import{m as A,g as f,a as O,f as x}from"./storage-tEZd5PMC.js";import{c as w}from"./llm-client-CDVh1Nha.js";A();chrome.runtime.onMessage.addListener((n,e,r)=>n.type==="GENERATE_COMMENTS"?(C(n.payload).then(r).catch(o=>{r({success:!1,error:o.message||"Failed to generate comments"})}),!0):n.type==="GENERATE_MESSAGES"?(M(n.payload).then(r).catch(o=>{r({success:!1,error:o.message||"Failed to generate message replies"})}),!0):n.type==="REFINE_COMMENT"?(P(n.payload).then(r).catch(o=>{r({success:!1,error:o.message||"Failed to refine comment"})}),!0):n.type==="CHECK_CONFIG"?(k().then(r).catch(o=>{r({success:!1,error:o.message||"Failed to check configuration"})}),!0):n.type==="STREAM_UPDATE_PERSONA"?(L(n.payload).then(r).catch(o=>{r({success:!1,error:o.message||"Failed to update persona"})}),!0):n.type==="OPEN_OPTIONS"?(chrome.runtime.openOptionsPage(),!1):n.type==="generate-post"?n.data?(U(n.data).then(r).catch(o=>{r({success:!1,error:o.message||"Failed to generate post"})}),!0):(r({success:!1,error:"Invalid request: missing data"}),!0):!1);async function C(n){var b;const{postData:e,tone:r,userThoughts:o,enableImageAnalysis:a,includeServiceOffer:t,serviceDescription:i}=n,s=await f();if(!s.apiKey)return{success:!1,error:"API key not configured. Please add it in the extension settings (click the gear icon)."};const l=s.persona,c=s.enableEmojis,d=s.languageLevel,m=a&&e.imageUrl,u=t&&(i==null?void 0:i.trim()),p=await O(),g=B(l,((b=e.threadContext)==null?void 0:b.mode)==="reply",c,d,o,!!m,u?i:void 0,p.map(h=>h.text)),y=G(e,r,o,u?i:void 0);let S,E;if(m&&e.imageUrl){const h=await $(e.imageUrl);h&&(S=h.base64,E=h.mimeType)}const v=await w(s.llmProvider,s.apiKey,s.model,{systemPrompt:g,userPrompt:y,imageBase64:S,imageMimeType:E,jsonMode:!0,temperature:.8,maxTokens:1500});if(!v.success)return{success:!1,error:v.error};const I=Y(v.content,t);if(I.length===0){const h=j(v.content);return h.length===0?{success:!1,error:"Could not parse generated comments."}:{success:!0,comments:h}}return{success:!0,scoredComments:I,comments:I.map(h=>h.text)}}async function P(n){const{comment:e,refinementType:r}=n,o=await f();if(!o.apiKey)return{success:!1,error:"API key not configured. Please add it in the extension settings."};const a=r==="concise"?`Make this LinkedIn comment more concise while keeping its impact and meaning. Remove filler words and tighten the prose. Keep it professional and engaging.

Original comment:
"${e}"

Respond with ONLY the refined comment, nothing else.`:`Rephrase this LinkedIn comment with different wording but keep the same meaning and tone. Make it sound fresh while maintaining professionalism.

Original comment:
"${e}"

Respond with ONLY the rephrased comment, nothing else.`,t=await w(o.llmProvider,o.apiKey,o.model,{systemPrompt:"You are a professional writing assistant.",userPrompt:a,jsonMode:!1,temperature:.7,maxTokens:300});return t.success?{success:!0,comment:t.content.replace(/^["']|["']$/g,"").trim()}:{success:!1,error:t.error}}async function k(){var o,a;const n=await f(),e=!!((o=n.apiKey)!=null&&o.trim()),r=!!((a=n.persona)!=null&&a.trim());if(!e||!r){const t=[];return r||t.push("persona"),e||t.push("API key"),{success:!1,error:`Please complete your setup in settings: ${t.join(", ")}`,settings:n}}return{success:!0,settings:n}}async function L(n){try{const{originalAiSuggestion:e,finalUserVersion:r}=n;if(R(e,r)>.95)return{success:!0};const a=await f();if(!a.apiKey)return{success:!0};const t=await w(a.llmProvider,a.apiKey,a.model,{systemPrompt:"You analyze how a user edits AI-generated text to understand their writing preferences.",userPrompt:`Compare these two texts and extract 1-3 concise observations about the user's writing preferences.

Original AI suggestion: "${e}"
User's final version: "${r}"

Examples of good observations: "Prefers shorter comments", "Removes technical jargon", "Adds personal anecdotes", "Uses more direct language"

Respond as JSON: { "observations": ["observation1", "observation2"] }`,jsonMode:!0,temperature:.3,maxTokens:200});if(t.success)try{const i=JSON.parse(t.content);if(i.observations&&Array.isArray(i.observations))for(const s of i.observations)typeof s=="string"&&s.length>3&&await x(s)}catch{}return{success:!0}}catch(e){return console.error("[LiPilot] Persona learning error:",e),{success:!0}}}function R(n,e){const r=n.toLowerCase().split(/\s+/),o=e.toLowerCase().split(/\s+/),a=new Set(r),t=new Set(o),i=new Set([...a].filter(l=>t.has(l))),s=new Set([...a,...t]);return s.size===0?1:i.size/s.size}async function M(n){const{conversationContext:e,tone:r,persona:o,enableEmojis:a,languageLevel:t,userThoughts:i,includeServiceOffer:s,serviceDescription:l}=n,c=await f();if(!c.apiKey)return{success:!1,error:"API key not configured. Please add it in the extension settings."};const d=await O(),m=F(o||c.persona,a,t,s?l:void 0,d.map(y=>y.text)),u=D(e,r,i,s?l:void 0),p=await w(c.llmProvider,c.apiKey,c.model,{systemPrompt:m,userPrompt:u,jsonMode:!0,temperature:.8,maxTokens:1200});if(!p.success)return{success:!1,error:p.error};const g=H(p.content);return!g.replies||g.replies.length===0?{success:!1,error:"Could not parse generated replies."}:{success:!0,replies:g.replies,summary:g.summary}}async function U(n){const e=await f();if(!e.apiKey)return{success:!1,error:"API key not configured. Please add it in the extension settings."};const r=`You are an expert LinkedIn content strategist. Generate a compelling LinkedIn post based on the user's topic and tone.

RULES:
1. Write in the first person as the user
2. Use line breaks for readability (LinkedIn format)
3. Include 3-5 relevant hashtags at the end
4. Keep it between 150-300 words
5. NO markdown formatting (no **, no ##, no bullet points with -)
6. Use plain text with line breaks
7. Make it engaging and shareable
8. Start with a hook that grabs attention`,o={professional:"Write in a polished, executive tone. Data-driven, strategic insights.",raw:"Write authentically and vulnerably. Share real experiences, lessons learned. Be genuine.",bold:"Write with strong opinions. Take a stance. Be provocative but respectful."},a=`Generate a LinkedIn post about: ${n.topic}

Tone: ${n.tone}
${o[n.tone]||""}

${n.keyPoints?`Key points to include:
${n.keyPoints}`:""}

Write the post directly. No preamble, no "Here's your post:" prefix.`,t=await w(e.llmProvider,e.apiKey,e.model,{systemPrompt:r,userPrompt:a,jsonMode:!1,temperature:.8,maxTokens:1e3});if(!t.success)return{success:!1,error:t.error};let i=t.content.trim();return i=i.replace(/\*\*/g,""),i=i.replace(/^#+\s*/gm,""),i=i.replace(/^[-*]\s/gm,""),{success:!0,data:{post:i,originalPost:t.content.trim()}}}async function $(n){try{const r=await(await fetch(n)).blob(),o=r.type||"image/jpeg";return new Promise(a=>{const t=new FileReader;t.onloadend=()=>{const s=t.result.split(",")[1];a({base64:s,mimeType:o})},t.onerror=()=>a(void 0),t.readAsDataURL(r)})}catch(e){console.error("[LiPilot] Error converting image to base64:",e);return}}function B(n,e=!1,r=!1,o="fluent",a,t=!1,i,s){const l="You are a seasoned professional who writes high-value, thought-provoking comments on LinkedIn.",c=r?"Use 1-2 relevant emojis sparingly to add warmth and make the tone friendlier. Place emojis naturally, not at the beginning.":"Do NOT use any emojis. Keep the text strictly professional and text-only.",d=t?`

IMAGE ANALYSIS:
You have been provided with an image from the LinkedIn post. Use this visual information to:
1. Reference specific details from the image (charts, graphs, screenshots, UI elements, text in images)
2. Make your comment more specific and insightful based on what you see
3. If the image contains data or statistics, mention them to show you've analyzed the content
4. If it's a screenshot or UI mockup, comment on specific design or feature elements
5. Connect the visual content with the text content for a more comprehensive response`:"",m=i?`

SERVICE BRIDGING (SUBTLE LEAD GENERATION):
The user wants to subtly showcase their expertise and services. Their service description:
"${i}"

CRITICAL INSTRUCTIONS FOR SERVICE BRIDGING:
1. Find a NATURAL connection between the post's topic and the user's service
2. DO NOT be pushy, salesy, or spammy - absolutely NO hard-sell phrases like "Buy now", "Hire me", "Check out my services"
3. The bridge must feel organic - as if the user is genuinely contributing expertise, not advertising
4. Position the user as a thought leader who happens to have relevant experience
5. Create a subtle opening for business conversation without explicitly pitching
6. The service mention should be woven into the comment naturally, not tacked on at the end
7. Focus on adding VALUE first, with the service connection as a secondary element`:"",u={native:`LANGUAGE LEVEL: Native/Bilingual
- Use sophisticated vocabulary, idioms, and nuanced expressions
- Complex sentence structures are fine
- Feel free to use industry jargon and advanced terminology
- Natural flow with varied rhythm and pacing`,fluent:`LANGUAGE LEVEL: Fluent/Advanced (B2-C1)
- Use rich vocabulary but avoid obscure words
- Natural sentence flow with some complexity
- Occasional advanced terms are okay, but not overly academic
- Sound professional but accessible`,intermediate:`LANGUAGE LEVEL: Intermediate (B1-B2)
- Use clear, straightforward vocabulary
- Prefer simpler sentence structures
- Avoid idioms, slang, and complex expressions
- Short to medium sentences (15-20 words max)
- Focus on clarity over sophistication
- Common words preferred over fancy alternatives`,basic:`LANGUAGE LEVEL: Basic (A2-B1)
- Use simple, everyday words only
- Very short sentences (8-12 words)
- No idioms, no metaphors, no complex grammar
- Subject-verb-object structure preferred
- One idea per sentence
- Write like explaining to someone learning the language`},p=u[o]||u.fluent,g=a?`

USER'S KEY POINT (PRIORITY):
The user wants to make this specific point or angle in their comment:
"${a}"

CRITICAL INSTRUCTIONS FOR USER'S KEY POINT:
1. You MUST incorporate this point naturally into ALL 3 comment variations
2. TRANSLATE the user's point to match the language of the original post/conversation - do NOT copy it verbatim if it's in a different language
3. This is the user's main intention - weave it organically into each response while maintaining the selected tone
4. Don't just append it; integrate it as the central thesis or key argument of the comment
5. The final comment must be entirely in the SAME language as the post being commented on`:"",y=s&&s.length>0?`

LEARNED USER PREFERENCES:
Based on past interactions, the user prefers:
${s.map(h=>`- ${h}`).join(`
`)}
Incorporate these preferences naturally into your comments.`:"";return`You are a world-class LinkedIn engagement specialist. Your mission is to craft high-value, professional comments that establish the commenter as a thought leader and valuable connection.${g}

${n?`The commenter's professional identity: "${n}"`:l}

CORE PRINCIPLES FOR HIGH-VALUE COMMENTS:

1. **Add Unique Perspective**: Share a fresh angle, contrarian view, or complementary insight that wasn't in the original post. Reference relevant industry trends, data points, or experiences.

2. **Demonstrate Expertise**: Use precise language and domain-specific knowledge. Avoid vague statements. Show you understand the nuances of the topic.

3. **Create Engagement Value**: Write comments that others will want to like or reply to. Provoke thought without being controversial. Ask questions that the author would genuinely want to answer.

4. **Sound Authentically Human**:
   - Vary sentence structure and length
   - Use natural transitions ("That said...", "What I've found...", "This reminds me of...")
   - Occasionally start with lowercase or use contractions
   - NO hashtags, NO exclamation marks overuse

5. **Be Concise but Substantive**: Aim for 2-3 impactful sentences. Every word should earn its place. Cut filler phrases like "I think that..." or "In my opinion..."

6. **Match the Conversation's Language**: Detect and respond in the SAME language as the post and existing comments (English, Spanish, French, German, etc.)

EMOJI POLICY:
${c}

${p}${d}${m}${y}`+`

STRICT FORMATTING RULES:
1. **NO Em-Dashes**: Never use long dashes without spaces (word—word). Use a comma, semicolon, or " - " (hyphen with spaces) instead.
2. **NO Quotation Marks**: Do not wrap the entire comment in quotation marks. Write the comment as plain text.
3. **NO Leading Quotes**: Never start a comment with " or ' characters.
4. **Clean Output**: Each comment should be ready to paste directly - no formatting artifacts.`+`

DISCUSSION CONTEXT AWARENESS:
- Analyze any existing comments provided. If you see a consensus forming, you can either add a new perspective or build upon a specific point.
- Avoid repeating what others have already said. Look for gaps in the discussion.
- If multiple people are making similar points, acknowledge it subtly ("Building on what others have noted...") then add fresh value.`+(e?`

REPLY MODE - THREAD CONVERSATION:
- You are replying to a SPECIFIC person in a comment thread, not the original post directly.
- Address their point directly while staying aligned with the original post's topic.
- Be conversational and direct - you're having a dialogue with this person.
- You can agree, respectfully disagree, ask follow-up questions, or extend their thinking.
- Use their name naturally if appropriate ("@Name, that's interesting because...")
- Keep replies slightly shorter than top-level comments - 1-2 sentences is often ideal for thread replies.`:"")+`

AVOID AT ALL COSTS:
- Generic praise ("Great post!", "Love this!", "So true!")
- Obvious statements that add no value
- Self-promotion or pitching (unless Service Bridging is enabled)
- Corporate buzzword soup
- Starting with "I"
- Sycophantic or overly agreeable tone
- Repeating points already made by other commenters
- Em-dashes (—) without spaces
- Wrapping comments in quotation marks

Generate exactly 3 DISTINCT comment variations with different approaches/angles.

SCORING & OUTPUT FORMAT:
You MUST respond with a valid JSON object. For each comment, score it on three dimensions (0-10):
- engagement: How likely to get likes, replies, and start discussions
- expertise: How much domain knowledge and professional credibility is shown
- conversion: How well it bridges to business/networking opportunities (relevant even if no service is mentioned)

Also assign ONE recommendation_tag from these options:
- "Best for Engagement" - most likely to get reactions
- "Most Insightful" - demonstrates deep expertise
- "Best for Sales" - creates business opportunities
- "Safe & Professional" - reliable, conservative choice
- "Most Creative" - unique, stands out
- "Thought-Provoking" - sparks discussion

Your response MUST be a JSON object with this exact structure:
{
  "comments": [
    {
      "text": "First comment here without any surrounding quotes",
      "scores": { "engagement": 8, "expertise": 7, "conversion": 5 },
      "recommendation_tag": "Best for Engagement"
    },
    {
      "text": "Second comment here",
      "scores": { "engagement": 6, "expertise": 9, "conversion": 4 },
      "recommendation_tag": "Most Insightful"
    },
    {
      "text": "Third comment here",
      "scores": { "engagement": 7, "expertise": 6, "conversion": 8 },
      "recommendation_tag": "Best for Sales"
    }
  ]
}`}function G(n,e,r,o){const{authorName:a,authorHeadline:t,postContent:i,threadContext:s}=n,l={professional:"Craft executive-level commentary. Use data-driven language, reference industry frameworks, and position insights as strategic observations. Think C-suite perspective.",funny:"Deploy wit and clever observations while maintaining professional credibility. Use unexpected analogies, gentle irony, or self-aware humor. Never force jokes - if humor doesn't fit naturally, lean intellectual instead.",question:'Ask thought-provoking questions that reveal deep understanding of the topic. Frame questions that the author would genuinely want to explore. Avoid yes/no questions - aim for "What if..." or "How might..." formats.',"agree-add-value":`Build on the post's thesis with a complementary case study, contrasting example, or "yes, and..." extension. Add a dimension the author didn't explore. Position as collaborative thought partnership.`};let c=`Generate 3 LinkedIn comment variations for this post:

POST AUTHOR: ${a}
${t?`AUTHOR HEADLINE: ${t}`:""}

POST CONTENT:
"""
${i}
"""`;s!=null&&s.existingComments&&s.existingComments.length>0&&(c+=`

EXISTING DISCUSSION (${s.existingComments.length} comments):
${s.existingComments.map((m,u)=>`${u+1}. ${m.authorName}${m.authorHeadline?` (${m.authorHeadline})`:""}: "${m.content}"`).join(`
`)}

IMPORTANT: Do NOT repeat points already made above. Add NEW value to the discussion.`),(s==null?void 0:s.mode)==="reply"&&s.parentComment&&(c+=`

REPLY MODE - You are replying to this specific comment:
REPLYING TO: ${s.parentComment.authorName}${s.parentComment.authorHeadline?` (${s.parentComment.authorHeadline})`:""}
THEIR COMMENT: "${s.parentComment.content}"

${s.threadParticipants.length>1?`Other participants in this thread: ${s.threadParticipants.filter(m=>{var u;return m!==((u=s.parentComment)==null?void 0:u.authorName)}).join(", ")}`:""}

Generate replies that directly engage with ${s.parentComment.authorName}'s point.`),c+=`

DESIRED TONE: ${e}
${l[e]||""}`,r&&(c+=`

USER'S KEY POINT TO INCLUDE:
"${r}"
IMPORTANT: Translate this point to match the post's language if needed, then weave it naturally into each comment variation. The entire comment must be in the same language as the original post.`),o&&(c+=`

SERVICE TO SUBTLY BRIDGE:
"${o}"
IMPORTANT: Find a natural connection to this service/expertise. Position as thought leadership, NOT advertising.`);let d=5;return c+=`

Remember to:
1. Detect the language of the conversation and write ALL comments in that SAME language
2. Make each comment variation distinct and unique
3. Keep the tone consistent with the request
4. Write naturally as if you're a real person engaging with the content`,(s==null?void 0:s.mode)==="reply"&&(c+=`
${d}. Address the specific person you are replying to`,d++),r&&(c+=`
${d}. PRIORITIZE integrating the user's key point above`,d++),o&&(c+=`
${d}. Subtly bridge to the user's service - establish authority, don't sell`),c}function F(n,e,r,o,a){const t="You are a skilled communicator who helps craft thoughtful, effective LinkedIn messages.",i=e?"Use 1-2 emojis sparingly to add warmth where appropriate. Keep it professional.":"Do NOT use any emojis. Keep the text clean and professional.",s=o?`
SERVICE BRIDGING (SUBTLE):
If appropriate, the user wants to naturally mention their services:
"${o}"

Find an organic opportunity to position this expertise. Do NOT be pushy or salesy. Position as helpful, not promotional.`:"",l={native:"Use sophisticated, natural language with idioms and nuanced expressions.",fluent:"Use rich but accessible vocabulary with natural flow.",intermediate:"Use clear, straightforward language. Avoid complex expressions.",basic:"Use simple words and short sentences. Very easy to understand."},c=l[r]||l.fluent,d=a&&a.length>0?`

LEARNED USER PREFERENCES:
${a.map(m=>`- ${m}`).join(`
`)}`:"";return`You are an expert business negotiator and the user's personal conversation co-pilot.

${n?`The user's professional identity: "${n}"`:t}

YOUR MISSION:
- Analyze the conversation history provided
- Craft replies that feel natural and advance the conversation toward the user's goal
- Match the tone and language already established in the chat
- Never sound robotic or templated

COMMUNICATION PRINCIPLES:
1. **Read the Room**: If the conversation is casual, stay casual. If formal, stay formal.
2. **Be Concise**: DMs should be brief and punchy. 1-3 sentences is ideal.
3. **Advance the Goal**: Every message should move the conversation forward - toward a meeting, a deal, or a stronger relationship.
4. **Be Human**: Use natural transitions, contractions, and conversational flow.
5. **Don't Overdo It**: Avoid over-enthusiasm ("So excited!", "Amazing!") unless the context warrants it.

AVOID:
- "Dear [Name]" if the conversation is already casual
- Long paragraphs - keep it short and scannable
- Repeated pleasantries if they've already been exchanged
- Sounding desperate or overly available
- Generic phrases like "I hope this finds you well" if they've already chatted

EMOJI POLICY:
${i}

LANGUAGE LEVEL:
${c}
${s}${d}

Generate exactly 3 DISTINCT reply options with different approaches.

Your response MUST be a valid JSON object with this structure:
{
  "summary": {
    "topic": "Brief description of what this conversation is about",
    "lastMessageSummary": "What the last message was about",
    "suggestedAction": "What the user should do next (e.g., 'Schedule a call', 'Follow up on proposal')"
  },
  "replies": [
    {
      "text": "First reply option",
      "recommendation_tag": "Best Follow-up"
    },
    {
      "text": "Second reply option",
      "recommendation_tag": "Build Rapport"
    },
    {
      "text": "Third reply option",
      "recommendation_tag": "Move Forward"
    }
  ]
}

Valid recommendation_tags: "Best Follow-up", "Move Forward", "Build Rapport", "Safe Choice", "Close the Deal"`}function D(n,e,r,o){const{participantName:a,participantHeadline:t,messages:i,topic:s,sentiment:l,lastMessageFrom:c}=n,d={friendly:"Keep it warm and personable. Build rapport and show genuine interest.",professional:"Maintain a business-appropriate tone. Be respectful and to-the-point.","follow-up":"Gently remind or check in. Don't be pushy but show you're engaged.","closing-deal":"Move toward concrete next steps. Be confident and action-oriented.",networking:"Focus on building the relationship. Find common ground."},m=i.map(p=>`[${p.sender==="me"?"YOU":a}]: ${p.content}`).join(`
`);let u=`Generate 3 reply options for this LinkedIn conversation:

CHATTING WITH: ${a}
${t?`THEIR ROLE: ${t}`:""}

CONVERSATION HISTORY:
${m}

CONTEXT ANALYSIS:
- Topic: ${s||"General discussion"}
- Sentiment: ${l||"neutral"}
- Last message from: ${c==="me"?"You (waiting for their reply)":a}

DESIRED TONE: ${e}
${d[e]||""}`;return r&&(u+=`

USER'S GOAL FOR THIS REPLY:
"${r}"
IMPORTANT: Incorporate this goal naturally into the reply options.`),o&&(u+=`

SERVICE TO SUBTLY MENTION (if natural):
"${o}"
Only include if there's a genuinely organic opportunity.`),c==="me"&&(u+=`

NOTE: The last message was from YOU. The user might be considering a follow-up since there's no response yet. Be mindful of not appearing pushy.`),u}function Y(n,e=!1){try{const r=JSON.parse(n);if(!r.comments||!Array.isArray(r.comments))return[];const o=["Best for Engagement","Most Insightful","Best for Sales","Safe & Professional","Most Creative","Thought-Provoking"],a=r.comments.filter(t=>{if(!t||typeof t!="object")return!1;const i=t;return typeof i.text=="string"&&i.text.length>10}).map(t=>{const i=t.scores,s=t.recommendation_tag,l={engagement:T(i==null?void 0:i.engagement),expertise:T(i==null?void 0:i.expertise),conversion:T(i==null?void 0:i.conversion)},c=o.includes(s)?s:"Safe & Professional";return{text:N(t.text),scores:l,recommendationTag:c,isRecommended:!1}}).slice(0,3);if(a.length>0){const t=[...a].sort((s,l)=>e?l.scores.conversion-s.scores.conversion:l.scores.engagement-s.scores.engagement),i=a.findIndex(s=>s.text===t[0].text);i!==-1&&(a[i].isRecommended=!0)}return a}catch{return[]}}function T(n){if(typeof n=="number")return Math.max(0,Math.min(10,Math.round(n)));if(typeof n=="string"){const e=parseFloat(n);if(!isNaN(e))return Math.max(0,Math.min(10,Math.round(e)))}return 5}function j(n){const e=[],r=/COMMENT\s*\d+:\s*([\s\S]*?)(?=COMMENT\s*\d+:|$)/gi;let o;for(;(o=r.exec(n))!==null;){const a=o[1].trim();a&&a.length>10&&e.push(a)}if(e.length===0){const a=/(?:^|\n)\s*(?:\d+[\.\)]\s*)([\s\S]*?)(?=(?:^|\n)\s*\d+[\.\)]|$)/gm;for(;(o=a.exec(n))!==null;){const t=o[1].trim();t&&t.length>10&&e.push(t)}}if(e.length===0){const a=n.split(/\n\s*\n/).filter(t=>t.trim().length>10);e.push(...a.slice(0,3))}return e.slice(0,3).map(a=>N(a))}function N(n){let e=n.trim();return e=e.replace(/^["'"'"]+|["'"'"]+$/g,""),e=e.replace(/—/g," - "),e=e.replace(/\s+/g," "),e=e.trim(),e}function H(n){try{const e=JSON.parse(n),r=["Best Follow-up","Move Forward","Build Rapport","Safe Choice","Close the Deal"],o=(e.replies||[]).filter(t=>{if(!t||typeof t!="object")return!1;const i=t;return typeof i.text=="string"&&i.text.length>5}).map(t=>({text:N(t.text),recommendationTag:r.includes(t.recommendation_tag)?t.recommendation_tag:"Safe Choice"})).slice(0,3),a=e.summary?{topic:e.summary.topic||"Professional discussion",lastMessageSummary:e.summary.lastMessageSummary||"",suggestedAction:e.summary.suggestedAction||"Continue the conversation"}:void 0;return{replies:o,summary:a}}catch{return{replies:[]}}}
