import{j as e,r as x,c as ye,R as we}from"./client-D7f9BLy3.js";import{b as Qe,d as Ze,e as De,g as Me}from"./storage-tEZd5PMC.js";function le({icon:t,label:n,value:o,fullValue:s,status:r,subLabel:i}){const[a,c]=x.useState(!1),l=s&&s.length>0&&s!==o,d=()=>r==="scanning"?e.jsx("div",{className:"context-status scanning",children:e.jsx("div",{className:"scan-spinner"})}):r==="success"?e.jsx("div",{className:"context-status success",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})}):e.jsx("div",{className:"context-status warning",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("path",{d:"M12 9v4M12 17h.01"})})});return e.jsxs("div",{className:`context-item ${r} ${l?"has-tooltip":""}`,onMouseEnter:()=>l&&c(!0),onMouseLeave:()=>c(!1),children:[e.jsx("div",{className:"context-item-line"}),e.jsx("div",{className:"context-item-icon",children:t}),e.jsxs("div",{className:"context-item-content",children:[e.jsxs("div",{className:"context-item-header",children:[e.jsx("span",{className:"context-item-label",children:n}),d(),l&&e.jsx("span",{className:"hover-hint",children:e.jsxs("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 16v-4M12 8h.01"})]})})]}),r==="scanning"?e.jsx("div",{className:"context-item-value scanning",children:"Scanning..."}):o?e.jsx("div",{className:"context-item-value",children:o}):e.jsx("div",{className:"context-item-value warning",children:i||"Not found"})]}),a&&s&&e.jsxs("div",{className:"context-tooltip",children:[e.jsx("div",{className:"context-tooltip-header",children:n}),e.jsx("div",{className:"context-tooltip-content",children:s})]})]})}function et({postData:t,isScanning:n,analyzeImage:o,onAnalyzeImageChange:s}){const r=(m,b)=>m?m.length>b?m.slice(0,b)+"...":m:"",i=()=>n?"scanning":t!=null&&t.postContent?"success":"warning",a=()=>n?"scanning":t!=null&&t.authorName?"success":"warning",c=()=>n?"scanning":"success",l=()=>{var b,C;return n?"scanning":(((C=(b=t==null?void 0:t.threadContext)==null?void 0:b.existingComments)==null?void 0:C.length)||0)>0?"success":"warning"},d=()=>{var m,b;return t?((m=t.threadContext)==null?void 0:m.mode)==="reply"&&((b=t.threadContext)!=null&&b.parentComment)?`Replying to ${t.threadContext.parentComment.authorName}`:"Direct Comment Mode":null},h=()=>{var m,b;return t?((m=t.threadContext)==null?void 0:m.mode)==="reply"&&((b=t.threadContext)!=null&&b.parentComment)?r(t.threadContext.parentComment.content,50):"Commenting directly on the main post":null},p=()=>{var m,b;return t&&((m=t.threadContext)==null?void 0:m.mode)==="reply"&&(b=t.threadContext)!=null&&b.parentComment?t.threadContext.parentComment.content:null},g=()=>{var b,C;if(!t)return null;const m=((C=(b=t.threadContext)==null?void 0:b.existingComments)==null?void 0:C.length)||0;return m===0?"No previous comments found":`${m} previous comment${m>1?"s":""} analyzed`},S=()=>{var b;if(!t)return null;const m=(b=t.threadContext)==null?void 0:b.existingComments;return!m||m.length===0?null:m.map((C,j)=>`${j+1}. ${C.authorName}: "${r(C.content,100)}"`).join(`

`)},E=()=>{if(!t)return null;const m=[];return t.authorName&&m.push(`Name: ${t.authorName}`),t.authorHeadline&&m.push(`Headline: ${t.authorHeadline}`),m.length>0?m.join(`
`):null},M=()=>n?"scanning":t!=null&&t.imageUrl?"success":"warning";return e.jsxs("div",{className:"context-awareness",children:[e.jsxs("div",{className:"context-header",children:[e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 16v-4M12 8h.01"})]}),e.jsx("span",{children:"Context Analysis"}),n&&e.jsx("span",{className:"scanning-badge",children:"Scanning"})]}),e.jsxs("div",{className:"context-timeline",children:[e.jsx(le,{icon:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"}),e.jsx("polyline",{points:"14 2 14 8 20 8"}),e.jsx("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),e.jsx("line",{x1:"16",y1:"17",x2:"8",y2:"17"})]}),label:"Post Content",value:t?r(t.postContent,50):null,fullValue:(t==null?void 0:t.postContent)||null,status:i(),subLabel:"Unable to scrape post content"}),e.jsx(le,{icon:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"}),e.jsx("circle",{cx:"12",cy:"7",r:"4"})]}),label:"Author",value:t!=null&&t.authorName?`${t.authorName}${t.authorHeadline?` • ${r(t.authorHeadline,30)}`:""}`:null,fullValue:E(),status:a(),subLabel:"Author info not found"}),e.jsx(le,{icon:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polyline",{points:"9 17 4 12 9 7"}),e.jsx("path",{d:"M20 18v-2a4 4 0 0 0-4-4H4"})]}),label:d()||"Thread Mode",value:h(),fullValue:p(),status:c()}),e.jsx(le,{icon:e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})}),label:"Discussion Context",value:g(),fullValue:S(),status:l()}),e.jsxs("div",{className:`context-item ${M()}`,children:[e.jsx("div",{className:"context-item-line"}),e.jsx("div",{className:"context-item-icon",children:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"}),e.jsx("circle",{cx:"8.5",cy:"8.5",r:"1.5"}),e.jsx("polyline",{points:"21 15 16 10 5 21"})]})}),e.jsxs("div",{className:"context-item-content",children:[e.jsxs("div",{className:"context-item-header",children:[e.jsx("span",{className:"context-item-label",children:"Image Analysis"}),M()==="scanning"?e.jsx("div",{className:"context-status scanning",children:e.jsx("div",{className:"scan-spinner"})}):M()==="success"?e.jsx("div",{className:"context-status success",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})}):e.jsx("div",{className:"context-status warning",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("path",{d:"M12 9v4M12 17h.01"})})}),(t==null?void 0:t.imageUrl)&&s&&e.jsxs("label",{className:"image-analysis-toggle",onClick:m=>m.stopPropagation(),children:[e.jsx("input",{type:"checkbox",checked:o??!1,onChange:m=>s(m.target.checked)}),e.jsx("span",{className:`mini-toggle ${o?"active":""}`})]})]}),M()==="scanning"?e.jsx("div",{className:"context-item-value scanning",children:"Scanning..."}):t!=null&&t.imageUrl?e.jsx("div",{className:"context-item-value",children:o?"Will analyze image":"Image skipped (click toggle)"}):e.jsx("div",{className:"context-item-value warning",children:"No image in post"})]})]})]})]})}function Pe(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}async function ce(t){if(console.log("[FloatingPanel] safeSendMessage called with type:",t.type),!Pe())return console.error("[FloatingPanel] Extension context invalidated!"),{success:!1,error:"Extension was updated. Please refresh the page."};try{console.log("[FloatingPanel] Sending message to background script...");const n=await chrome.runtime.sendMessage(t);return console.log("[FloatingPanel] Received response from background:",n),n}catch(n){if(console.error("[FloatingPanel] Error sending message:",n),n instanceof Error&&(n.message.includes("Extension context invalidated")||n.message.includes("Receiving end does not exist")))return{success:!1,error:"Extension was updated. Please refresh the page."};throw n}}const tt=[{value:"professional",label:"Professional"},{value:"funny",label:"Funny"},{value:"question",label:"Question"},{value:"agree-add-value",label:"Agree & Add Value"}];function nt({postData:t,isScanning:n=!1,onClose:o,onInsertComment:s}){const[r,i]=x.useState("generate"),[a,c]=x.useState("professional"),[l,d]=x.useState(""),[h,p]=x.useState(!1),[g,S]=x.useState([]),[E,M]=x.useState([]),[m,b]=x.useState(null),[C,j]=x.useState(null),[L,w]=x.useState(!1),[N,I]=x.useState(!0),[z,P]=x.useState(null),[T,k]=x.useState([]),[W,oe]=x.useState(null),[se,re]=x.useState(null),[v,A]=x.useState(!1),[V,H]=x.useState(!1),[O,D]=x.useState(!1),[ee,He]=x.useState(!1),[te,Fe]=x.useState(null),$e=!n&&t&&t.postContent&&L,ie=x.useRef(null),Ve=()=>{const u=ie.current;u&&(u.style.height="auto",u.style.height=`${Math.min(u.scrollHeight,120)}px`)},ae=x.useRef(null),F=x.useRef({isDragging:!1,startX:0,startY:0,initialX:0,initialY:0});x.useEffect(()=>{Oe(),pe()},[]);const Oe=async()=>{var u;I(!0),P(null);try{const f=await ce({type:"CHECK_CONFIG"});if(!f.success){w(!1),P(f.error||"Failed to check configuration"),I(!1);return}const y=f.settings;if(!y){w(!1),P("Settings not found. Please configure the extension in Settings."),I(!1);return}Fe({enableEmojis:y.enableEmojis??!1,languageLevel:y.languageLevel||"fluent",serviceDescription:y.serviceDescription||""});const B=y.persona&&y.persona.trim().length>0,_=y.apiKey&&y.apiKey.trim().length>0,$=B&&_;if(w($),H(!!((u=y.serviceDescription)!=null&&u.trim())),He(y.enableImageAnalysis??!1),D(y.enableImageAnalysis??!1),$)console.log("[FloatingPanel] Configuration check successful - extension ready");else{const R=[];B||R.push("persona"),_||R.push("API key"),P(`Please complete your setup in Settings: ${R.join(", ")}`)}}catch(f){console.error("[FloatingPanel] Configuration check failed:",f),w(!1),f!=null&&f.message?P(`Error: ${f.message}`):P("Failed to check configuration. Please try again.")}finally{I(!1)}},pe=async()=>{const u=await Qe();k(u)};x.useEffect(()=>{const u=ae.current;if(!u)return;const f=_=>{if(!_.target.closest(".panel-header"))return;F.current.isDragging=!0,F.current.startX=_.clientX,F.current.startY=_.clientY;const R=u.getBoundingClientRect();F.current.initialX=R.left,F.current.initialY=R.top,u.style.transition="none"},y=_=>{if(!F.current.isDragging)return;const $=_.clientX-F.current.startX,R=_.clientY-F.current.startY;u.style.right="auto",u.style.left=`${F.current.initialX+$}px`,u.style.top=`${F.current.initialY+R}px`},B=()=>{F.current.isDragging=!1,u.style.transition=""};return u.addEventListener("mousedown",f),document.addEventListener("mousemove",y),document.addEventListener("mouseup",B),()=>{u.removeEventListener("mousedown",f),document.removeEventListener("mousemove",y),document.removeEventListener("mouseup",B)}},[]);const Ge=async()=>{var u;if(!t){j("No post data available. Please try again.");return}if(!te||!L){j("Configuration not ready. Please wait...");return}p(!0),j(null),S([]),M([]);try{const f={type:"GENERATE_COMMENTS",payload:{postData:t,tone:a,enableEmojis:te.enableEmojis,languageLevel:te.languageLevel,userThoughts:l.trim()||void 0,enableImageAnalysis:O&&!!(t!=null&&t.imageUrl),includeServiceOffer:v&&!!((u=te.serviceDescription)!=null&&u.trim()),serviceDescription:v?te.serviceDescription:void 0}},y=await ce(f);y.success?y.scoredComments&&y.scoredComments.length>0?(M(y.scoredComments),S(y.scoredComments.map(B=>B.text))):y.comments&&S(y.comments):j(y.error||"Failed to generate comments")}catch(f){j(f instanceof Error?f.message:"An unexpected error occurred")}finally{p(!1)}},Ne=async(u,f)=>{b(u);try{const B={type:"REFINE_COMMENT",payload:{comment:E.length>0?E[u].text:g[u],refinementType:f}},_=await ce(B);if(_.success&&_.comment){if(E.length>0){const R=[...E];R[u]={...R[u],text:_.comment},M(R)}const $=[...g];$[u]=_.comment,S($)}else _.error&&j(_.error)}catch(y){console.error("Refine error:",y)}finally{b(null)}},Se=async(u,f,y)=>{try{await navigator.clipboard.writeText(u),f!==void 0&&(oe(f),setTimeout(()=>oe(null),2e3)),y&&(re(y),setTimeout(()=>re(null),2e3))}catch(B){console.error("Copy failed:",B)}},Ye=async(u,f)=>{var B;t&&await Ze(u,t.postContent);const y=f!==void 0&&(((B=E[f])==null?void 0:B.text)||g[f])||u;s(u),ce({type:"STREAM_UPDATE_PERSONA",payload:{originalAiSuggestion:y,finalUserVersion:u}}).catch(_=>{console.error("[FloatingPanel] Persona update error:",_)}),pe()},Xe=async()=>{await De(),k([])},Ue=()=>{if(Pe())try{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})}catch{j("Extension was updated. Please refresh the page.")}else j("Extension was updated. Please refresh the page.")},Ke=(u,f)=>u.length<=f?u:u.slice(0,f)+"...",Je=u=>{const f=new Date(u),B=new Date().getTime()-f.getTime(),_=Math.floor(B/6e4),$=Math.floor(B/36e5),R=Math.floor(B/864e5);return _<1?"Just now":_<60?`${_}m ago`:$<24?`${$}h ago`:R<7?`${R}d ago`:f.toLocaleDateString()};return N?e.jsxs("div",{className:"panel",ref:ae,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"})})}),e.jsx("span",{children:"AI Comment Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"panel-content",children:e.jsxs("div",{className:"no-api-key",children:[e.jsx("div",{className:"no-api-key-icon",children:e.jsx("div",{className:"w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto"})}),e.jsx("h3",{children:"Checking Configuration..."}),e.jsx("p",{children:"Verifying your setup"})]})})]}):L?e.jsx(e.Fragment,{children:e.jsxs("div",{className:"panel",ref:ae,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"})})}),e.jsx("span",{children:"AI Comment Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsxs("div",{className:"tabs",children:[e.jsxs("button",{className:`tab ${r==="generate"?"active":""}`,onClick:()=>i("generate"),children:[e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),"Generate"]}),e.jsxs("button",{className:`tab ${r==="history"?"active":""}`,onClick:()=>{i("history"),pe()},children:[e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("polyline",{points:"12 6 12 12 16 14"})]}),"History"]})]}),e.jsx(et,{postData:t,isScanning:n,analyzeImage:O,onAnalyzeImageChange:D}),e.jsx("div",{className:"panel-content",children:r==="generate"?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"section",children:[e.jsxs("div",{className:"section-label",children:["Your key point ",e.jsx("span",{className:"optional-label",children:"(optional)"})]}),e.jsxs("div",{className:"thoughts-input-wrapper",children:[e.jsx("textarea",{ref:ie,className:"thoughts-input",value:l,onChange:u=>{d(u.target.value),Ve()},placeholder:"e.g., Mention that we just launched a similar feature, or ask about their pricing model...",rows:2}),l&&e.jsx("button",{className:"clear-thoughts-btn",onClick:()=>{d(""),ie.current&&(ie.current.style.height="auto")},title:"Clear",children:e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]})]}),e.jsx("div",{className:"section",children:e.jsxs("label",{className:`service-offer-toggle ${V?"":"disabled"}`,children:[e.jsxs("div",{className:"toggle-left",children:[e.jsx("div",{className:"toggle-icon",children:e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"2",y:"7",width:"20",height:"14",rx:"2",ry:"2"}),e.jsx("path",{d:"M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"})]})}),e.jsxs("div",{className:"toggle-text",children:[e.jsx("span",{className:"toggle-label",children:"Include Service Offer"}),V?e.jsx("span",{className:"toggle-hint",children:"Subtly promote your expertise"}):e.jsx("span",{className:"toggle-hint warning",children:"Configure in Settings first"})]})]}),e.jsx("input",{type:"checkbox",checked:v,onChange:u=>A(u.target.checked),disabled:!V,className:"toggle-checkbox"}),e.jsx("span",{className:`toggle-switch ${v?"active":""}`})]})}),e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Tone"}),e.jsx("select",{className:"tone-select",value:a,onChange:u=>c(u.target.value),children:tt.map(u=>e.jsx("option",{value:u.value,children:u.label},u.value))})]}),e.jsx("div",{className:"section",children:e.jsx("button",{className:"generate-btn",onClick:Ge,disabled:!$e||h,children:n?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Scanning Context..."]}):h?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Generating..."]}):t?e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),"Generate Comments"]}):e.jsxs(e.Fragment,{children:[e.jsxs("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 8v4M12 16h.01"})]}),"Waiting for Context..."]})})}),h&&e.jsxs("div",{className:"shimmer-container",children:[e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line long"}),e.jsx("div",{className:"shimmer-line medium"}),e.jsx("div",{className:"shimmer-line short"})]}),e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line long"}),e.jsx("div",{className:"shimmer-line medium"})]}),e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line medium"}),e.jsx("div",{className:"shimmer-line long"})]})]}),C&&e.jsxs("div",{className:"error-message",children:[e.jsxs("svg",{className:"error-icon",width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("line",{x1:"12",y1:"8",x2:"12",y2:"12"}),e.jsx("line",{x1:"12",y1:"16",x2:"12.01",y2:"16"})]}),e.jsx("span",{children:C})]}),g.length>0&&!h&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Generated Comments"}),e.jsx("div",{className:"results",children:g.map((u,f)=>{const y=E[f];return e.jsxs("div",{className:`comment-card ${m===f?"refining":""}`,children:[(y==null?void 0:y.recommendationTag)&&e.jsx("div",{className:"recommendation-tag",children:y.recommendationTag}),e.jsx("div",{className:"comment-text",children:u}),e.jsxs("div",{className:"comment-actions",children:[e.jsxs("div",{className:"action-group",children:[e.jsx("button",{className:"action-btn refine-btn",onClick:()=>Ne(f,"concise"),disabled:m!==null,title:"Make more concise",children:m===f?e.jsx("div",{className:"spinner-small"}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M4 12h16M4 12l4-4M4 12l4 4M20 12l-4-4M20 12l-4 4"})}),e.jsx("span",{children:"Shorter"})]})}),e.jsx("button",{className:"action-btn refine-btn",onClick:()=>Ne(f,"rephrase"),disabled:m!==null,title:"Rephrase",children:m===f?e.jsx("div",{className:"spinner-small"}):e.jsxs(e.Fragment,{children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M1 4v6h6"}),e.jsx("path",{d:"M3.51 15a9 9 0 1 0 2.13-9.36L1 10"})]}),e.jsx("span",{children:"Rephrase"})]})})]}),e.jsxs("div",{className:"action-group",children:[e.jsx("button",{className:`action-btn ${W===f?"copied":""}`,onClick:()=>Se(u,f),title:"Copy to clipboard",children:W===f?e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})}):e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),e.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]})}),e.jsxs("button",{className:"insert-btn",onClick:()=>Ye(u,f),title:"Insert into comment box",children:[e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})}),"Insert"]})]})]})]},f)})})]})]}):e.jsx("div",{className:"history-section",children:T.length===0?e.jsxs("div",{className:"empty-history",children:[e.jsxs("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("polyline",{points:"12 6 12 12 16 14"})]}),e.jsx("p",{children:"No comments in history yet."}),e.jsx("span",{children:"Generated comments will appear here."})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"history-header",children:[e.jsxs("span",{className:"history-count",children:[T.length," recent comments"]}),e.jsxs("button",{className:"clear-history-btn",onClick:Xe,children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polyline",{points:"3 6 5 6 21 6"}),e.jsx("path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),"Clear"]})]}),e.jsx("div",{className:"history-list",children:T.map(u=>e.jsxs("div",{className:"history-item",children:[e.jsxs("div",{className:"history-meta",children:[e.jsx("span",{className:"history-time",children:Je(u.timestamp)}),e.jsx("span",{className:"history-post",children:Ke(u.postPreview,30)})]}),e.jsx("div",{className:"history-comment",children:u.comment}),e.jsxs("div",{className:"history-actions",children:[e.jsx("button",{className:`action-btn ${se===u.id?"copied":""}`,onClick:()=>Se(u.comment,void 0,u.id),children:se===u.id?e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})}),"Copied"]}):e.jsxs(e.Fragment,{children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),e.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]}),"Copy"]})}),e.jsxs("button",{className:"insert-btn",onClick:()=>s(u.comment),children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})}),"Insert"]})]})]},u.id))})]})})}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]})}):e.jsx(e.Fragment,{children:e.jsxs("div",{className:"panel",ref:ae,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"})})}),e.jsx("span",{children:"AI Comment Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"panel-content",children:e.jsxs("div",{className:"no-api-key",children:[e.jsx("div",{className:"no-api-key-icon",children:e.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"})})}),e.jsx("h3",{children:"Setup Required"}),e.jsx("p",{children:z||"Please complete your setup in Settings"}),e.jsxs("button",{className:"settings-btn",onClick:Ue,children:[e.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"})]}),"Open Settings"]})]})}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]})})}const ot=[{value:"friendly",label:"Friendly"},{value:"professional",label:"Professional"},{value:"follow-up",label:"Follow-up"},{value:"closing-deal",label:"Closing Deal"},{value:"networking",label:"Networking"}];function Te(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}async function st(t){if(!Te())return{success:!1,error:"Extension was updated. Please refresh the page."};try{return await chrome.runtime.sendMessage(t)}catch(n){if(n instanceof Error&&(n.message.includes("Extension context invalidated")||n.message.includes("Receiving end does not exist")))return{success:!1,error:"Extension was updated. Please refresh the page."};throw n}}function rt({conversationContext:t,isScanning:n=!1,onClose:o,onInsertReply:s}){const[r,i]=x.useState("friendly"),[a,c]=x.useState(""),[l,d]=x.useState(!1),[h,p]=x.useState([]),[g,S]=x.useState(null),[E,M]=x.useState(null),[m,b]=x.useState(!0),[C,j]=x.useState(null),[L,w]=x.useState(!1),[N,I]=x.useState(!1),z=!n&&t&&t.messages.length>0&&m,P=x.useRef(null),T=x.useRef(null),k=x.useRef({isDragging:!1,startX:0,startY:0,initialX:0,initialY:0});x.useEffect(()=>{Me().then(v=>{var A;b(!!v.apiKey),I(!!((A=v.serviceDescription)!=null&&A.trim()))})},[]);const W=()=>{const v=P.current;v&&(v.style.height="auto",v.style.height=`${Math.min(v.scrollHeight,120)}px`)};x.useEffect(()=>{const v=T.current;if(!v)return;const A=O=>{if(!O.target.closest(".panel-header"))return;k.current.isDragging=!0,k.current.startX=O.clientX,k.current.startY=O.clientY;const ee=v.getBoundingClientRect();k.current.initialX=ee.left,k.current.initialY=ee.top,v.style.transition="none"},V=O=>{if(!k.current.isDragging)return;const D=O.clientX-k.current.startX,ee=O.clientY-k.current.startY;v.style.right="auto",v.style.left=`${k.current.initialX+D}px`,v.style.top=`${k.current.initialY+ee}px`},H=()=>{k.current.isDragging=!1,v.style.transition=""};return v.addEventListener("mousedown",A),document.addEventListener("mousemove",V),document.addEventListener("mouseup",H),()=>{v.removeEventListener("mousedown",A),document.removeEventListener("mousemove",V),document.removeEventListener("mouseup",H)}},[]);const oe=async()=>{var v;if(!t){M("No conversation context available.");return}d(!0),M(null),p([]),S(null);try{const A=await Me();if(!A.apiKey){b(!1);return}const V={type:"GENERATE_MESSAGES",payload:{conversationContext:t,tone:r,persona:A.persona,enableEmojis:A.enableEmojis??!1,languageLevel:A.languageLevel||"fluent",userThoughts:a.trim()||void 0,includeServiceOffer:L&&!!((v=A.serviceDescription)!=null&&v.trim()),serviceDescription:L?A.serviceDescription:void 0}},H=await st(V);H.success&&H.replies?(p(H.replies),H.summary&&S(H.summary)):M(H.error||"Failed to generate replies")}catch(A){M(A instanceof Error?A.message:"An unexpected error occurred")}finally{d(!1)}},se=async(v,A)=>{try{await navigator.clipboard.writeText(v),j(A),setTimeout(()=>j(null),2e3)}catch(V){console.error("Copy failed:",V)}},re=()=>{if(Te())try{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})}catch{M("Extension was updated. Please refresh the page.")}else M("Extension was updated. Please refresh the page.")};return m?e.jsxs("div",{className:"panel messaging-panel",ref:T,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon messaging",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})})}),e.jsx("span",{children:"Conversation Co-pilot"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"messaging-context",children:n?e.jsxs("div",{className:"context-scanning",children:[e.jsx("div",{className:"spinner-small"}),e.jsx("span",{children:"Analyzing conversation..."})]}):t?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"context-participant",children:[e.jsx("span",{className:"context-label",children:"Chatting with:"}),e.jsx("span",{className:"context-value",children:t.participantName})]}),t.participantHeadline&&e.jsx("div",{className:"context-headline",children:t.participantHeadline}),e.jsxs("div",{className:"context-stats",children:[e.jsxs("span",{className:"stat",children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})}),t.messages.length," messages"]}),e.jsxs("span",{className:"stat",children:[e.jsx("span",{className:`sentiment-dot ${t.sentiment}`}),t.sentiment]})]}),g&&e.jsxs("div",{className:"ai-summary",children:[e.jsx("div",{className:"summary-topic",children:g.topic}),e.jsxs("div",{className:"summary-action",children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),g.suggestedAction]})]})]}):e.jsxs("div",{className:"context-empty",children:[e.jsxs("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 8v4M12 16h.01"})]}),e.jsx("span",{children:"Open a conversation to get started"})]})}),e.jsxs("div",{className:"panel-content",children:[e.jsxs("div",{className:"section",children:[e.jsxs("div",{className:"section-label",children:["Your goal for this reply ",e.jsx("span",{className:"optional-label",children:"(optional)"})]}),e.jsxs("div",{className:"thoughts-input-wrapper",children:[e.jsx("textarea",{ref:P,className:"thoughts-input",value:a,onChange:v=>{c(v.target.value),W()},placeholder:"e.g., Schedule a call for next week, or ask about their budget...",rows:2}),a&&e.jsx("button",{className:"clear-thoughts-btn",onClick:()=>{c(""),P.current&&(P.current.style.height="auto")},title:"Clear",children:e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]})]}),e.jsx("div",{className:"section",children:e.jsxs("label",{className:`service-offer-toggle ${N?"":"disabled"}`,children:[e.jsxs("div",{className:"toggle-left",children:[e.jsx("div",{className:"toggle-icon",children:e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"2",y:"7",width:"20",height:"14",rx:"2",ry:"2"}),e.jsx("path",{d:"M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"})]})}),e.jsxs("div",{className:"toggle-text",children:[e.jsx("span",{className:"toggle-label",children:"Include Service Offer"}),N?e.jsx("span",{className:"toggle-hint",children:"Subtly mention your expertise"}):e.jsx("span",{className:"toggle-hint warning",children:"Configure in Settings first"})]})]}),e.jsx("input",{type:"checkbox",checked:L,onChange:v=>w(v.target.checked),disabled:!N,className:"toggle-checkbox"}),e.jsx("span",{className:`toggle-switch ${L?"active":""}`})]})}),e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Conversation Tone"}),e.jsx("select",{className:"tone-select",value:r,onChange:v=>i(v.target.value),children:ot.map(v=>e.jsx("option",{value:v.value,children:v.label},v.value))})]}),e.jsx("div",{className:"section",children:e.jsx("button",{className:"generate-btn",onClick:oe,disabled:!z||l,children:n?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Analyzing Chat..."]}):l?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Crafting Replies..."]}):t?e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),"Suggest Replies"]}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})}),"Open a Conversation"]})})}),l&&e.jsxs("div",{className:"shimmer-container",children:[e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line long"}),e.jsx("div",{className:"shimmer-line short"})]}),e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line medium"}),e.jsx("div",{className:"shimmer-line long"})]})]}),E&&e.jsxs("div",{className:"error-message",children:[e.jsxs("svg",{className:"error-icon",width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("line",{x1:"12",y1:"8",x2:"12",y2:"12"}),e.jsx("line",{x1:"12",y1:"16",x2:"12.01",y2:"16"})]}),e.jsx("span",{children:E})]}),h.length>0&&!l&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Suggested Replies"}),e.jsx("div",{className:"results",children:h.map((v,A)=>e.jsxs("div",{className:"comment-card",children:[e.jsx("div",{className:"recommendation-tag",children:v.recommendationTag}),e.jsx("div",{className:"comment-text",children:v.text}),e.jsx("div",{className:"comment-actions",children:e.jsxs("div",{className:"action-group",children:[e.jsx("button",{className:`action-btn ${C===A?"copied":""}`,onClick:()=>se(v.text,A),title:"Copy to clipboard",children:C===A?e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})}):e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),e.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]})}),e.jsxs("button",{className:"insert-btn",onClick:()=>s(v.text),title:"Insert into message box",children:[e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})}),"Send"]})]})})]},A))})]})]}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]}):e.jsxs("div",{className:"panel messaging-panel",ref:T,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon messaging",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})})}),e.jsx("span",{children:"Conversation Co-pilot"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"panel-content",children:e.jsxs("div",{className:"no-api-key",children:[e.jsx("div",{className:"no-api-key-icon",children:e.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"})})}),e.jsx("h3",{children:"API Key Required"}),e.jsx("p",{children:"Please configure your API key in the extension settings."}),e.jsx("button",{className:"settings-btn",onClick:re,children:"Open Settings"})]})}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]})}const Ae={"business-mistake":{name:"Business Mistake & Lesson",prompt:"Write a post about a business mistake and lessons learned — in the style of a founder who honestly documents their journey. Format: hook → crisis → solution → key takeaway."}},it=[{value:"professional",label:"Professional"},{value:"raw",label:"Raw/Authentic"},{value:"bold",label:"Bold"}];function at(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}async function lt(t){if(!at())return{success:!1,error:"Extension was updated. Please refresh the page."};try{return await chrome.runtime.sendMessage(t)}catch(n){if(console.error("[PostAssistant] Error sending message:",n),n instanceof Error&&(n.message.includes("Extension context invalidated")||n.message.includes("Receiving end does not exist")))return{success:!1,error:"Extension was updated. Please refresh the page."};throw n}}function ct({onClose:t,onInsertPost:n}){const[o,s]=x.useState("business-mistake"),[r,i]=x.useState(""),[a,c]=x.useState(""),[l,d]=x.useState("raw"),[h,p]=x.useState(!1),[g,S]=x.useState(null),[E,M]=x.useState(null),[m,b]=x.useState(null),C=async()=>{var w;p(!0),b(null),S(null);try{let N="";o==="business-mistake"?N=Ae["business-mistake"].prompt:r.trim()?N=r.trim():N="Write a post about a business mistake and lessons learned — in the style of a founder who honestly documents their journey. Format: hook → crisis → solution → key takeaway.",console.log("[PostAssistant] Sending request:",{topic:N,tone:l,keyPoints:a.trim()||void 0});const I=await lt({type:"generate-post",data:{topic:N,tone:l,keyPoints:a.trim()||void 0}});if(console.log("[PostAssistant] Received response:",I),I.success&&((w=I.data)!=null&&w.post))S(I.data.post),M(I.data.originalPost||I.data.post);else{const z=I.error||"Failed to generate post";console.error("[PostAssistant] Error:",z),b(z)}}catch(N){b(N.message||"An error occurred")}finally{p(!1)}},j=()=>{g&&(n(g),t())},L=w=>{if(!w)return"";const z=(T=>{const k=document.createElement("div");return k.textContent=T,k.innerHTML})(w).split(`
`),P=[];for(let T=0;T<z.length;T++){let k=z[T];const W=k.trim();if(W===""){P.push("<br/>");continue}if(W.startsWith("### ")){P.push(`<h3>${W.substring(4)}</h3>`);continue}if(W.startsWith("## ")){P.push(`<h2>${W.substring(3)}</h2>`);continue}if(W.startsWith("# ")){P.push(`<h1>${W.substring(2)}</h1>`);continue}k=k.replace(/\*\*([^*]+?)\*\*/g,"<strong>$1</strong>"),k=k.replace(/__([^_]+?)__/g,"<strong>$1</strong>"),k=k.replace(new RegExp("(?<!\\*)\\*([^*]+?)\\*(?!\\*)","g"),"<em>$1</em>"),k=k.replace(new RegExp("(?<!_)_([^_]+?)_(?!_)","g"),"<em>$1</em>"),k=k.replace(/#(\w+)/g,'<span style="color: #70b5f9; font-weight: 600;">#$1</span>'),P.push(`<p>${k}</p>`)}return P.join("")};return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"}),e.jsx("circle",{cx:"7.5",cy:"14.5",r:"1.5"}),e.jsx("circle",{cx:"16.5",cy:"14.5",r:"1.5"})]})}),e.jsx("span",{children:"Post Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:t,title:"Close",children:e.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsxs("div",{className:"panel-content",children:[e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Template"}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:[e.jsx("button",{onClick:()=>s("business-mistake"),style:{padding:"12px",background:o==="business-mistake"?"rgba(10, 102, 194, 0.2)":"rgba(255, 255, 255, 0.05)",border:`1px solid ${o==="business-mistake"?"rgba(10, 102, 194, 0.4)":"rgba(255, 255, 255, 0.1)"}`,borderRadius:"10px",color:"#fff",cursor:"pointer",textAlign:"left",fontSize:"13px",fontWeight:o==="business-mistake"?600:400},children:Ae["business-mistake"].name}),e.jsx("button",{onClick:()=>s("custom"),style:{padding:"12px",background:o==="custom"?"rgba(10, 102, 194, 0.2)":"rgba(255, 255, 255, 0.05)",border:`1px solid ${o==="custom"?"rgba(10, 102, 194, 0.4)":"rgba(255, 255, 255, 0.1)"}`,borderRadius:"10px",color:"#fff",cursor:"pointer",textAlign:"left",fontSize:"13px",fontWeight:o==="custom"?600:400},children:"Custom Topic"})]})]}),o==="custom"&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Topic"}),e.jsx("textarea",{className:"thoughts-input",placeholder:"Write about our new update, My thoughts on AI, etc.",value:r,onChange:w=>i(w.target.value),rows:3})]}),e.jsxs("div",{className:"section",children:[e.jsxs("div",{className:"section-label",children:["Key Points ",e.jsx("span",{className:"optional-label",children:"(optional)"})]}),e.jsx("textarea",{className:"thoughts-input",placeholder:"Add context, specific points, or details you want to include in the post...",value:a,onChange:w=>c(w.target.value),rows:3})]}),e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Tone"}),e.jsx("select",{className:"tone-select",value:l,onChange:w=>d(w.target.value),children:it.map(w=>e.jsx("option",{value:w.value,children:w.label},w.value))})]}),e.jsx("button",{className:"generate-btn",onClick:C,disabled:h||o==="custom"&&!r.trim(),children:h?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Generating..."]}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M13 2L3 14h9l-1 8 10-12h-9l1-8z"})}),"Generate Post"]})}),m&&e.jsxs("div",{className:"error-message",children:[e.jsxs("svg",{className:"error-icon",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 8v4M12 16h.01"})]}),e.jsx("span",{children:m})]}),g&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",style:{marginBottom:"12px",fontSize:"14px",fontWeight:600},children:"Generated Post"}),e.jsx("div",{className:"post-preview",style:{maxHeight:"300px",overflowY:"auto",padding:"16px",background:"rgba(255, 255, 255, 0.03)",border:"1px solid rgba(255, 255, 255, 0.1)",borderRadius:"8px",fontSize:"14px",lineHeight:"1.6",color:"#fff",wordWrap:"break-word",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'},dangerouslySetInnerHTML:{__html:L(E||g)}}),e.jsxs("button",{className:"insert-btn",onClick:j,style:{marginTop:"16px",width:"100%",padding:"12px 16px",background:"linear-gradient(135deg, #0a66c2 0%, #004182 100%)",border:"none",borderRadius:"8px",color:"#fff",fontSize:"14px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",transition:"all 0.2s ease"},onMouseEnter:w=>{w.currentTarget.style.background="linear-gradient(135deg, #004182 0%, #0a66c2 100%)",w.currentTarget.style.transform="translateY(-1px)"},onMouseLeave:w=>{w.currentTarget.style.background="linear-gradient(135deg, #0a66c2 0%, #004182 100%)",w.currentTarget.style.transform="translateY(0)"},children:[e.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 5v14M5 12l7-7 7 7"})}),"Insert into Post"]})]})]})]})}function Be(t){const n=document.createElement("button");return n.className="lai-ai-button",n.setAttribute("aria-label","Generate AI Comment"),n.innerHTML=`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
      <circle cx="7.5" cy="14.5" r="1.5"/>
      <circle cx="16.5" cy="14.5" r="1.5"/>
    </svg>
  `,n.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),t()}),n}function Z(t,n){for(const o of n)try{const s=t.querySelector(o);if(s)return s}catch{console.warn(`[LinkedIn AI] Invalid selector: ${o}`)}return null}function X(t,n){const o=[],s=new Set;for(const r of n)try{t.querySelectorAll(r).forEach(a=>{s.has(a)||(s.add(a),o.push(a))})}catch{}return o}function ge(t){let n=t.parentElement;for(;n;){if(n.querySelectorAll('[data-view-name="reaction-button"], [data-view-name="feed-comment-button"], [data-view-name="feed-share-button"], [data-view-name="feed-send-as-message-button"]').length>=3)return n;const s=n.querySelectorAll("button");let r=0;if(s.forEach(i=>{var c;const a=(c=i.textContent)==null?void 0:c.trim();["Like","Comment","Repost","Send"].includes(a||"")&&r++}),r>=3)return n;n=n.parentElement}return null}function dt(){const t=document.querySelectorAll('[data-view-name="feed-full-update"]');return t.length>0?Array.from(t):X(document,[".feed-shared-update-v2",".occludable-update",'[data-urn*="activity"]','[data-urn*="ugcPost"]'])}function ut(t){var r;const n=t.querySelector('[data-view-name="feed-comment-button"]');if(n)return ge(n);const o=t.querySelectorAll("button");for(const i of o)if(((r=i.textContent)==null?void 0:r.trim())==="Comment")return ge(i);const s=t.querySelector('[data-view-name="reaction-button"]');return s?ge(s):Z(t,[".social-actions-button",".feed-shared-social-action-bar",".social-details-social-activity",'[class*="social-actions"]'])}function ht(t){var s,r;const n=t.querySelectorAll('[data-view-name="feed-commentary"]');if(n.length>0){const i=[];let c=n[0].parentElement;for(;c&&c!==t&&!(c.querySelectorAll('[data-view-name="feed-commentary"]').length>=n.length);)c=c.parentElement;if(c&&c!==t){let d=((s=c.textContent)==null?void 0:s.trim())||"";if(d=d.replace(/…?see (more|less)/gi,"").trim(),d=d.replace(/…?\s*more\s*$/gi,"").trim(),d=d.replace(/…?voir (plus|moins)/gi,"").trim(),d=d.replace(/…?ещё/gi,"").trim(),d.length>10)return d}n.forEach(d=>{var p;const h=(p=d.textContent)==null?void 0:p.trim();h&&i.push(h)});const l=i.join(" ").trim();if(l.length>10)return l}const o=Z(t,['[class*="update-components-text"]',".feed-shared-update-v2__description",".feed-shared-text",".feed-shared-inline-show-more-text",".break-words",'[data-test-id="main-feed-activity-card__commentary"]']);if(o){let i=((r=o.textContent)==null?void 0:r.trim())||"";if(i=i.replace(/…?see (more|less)/gi,"").trim(),i=i.replace(/…?voir (plus|moins)/gi,"").trim(),i=i.replace(/…?ещё/gi,"").trim(),i.length>10)return i}return""}function mt(t){const n=t.querySelectorAll('button, span[role="button"]');let o=!1;return n.forEach(s=>{var i;const r=((i=s.textContent)==null?void 0:i.trim().toLowerCase())||"";(r==="more"||r==="...more"||r==="…more"||r.includes("see more")||r.includes("show more")||r.includes("voir plus")||r.includes("mehr anzeigen")||r.includes("ещё")||r.includes("больше"))&&(s.click(),o=!0)}),o||X(t,[".feed-shared-inline-show-more-text__see-more-less-toggle",".see-more",'[data-control-name="see_more"]','button[aria-label*="see more"]','button[aria-label*="Show more"]']).forEach(r=>{r.click(),o=!0}),o}async function pt(t){mt(t)&&await new Promise(o=>setTimeout(o,300))}function gt(t){var i,a,c,l,d,h,p,g,S,E,M,m,b,C;const n=t.querySelector('[data-view-name="feed-actor-image"]');if(n){const j=n.parentElement;if(j){const w=j.querySelectorAll('a[href*="/in/"], a[href*="/company/"]');for(const N of w){if(N===n)continue;const I=(i=N.textContent)==null?void 0:i.trim();if(I&&I.length>=2&&I.length<100)return I.split(`
`)[0].trim()}}const L=(a=n.parentElement)==null?void 0:a.parentElement;if(L){const w=L.querySelectorAll('a[href*="/in/"], a[href*="/company/"]');for(const N of w){if(N===n)continue;const I=N.querySelectorAll("span");for(const P of I){const T=(c=P.textContent)==null?void 0:c.trim();if(T&&T.length>=2&&T.length<80&&!T.includes("•")&&!T.includes("followers"))return T}const z=(h=(d=(l=N.textContent)==null?void 0:l.trim())==null?void 0:d.split(`
`)[0])==null?void 0:h.trim();if(z&&z.length>=2&&z.length<80)return z}}}const o=t.querySelector('[data-view-name="feed-header-text"]');if(o){const j=(S=(g=(p=o.textContent)==null?void 0:p.trim())==null?void 0:g.split(`
`)[0])==null?void 0:S.trim();if(j&&j.length>=2)return j}const s=Z(t,['[class*="update-components-actor__name"]',".feed-shared-actor__name",".feed-shared-actor__title",'a[class*="actor-name"]']);if(s){let j=((E=s.textContent)==null?void 0:E.trim())||"";if(j=j.split(`
`)[0].replace(/View.*profile/gi,"").replace(/•.*$/g,"").trim(),j)return j}const r=(M=t.children[0])==null?void 0:M.children;if(r)for(let j=0;j<Math.min(3,r.length);j++){const L=r[j],w=L==null?void 0:L.querySelector('a[href*="/in/"], a[href*="/company/"]');if(w){const N=(C=(b=(m=w.textContent)==null?void 0:m.trim())==null?void 0:b.split(`
`)[0])==null?void 0:C.trim();if(N&&N.length>=2&&N.length<80)return N}}return"Unknown Author"}function xt(t){var s,r,i,a,c;const n=t.querySelector('[data-view-name="feed-actor-image"]');if(n){const l=(s=n.parentElement)==null?void 0:s.parentElement;if(l){const d=l.querySelectorAll("span");for(const h of d){const p=(r=h.textContent)==null?void 0:r.trim();if(p&&p.length>=5&&p.length<200&&!p.includes("•")&&!p.match(/^\d+[hdwmy]$/)&&!p.match(/^\d+\s*(followers?|connections?)/i)&&!p.includes("Follow")&&!p.includes("Promoted")){const g=(i=n.parentElement)==null?void 0:i.querySelector('a[href*="/in/"], a[href*="/company/"]'),S=(a=g==null?void 0:g.textContent)==null?void 0:a.trim();if(S&&p!==S&&!p.startsWith(S))return p}}}}const o=Z(t,['[class*="update-components-actor__description"]',".feed-shared-actor__description",".feed-shared-actor__sub-description",".update-components-actor__sublabel"]);if(o){let l=((c=o.textContent)==null?void 0:c.trim())||"";if(l=l.split("•")[0].trim(),l=l.replace(/\d+\s*(followers?|connections?)/gi,"").trim(),l)return l}return""}function ft(t){const n=t.querySelectorAll('[data-view-name="feed-update-image"] img, [data-view-name="image"] img');for(const r of n){const i=r;if(i.closest('[data-view-name="feed-actor-image"]')||i.closest('[data-view-name="feed-header-actor-image"]'))continue;const a=i.src||i.getAttribute("data-delayed-url")||i.getAttribute("data-src");if(!a||a.startsWith("data:")||a.includes("/icons/")||a.includes("ghost-organization")||a.includes("ghost-person"))continue;const c=i.naturalWidth||i.width,l=i.naturalHeight||i.height;if(!(c&&l&&(c<100||l<100)))return a}const o=t.querySelectorAll("img");for(const r of o){const i=r;if(i.closest('[data-view-name="feed-actor-image"]')||i.closest('[data-view-name="feed-header-actor-image"]')||i.closest('[data-view-name="identity-module"]'))continue;const a=i.src||i.getAttribute("data-delayed-url");if(!a||a.startsWith("data:")||a.includes("/icons/")||a.includes("ghost-")||a.includes("logo"))continue;const c=i.naturalWidth||i.width,l=i.naturalHeight||i.height;if(c&&l&&(c<100||l<100))continue;const d=i.getBoundingClientRect();if(d.width>150&&d.height>100)return a}const s=[".update-components-image__image",".feed-shared-image__image",".ivm-view-attr__img--centered",'[class*="update-components-image"] img',"img[data-delayed-url]"];for(const r of s){const i=t.querySelectorAll(r);for(const a of i){const c=a;if(c.closest('.feed-shared-actor, [class*="actor"]'))continue;const l=c.src||c.getAttribute("data-delayed-url");if(l&&!l.startsWith("data:")&&!l.includes("/icons/"))return l}}}function Le(){return X(document,['[role="textbox"][contenteditable="true"]','.ql-editor[contenteditable="true"]','[data-placeholder="Add a comment…"]','[data-placeholder="Add a comment..."]','[aria-placeholder="Add a comment…"]','[aria-placeholder="Add a comment..."]','[contenteditable="true"][aria-label*="comment" i]','[contenteditable="true"][aria-label*="reply" i]','.editor-content [contenteditable="true"]']).find(s=>{const r=s.getBoundingClientRect();return r.width>0&&r.height>0})||null}function bt(t,n){try{const o=t.querySelectorAll('a[data-attribute-index], span[data-mention], [class*="mention"], a[href*="/in/"]'),s=[];o.forEach(h=>{s.push(h.cloneNode(!0))});const i=(t.textContent||"").match(/^(@[\w\s]+)\s*/),a=i?i[1]:null;t.innerHTML="",s.length>0?s.forEach(h=>{t.appendChild(h),t.appendChild(document.createTextNode(" "))}):a&&t.appendChild(document.createTextNode(a+" "));const c=document.createElement("p");c.textContent=n,t.appendChild(c),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:n})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0})),t.focus();const l=window.getSelection(),d=document.createRange();return d.selectNodeContents(t),d.collapse(!1),l==null||l.removeAllRanges(),l==null||l.addRange(d),!0}catch(o){return console.error("[LinkedIn AI] Failed to inject text:",o),!1}}function vt(t){var r,i,a,c,l,d,h,p;const n=t.querySelectorAll('a[href*="/in/"]');for(const g of n){if(g.closest('[data-view-name="feed-commentary"]'))continue;const E=g.querySelector('span[aria-hidden="true"]');if(E){const b=(r=E.textContent)==null?void 0:r.trim();if(b&&b.length>=2&&b.length<100)return b}const M=g.querySelectorAll("span");for(const b of M){const C=(i=b.textContent)==null?void 0:i.trim();if(C&&C.length>=2&&C.length<80&&!C.includes("•")&&!C.includes("1st")&&!C.includes("2nd")&&!C.includes("3rd"))return C}const m=(l=(c=(a=g.textContent)==null?void 0:a.trim())==null?void 0:c.split(`
`)[0])==null?void 0:l.trim();if(m&&m.length>=2&&m.length<80&&!m.includes("•"))return m}const s=Z(t,[".comments-post-meta__name-text",".comments-post-meta__name",'[class*="comments-post-meta__name"]']);if(s){const g=(p=(h=(d=s.textContent)==null?void 0:d.trim())==null?void 0:h.split(`
`)[0])==null?void 0:p.trim();if(g&&g.length>=2)return g}return"Unknown"}function fe(t){var n,o,s,r,i,a;try{if((((n=t.textContent)==null?void 0:n.trim())||"").length<10)return null;const l=vt(t),d=t.querySelector('[data-view-name="feed-commentary"]');let h="";if(d){let g=d.parentElement;g?h=((o=g.textContent)==null?void 0:o.trim())||((s=d.textContent)==null?void 0:s.trim())||"":h=((r=d.textContent)==null?void 0:r.trim())||""}if(!h){const g=Z(t,[".comments-comment-item__main-content",'[class*="comment-item__main-content"]',".comments-comment-item-content-body",".update-components-text"]);h=((i=g==null?void 0:g.textContent)==null?void 0:i.trim())||""}if(h=h.replace(/…?see (more|less)/gi,"").trim(),h=h.replace(/…?voir (plus|moins)/gi,"").trim(),!h||h.length<5)return null;const p=!!t.closest('[class*="replies-list"]')||!!((a=t.parentElement)!=null&&a.closest('[class*="replies"]'));return{authorName:l,authorHeadline:"",content:h,isReply:p}}catch(c){return console.error("[LinkedIn AI] Error extracting comment:",c),null}}function Re(t){const n=X(t,[".comments-comment-item",".comments-comment-entity",'article[class*="comments-comment-item"]']);if(n.length>0)return n;const o=Array.from(t.querySelectorAll("button")).filter(i=>{var c;return((c=i.textContent)==null?void 0:c.trim())==="Reply"}),s=[],r=new Set;for(const i of o){let a=i.parentElement;for(let c=0;c<6&&a;c++){const l=a.querySelector('a[href*="/in/"]'),d=a.querySelector('[data-view-name="feed-commentary"]');if(l&&(d||a.textContent.length>20)){r.has(a)||(r.add(a),s.push(a));break}a=a.parentElement}}return s}function yt(t,n=5){const o=[],s=new Set,r=Re(t);for(const i of r){if(o.length>=n)break;if(!t.contains(i))continue;const a=fe(i);if(a&&a.content.length>5){const c=a.content.slice(0,50).toLowerCase();s.has(c)||(s.add(c),o.push(a))}}return o}function wt(t){var a;const n=Le();if(!n)return{isReply:!1,parentComment:null,threadParticipants:[]};const o=n.closest('[class*="replies-list"], [class*="replies"]');if(!o)return{isReply:!1,parentComment:null,threadParticipants:[]};let s=null;const r=[],i=Re(t);for(const c of i)if(c.contains(o)){s=fe(c),s&&r.push(s.authorName);break}if(!s){const c=n.querySelector('a[href*="/in/"], [data-mention]');if(c){const l=(a=c.textContent)==null?void 0:a.trim();if(l)for(const d of i){const h=fe(d);if(h&&h.authorName.includes(l.replace("@",""))){s=h,r.push(h.authorName);break}}}}return{isReply:!0,parentComment:s,threadParticipants:r}}function jt(t){const n=t.closest('[data-view-name="feed-full-update"]');if(n)return n;const o=[".feed-shared-update-v2",".occludable-update",'[data-urn*="activity"]','[data-urn*="ugcPost"]'];for(const s of o){const r=t.closest(s);if(r)return r}return t}function kt(t){if(t.closest('.comments-comment-item, .comments-comment-entity, [class*="comments-comment-item"]'))return!0;const o=t.parentElement;if(o&&Array.from(o.querySelectorAll("button")).find(i=>{var a;return((a=i.textContent)==null?void 0:a.trim())==="Reply"}))return!0;let s=t.parentElement;for(let r=0;r<4&&s;r++){const i=s.querySelectorAll("button");let a=!1,c=!1;if(i.forEach(l=>{var h,p;const d=(h=l.textContent)==null?void 0:h.trim();d==="Reply"&&(a=!0),d==="Like"&&!((p=l.getAttribute("data-view-name"))!=null&&p.includes("reaction"))&&(c=!0)}),a&&c)return!0;s=s.parentElement}return!1}async function Ct(t){try{const n=jt(t);if(!n)return console.warn("[LinkedIn AI] Could not find main post container"),null;const o=kt(t),s=gt(n),r=xt(n);await pt(n);const i=ht(n);if(!i)return console.warn("[LinkedIn AI] Could not extract post content"),null;const a=ft(n),c=yt(n,5);let l;const d=[];if(o){const p=wt(n);l=p.parentComment||void 0,d.push(...p.threadParticipants)}for(const p of c)d.includes(p.authorName)||d.push(p.authorName);const h={mode:o?"reply":"post",parentComment:l,existingComments:c,threadParticipants:d};return console.log("[LinkedIn AI] Scraped data:",{authorName:s,authorHeadline:r,postContentLength:i.length,hasImage:!!a,isReplyMode:o,parentComment:l==null?void 0:l.authorName,existingCommentsCount:c.length}),{authorName:s,authorHeadline:r,postContent:i,imageUrl:a,threadContext:h}}catch(n){return console.error("[LinkedIn AI] Error scraping post data:",n),null}}function me(){return X(document,['[role="dialog"][aria-label*="Start a post" i]','[role="dialog"][aria-label*="Create a post" i]','[role="dialog"][aria-label*="post" i]','[data-view-name*="share"]',".share-box-feed-entry__modal",".share-box__modal",".artdeco-modal",'[class*="share-box"]','[class*="share-modal"]']).find(s=>{const r=s.getBoundingClientRect();return r.width>0&&r.height>0})||null}function je(){const t=['[role="textbox"][contenteditable="true"]','.ql-editor[contenteditable="true"]','[data-placeholder*="What do you want to talk about"]','[aria-placeholder*="What do you want to talk about"]','[contenteditable="true"][aria-label*="post" i]','[contenteditable="true"][aria-label*="Text editor" i]',".ql-container .ql-editor"],n=me();if(n){const r=X(n,t);if(r.length>0){const i=r.find(a=>{const c=a.getBoundingClientRect();return c.width>0&&c.height>0});if(i)return i}}return X(document,t).find(r=>{const i=r.getBoundingClientRect();return i.width>0&&i.height>0})||null}function Nt(){var s;const t=me();if(!t)return null;const o=X(t,[".share-box__toolbar",".share-box-feed-entry__toolbar",".share-box__footer",".share-creation-state__toolbar",'[class*="share-box"][class*="toolbar"]','[class*="share-box"][class*="footer"]',".artdeco-modal__actionbar"]);if(o.length===0){const r=t.querySelectorAll("button");for(const i of r){const a=((s=i.getAttribute("aria-label"))==null?void 0:s.toLowerCase())||"";if(a.includes("photo")||a.includes("video")||a.includes("media"))return i.parentElement}}return o[0]||null}function St(t,n){try{t.innerHTML="";const o=document.createElement("p");o.textContent=n,t.appendChild(o),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:n})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0})),t.focus();const s=window.getSelection(),r=document.createRange();return r.selectNodeContents(t),r.collapse(!1),s==null||s.removeAllRanges(),s==null||s.addRange(r),!0}catch(o){return console.error("[LinkedIn AI] Failed to inject text into post editor:",o),!1}}function Mt(){const t=window.getSelection();return(t==null?void 0:t.toString().trim())||""}function At(){const t=Mt();return!t||t.length<10?null:{authorName:"Selected Text",authorHeadline:"",postContent:t,threadContext:{mode:"post",existingComments:[],threadParticipants:[]}}}const Y={messageItem:[".msg-s-message-list__event",".msg-s-event-listitem",'[class*="msg-s-event-listitem"]'],messageContent:[".msg-s-event-listitem__body",".msg-s-message-group__content",'[class*="msg-s-event-listitem__body"]',"p.msg-s-event-listitem__body"],messageTimestamp:[".msg-s-message-list__time-heading",".msg-s-message-group__timestamp","time"],participantName:[".msg-overlay-bubble-header__title",".msg-thread__link-to-profile",".msg-entity-lockup__entity-title",'[class*="msg-overlay-bubble-header__title"]',"h2.msg-entity-lockup__entity-title"],participantHeadline:[".msg-entity-lockup__entity-subtitle",".msg-overlay-bubble-header__subtitle",'[class*="msg-entity-lockup__entity-subtitle"]'],messageInput:[".msg-form__contenteditable",".msg-form__message-texteditor",'[contenteditable="true"][role="textbox"]',"div.msg-form__contenteditable"],myMessageIndicator:[".msg-s-message-group--selfsend",'[class*="selfsend"]']};function ne(t,n){for(const o of n){const s=t.querySelector(o);if(s)return s}return null}function Et(t,n){for(const o of n){const s=t.querySelectorAll(o);if(s.length>0)return Array.from(s)}return[]}function he(){return window.location.pathname.includes("/messaging")}function It(){const t=document.querySelector(".global-nav__me-photo, .feed-identity-module__actor-meta"),n=t==null?void 0:t.getAttribute("alt");if(n)return n;const o=document.querySelector(".global-nav__me .t-14");return o!=null&&o.textContent?o.textContent.trim():"Me"}function ze(){var o,s;const t=ne(document,Y.participantName),n=ne(document,Y.participantHeadline);return{name:((o=t==null?void 0:t.textContent)==null?void 0:o.trim())||"Unknown",headline:((s=n==null?void 0:n.textContent)==null?void 0:s.trim())||void 0}}function _t(t){const n=t.closest(".msg-s-message-group");if(n){for(const o of Y.myMessageIndicator)if(n.matches(o)||n.querySelector(o))return!0}for(const o of Y.myMessageIndicator)if(t.matches(o)||t.closest(o))return!0;return!1}function Pt(t=10){var a,c;const n=[],o=It(),s=ze(),i=Et(document,Y.messageItem).slice(-t);for(const l of i){const d=ne(l,Y.messageContent),h=(a=d==null?void 0:d.textContent)==null?void 0:a.trim();if(!h||h.length<2)continue;const p=_t(l),g=ne(l,Y.messageTimestamp),S=(c=g==null?void 0:g.textContent)==null?void 0:c.trim();n.push({sender:p?"me":"other",senderName:p?o:s.name,content:h,timestamp:S})}return n}function Tt(t){if(t.length===0)return"neutral";const o=t.slice(-5).map(d=>d.content.toLowerCase()).join(" "),r=["great","awesome","thanks","thank you","excellent","love","excited","looking forward","happy","pleased"].some(d=>o.includes(d)),a=["price","cost","budget","deal","offer","proposal","terms","negotiate","discount","rate"].some(d=>o.includes(d)),c=t[t.length-1],l=c.sender==="me";return c.content.length<20,a?"negotiating":r?"positive":l&&t.length>3?"cold":"neutral"}function Bt(t){if(t.length===0)return"General conversation";const n=t.map(s=>s.content).join(" ").toLowerCase(),o=[{pattern:/job|position|opportunity|hiring|role|career/i,topic:"Job opportunity discussion"},{pattern:/project|collaboration|partner|work together/i,topic:"Collaboration proposal"},{pattern:/service|solution|help|consulting/i,topic:"Business services"},{pattern:/meeting|call|schedule|calendar|zoom|coffee/i,topic:"Scheduling a meeting"},{pattern:/price|cost|budget|quote|proposal/i,topic:"Pricing negotiation"},{pattern:/connect|networking|intro|introduction/i,topic:"Networking"},{pattern:/question|help|advice|recommend/i,topic:"Seeking advice"},{pattern:/follow.?up|checking in|touch base/i,topic:"Follow-up conversation"}];for(const{pattern:s,topic:r}of o)if(s.test(n))return r;return"Professional discussion"}async function Lt(){try{if(!he())return console.log("[LinkedIn AI] Not on messaging page"),null;const t=ze(),n=Pt(10);if(n.length===0)return console.log("[LinkedIn AI] No messages found in conversation"),null;const o=n[n.length-1],s=Bt(n),r=Tt(n);return console.log("[LinkedIn AI] Scraped conversation:",{participant:t.name,messageCount:n.length,topic:s,sentiment:r,lastMessageFrom:o.sender}),{participantName:t.name,participantHeadline:t.headline,messages:n,topic:s,sentiment:r,lastMessageFrom:o.sender}}catch(t){return console.error("[LinkedIn AI] Error scraping conversation:",t),null}}function Rt(){return ne(document,Y.messageInput)}function zt(t){const n=Rt();if(!n)return console.error("[LinkedIn AI] Message input not found"),!1;try{n.focus(),n.innerHTML="";const o=document.createElement("p");return o.textContent=t,n.appendChild(o),n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0})),setTimeout(()=>{n.innerText=t,n.dispatchEvent(new Event("input",{bubbles:!0}))},50),!0}catch(o){return console.error("[LinkedIn AI] Error injecting text:",o),!1}}const Wt=`
  .lai-ai-button {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(10, 102, 194, 0.3);
    margin-left: 8px;
  }
  
  .lai-ai-button:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(10, 102, 194, 0.4);
  }
  
  .lai-ai-button:active {
    transform: scale(0.95);
  }
  
  .lai-ai-button svg {
    width: 18px;
    height: 18px;
    color: white;
  }

  .lai-ai-button::after {
    content: 'AI Comment';
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%) scale(0.9);
    padding: 6px 10px;
    background: #1a1a2e;
    color: white;
    font-size: 12px;
    font-weight: 500;
    border-radius: 6px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }

  .lai-ai-button::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    border: 6px solid transparent;
    border-top-color: #1a1a2e;
    opacity: 0;
    pointer-events: none;
    transition: all 0.2s ease;
  }

  .lai-ai-button:hover::after,
  .lai-ai-button:hover::before {
    opacity: 1;
    transform: translateX(-50%) scale(1);
  }

  .lai-ai-button:hover::before {
    transform: translateX(-50%);
  }

  .lai-selection-btn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 16px;
    background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
    border: none;
    border-radius: 12px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(10, 102, 194, 0.4);
    z-index: 999998;
    transition: all 0.2s ease;
  }

  .lai-selection-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 24px rgba(10, 102, 194, 0.5);
  }

  .lai-selection-btn svg {
    width: 18px;
    height: 18px;
  }

  /* Messaging AI Button */
  .lai-messaging-ai-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 6px rgba(10, 102, 194, 0.25);
    margin: 0 4px;
    flex-shrink: 0;
    vertical-align: middle;
  }
  
  .lai-messaging-ai-button:hover {
    transform: scale(1.1);
    box-shadow: 0 3px 10px rgba(10, 102, 194, 0.4);
    background: linear-gradient(135deg, #004182 0%, #0066a2 100%);
  }
  
  .lai-messaging-ai-button:active {
    transform: scale(0.95);
  }
  
  .lai-messaging-ai-button svg {
    width: 16px;
    height: 16px;
    color: white;
  }

  /* Post Assistant Sparkle Button */
  .lai-post-sparkle-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 8px;
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%);
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
    margin: 0 4px;
    flex-shrink: 0;
  }
  
  .lai-post-sparkle-button:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
    background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%);
  }
  
  .lai-post-sparkle-button:active {
    transform: scale(0.95);
  }
  
  .lai-post-sparkle-button svg {
    width: 18px;
    height: 18px;
    color: white;
  }
`;let q=null,K=null,G=null,ke=null;function qt(){if(document.getElementById("lai-content-styles"))return;const t=document.createElement("style");t.id="lai-content-styles",t.textContent=Wt,document.head.appendChild(t)}function J(){if(K)return K;K=document.createElement("div"),K.id="lai-panel-container";const t=K.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=Zt(),t.appendChild(n);const o=document.createElement("div");return o.id="lai-panel-mount",t.appendChild(o),document.body.appendChild(K),K}function ue(t,n){const r=J().shadowRoot.getElementById("lai-panel-mount");q||(q=ye.createRoot(r)),q.render(e.jsx(we.StrictMode,{children:e.jsx(nt,{postData:t,isScanning:n,onClose:U,onInsertComment:Ut})}))}function xe(t,n){const r=J().shadowRoot.getElementById("lai-panel-mount");q||(q=ye.createRoot(r)),q.render(e.jsx(we.StrictMode,{children:e.jsx(rt,{conversationContext:t,isScanning:n,onClose:U,onInsertReply:Ft})}))}function Ht(){const o=J().shadowRoot.getElementById("lai-panel-mount");q||(q=ye.createRoot(o)),q.render(e.jsx(we.StrictMode,{children:e.jsx(ct,{onClose:U,onInsertPost:$t})}))}function Ft(t){zt(t)&&U()}function $t(t){const n=je();n?St(n,t)&&U():navigator.clipboard.writeText(t).then(()=>{alert("Post copied to clipboard! Paste it into the post editor."),U()}).catch(()=>{console.error("[LinkedIn AI] Failed to copy to clipboard")})}function Vt(){J(),Ht()}function Ot(){J(),xe(null,!0),(async()=>{await new Promise(n=>setTimeout(n,200));const t=await Lt();xe(t||null,!1)})()}function Gt(t){var r;const n=['[role="textbox"][contenteditable="true"]','[contenteditable="true"][aria-label*="comment" i]','[contenteditable="true"][aria-label*="reply" i]','[aria-placeholder="Add a comment…"]','[aria-placeholder="Add a comment..."]','[data-placeholder="Add a comment…"]','[data-placeholder="Add a comment..."]','.ql-editor[contenteditable="true"]',".comments-comment-box__form-container .ql-editor",".comments-comment-texteditor .ql-editor",'.editor-content [contenteditable="true"]'];for(const i of n){const a=t.querySelectorAll(i);for(const c of a){const l=c.getBoundingClientRect();if(l.width>0&&l.height>0)return c}}const o=[],s=t.getBoundingClientRect();for(const i of n){const a=document.querySelectorAll(i);for(const c of a){const l=c.getBoundingClientRect();if(l.width>0&&l.height>0){const d=Math.abs(l.top-s.top);o.push({box:c,distance:d})}}}return o.sort((i,a)=>i.distance-a.distance),((r=o[0])==null?void 0:r.box)||null}function Yt(t,n=!1){J(),ue(null,!0),Ce(),(async()=>{const o=n?400:100;await new Promise(r=>setTimeout(r,o)),ke=Gt(t);const s=await Ct(t);s?ue(s,!1):(ue(null,!1),Kt())})()}function Xt(t){J();const n={...t,threadContext:t.threadContext||{mode:"post",existingComments:[],threadParticipants:[]}};ue(n,!1),Ce()}function U(){q&&(q.unmount(),q=null),ke=null}function Ut(t){let n=ke;if(n){const o=n.getBoundingClientRect();(!document.body.contains(n)||o.width===0&&o.height===0)&&(n=null)}if(n||(n=Le()),n&&bt(n,t)){U();return}navigator.clipboard.writeText(t).then(()=>{alert("Comment copied to clipboard! Paste it into the comment box."),U()}).catch(()=>{console.error("[LinkedIn AI] Failed to copy to clipboard")})}function We(t,n=!1){Yt(t,n)}function Kt(){G||(G=document.createElement("button"),G.className="lai-selection-btn",G.innerHTML=`
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M4 7V4h16v3"/>
      <path d="M9 20h6"/>
      <path d="M12 4v16"/>
    </svg>
    Analyze Selected Text
  `,G.addEventListener("click",()=>{const t=At();t?(Xt(t),Ce()):alert("Please highlight some text from a LinkedIn post first.")}),document.body.appendChild(G))}function Ce(){G&&(G.remove(),G=null)}function be(){dt().forEach(n=>{const o=n;if(o.dataset.laiProcessed)return;o.dataset.laiProcessed="true";const s=ut(n);if(s){const r=Array.from(s.querySelectorAll("button")).some(a=>{var c;return((c=a.textContent)==null?void 0:c.trim())==="Reply"});if(s.closest('.comments-comment-item, .comments-comment-entity, [class*="comments-comment-item"], .comments-comments-list')||r)return;if(!s.querySelector(".lai-ai-button")){const a=Be(()=>{We(a,!1)});s.appendChild(a)}}qe(n)})}function Jt(t){var s,r;const n=t.querySelectorAll('button, span[role="button"]');for(const i of n)if(((s=i.textContent)==null?void 0:s.trim())==="Reply"){i.click(),console.log("[LinkedIn AI] Clicked Reply button (by text)");return}const o=(r=t.querySelector('button[aria-label*="Reply"], button[aria-label*="reply"], [class*="reply-action"], .comments-comment-social-bar__reply-action'))==null?void 0:r.closest("button");o&&(o.click(),console.log("[LinkedIn AI] Clicked Reply button (by selector)"))}function qe(t){const n=t.querySelectorAll('.comments-comment-item, .comments-comment-entity, article[class*="comments-comment"]');if(n.length>0){n.forEach(s=>{Ee(s)});return}const o=Array.from(t.querySelectorAll("button")).filter(s=>{var r;return((r=s.textContent)==null?void 0:r.trim())==="Reply"});for(const s of o){let r=s.parentElement;for(let i=0;i<6&&r;i++){const a=r.querySelector('a[href*="/in/"]'),c=r.querySelector('[data-view-name="feed-commentary"]');if(a&&(c||r.textContent.length>20)){Ee(r,s);break}r=r.parentElement}}}function Ee(t,n){var r;const o=t;if(o.dataset.laiCommentProcessed)return;o.dataset.laiCommentProcessed="true";let s=null;if(n){s=n.parentElement;let i=n.parentElement;for(let a=0;a<3&&i;a++){const c=i.querySelectorAll("button");let l=!1,d=!1;if(c.forEach(h=>{var g;const p=(g=h.textContent)==null?void 0:g.trim();p==="Like"&&(l=!0),p==="Reply"&&(d=!0)}),l&&d){s=i;break}i=i.parentElement}}if(!s){const i=[".comments-comment-social-bar",'[class*="comment-social-bar"]',".comments-comment-item__action-bar"];for(const a of i)if(s=t.querySelector(a),s)break}if(!s){const i=t.querySelectorAll("button");for(const a of i){const c=(r=a.textContent)==null?void 0:r.trim();if(c==="Reply"||c==="Like"){s=a.parentElement;break}}}if(s&&!s.querySelector(".lai-ai-button")){const i=Be(()=>{Jt(t),setTimeout(()=>{We(i,!0)},300)});i.style.width="28px",i.style.height="28px",i.style.marginLeft="4px",s.appendChild(i)}}function Qt(){document.querySelectorAll('[data-view-name="feed-full-update"], .feed-shared-update-v2, .occludable-update, [data-urn*="activity"]').forEach(n=>{qe(n)})}function de(){const t=document.createElement("button");return t.className="lai-post-sparkle-button",t.setAttribute("aria-label","AI Post Assistant"),t.title="AI Post Assistant",t.innerHTML=`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
      <circle cx="7.5" cy="14.5" r="1.5"/>
      <circle cx="16.5" cy="14.5" r="1.5"/>
    </svg>
  `,t.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Vt()}),t}function Q(){const t=me();if(document.querySelector(".lai-post-sparkle-button"))return;let n=Nt();if(!n){const s=[".share-box__toolbar",".share-box-feed-entry__toolbar",".share-box__footer",".share-creation-state__toolbar",".share-box__actions",".share-box-feed-entry__actions",".artdeco-modal__actionbar",'[class*="share-box"][class*="toolbar"]','[class*="share-box"][class*="footer"]','[class*="share-box"][class*="actions"]'];for(const r of s){const i=document.querySelector(r);if(i){const a=i.getBoundingClientRect();if(a.width>0&&a.height>0){n=i;break}}}}if(n){const s=de();n.insertBefore(s,n.firstChild),console.log("[LinkedIn AI] Post Assistant button injected into toolbar");return}const o=je();if(o&&o.parentElement){let s=o.parentElement;for(let r=0;r<3;r++)if(s){const i=s.querySelector('[class*="toolbar"], [class*="footer"], [class*="actions"], [class*="button"]');if(i){const a=de();i.insertBefore(a,i.firstChild),console.log("[LinkedIn AI] Post Assistant button injected near editor");return}s=s.parentElement}if(o.parentElement){const r=de();o.parentElement.insertBefore(r,o.nextSibling),console.log("[LinkedIn AI] Post Assistant button injected after editor");return}}if(t){const s=de();s.style.position="absolute",s.style.top="10px",s.style.right="10px",s.style.zIndex="10000",t.appendChild(s),console.log("[LinkedIn AI] Post Assistant button injected as absolute positioned")}}function ve(){const t=[".msg-form__footer",".msg-form__left-actions",".msg-form__content-container",".msg-form"];let n=null;for(const a of t)if(n=document.querySelector(a),n)break;if(!n){console.log("[LinkedIn AI] Message form footer not found");return}if(document.querySelector(".lai-messaging-ai-button"))return;const o=document.createElement("button");o.className="lai-messaging-ai-button",o.type="button",o.title="AI Reply Assistant",o.innerHTML=`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
    </svg>
  `,o.addEventListener("click",a=>{a.preventDefault(),a.stopPropagation(),Ot()});const s=document.querySelector(".msg-form__left-actions");if(s){s.insertBefore(o,s.firstChild),console.log("[LinkedIn AI] Messaging AI button injected into left actions");return}const r=document.querySelector(".msg-form__footer");if(r){r.insertBefore(o,r.firstChild),console.log("[LinkedIn AI] Messaging AI button injected into footer");return}const i=document.querySelector('.msg-form__send-button, .msg-form__send-btn, button[type="submit"][class*="send"]');if(i&&i.parentElement){i.parentElement.insertBefore(o,i),console.log("[LinkedIn AI] Messaging AI button injected before send button");return}console.log("[LinkedIn AI] Could not find suitable location for messaging button")}function Ie(){qt(),he()?ve():be(),Q(),setInterval(()=>{(me()||je())&&Q()},500);let n=null;const o=()=>{n&&clearTimeout(n),n=setTimeout(()=>{he()?ve():(be(),Qt()),Q()},300)};new MutationObserver(r=>{let i=!1,a=!1;r.forEach(c=>{c.addedNodes.length>0&&(c.addedNodes.forEach(l=>{var d,h,p,g,S,E,M,m,b;l instanceof Element&&(((h=(d=l.getAttribute)==null?void 0:d.call(l,"data-view-name"))!=null&&h.includes("feed")||(p=l.querySelector)!=null&&p.call(l,'[data-view-name="feed-full-update"]')||(g=l.querySelector)!=null&&g.call(l,'[data-view-name="feed-comment-button"]')||(S=l.querySelector)!=null&&S.call(l,"button"))&&(i=!0),((E=l.matches)!=null&&E.call(l,'.comments-comment-item, .comments-comment-entity, [class*="comment"], .feed-shared-update-v2')||(M=l.querySelector)!=null&&M.call(l,".comments-comment-item, .comments-comment-entity"))&&(i=!0),((m=l.matches)!=null&&m.call(l,'[role="dialog"], .artdeco-modal, [class*="share-box"], [class*="share-modal"]')||(b=l.querySelector)!=null&&b.call(l,'[role="dialog"][aria-label*="post" i], .artdeco-modal, [class*="share-box"]'))&&(a=!0))}),i=!0)}),i&&o(),a&&(setTimeout(()=>Q(),100),setTimeout(()=>Q(),500),setTimeout(()=>Q(),1e3))}).observe(document.body,{childList:!0,subtree:!0})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Ie):Ie();let _e=location.href;new MutationObserver(()=>{location.href!==_e&&(_e=location.href,setTimeout(()=>{he()?ve():be()},1e3))}).observe(document,{subtree:!0,childList:!0});function Zt(){return`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    .panel {
      position: fixed;
      top: 80px;
      right: 20px;
      width: 400px;
      max-height: calc(100vh - 100px);
      background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
      border-radius: 16px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      color: #fff;
      z-index: 999999;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(30px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateX(0) scale(1);
      }
    }
    
    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      background: rgba(255, 255, 255, 0.02);
      cursor: move;
      flex-shrink: 0;
    }
    
    .panel-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: 14px;
    }
    
    .panel-icon {
      width: 32px;
      height: 32px;
      border-radius: 8px;
      background: linear-gradient(135deg, #0a66c2 0%, #00a0dc 100%);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .panel-icon svg {
      width: 18px;
      height: 18px;
      color: white;
    }

    .panel-icon.messaging {
      background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%);
    }

    /* Messaging Context Styles */
    .messaging-context {
      padding: 12px 16px;
      background: rgba(124, 58, 237, 0.1);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .context-scanning {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #a78bfa;
      font-size: 13px;
    }

    .context-participant {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
    }

    .context-label {
      font-size: 11px;
      color: #9ca3af;
    }

    .context-value {
      font-size: 14px;
      font-weight: 600;
      color: #f3f4f6;
    }

    .context-headline {
      font-size: 12px;
      color: #9ca3af;
      margin-bottom: 8px;
    }

    .context-stats {
      display: flex;
      gap: 12px;
      margin-top: 8px;
    }

    .context-stats .stat {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      color: #9ca3af;
    }

    .sentiment-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #6b7280;
    }

    .sentiment-dot.positive {
      background: #22c55e;
    }

    .sentiment-dot.neutral {
      background: #eab308;
    }

    .sentiment-dot.negotiating {
      background: #f97316;
    }

    .sentiment-dot.cold {
      background: #6b7280;
    }

    .ai-summary {
      margin-top: 10px;
      padding: 10px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 8px;
      border-left: 3px solid #a855f7;
    }

    .summary-topic {
      font-size: 12px;
      font-weight: 500;
      color: #e5e7eb;
      margin-bottom: 6px;
    }

    .summary-action {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: #a78bfa;
    }

    .context-empty {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 16px;
      color: #6b7280;
      font-size: 13px;
      text-align: center;
    }

    .context-empty svg {
      opacity: 0.5;
    }
    
    .close-btn {
      width: 28px;
      height: 28px;
      border-radius: 6px;
      border: none;
      background: rgba(255, 255, 255, 0.1);
      color: #9ca3af;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }
    
    .close-btn:hover {
      background: rgba(239, 68, 68, 0.2);
      color: #ef4444;
    }

    /* Tabs */
    .tabs {
      display: flex;
      padding: 0 12px;
      background: rgba(0, 0, 0, 0.2);
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      flex-shrink: 0;
    }

    .tab {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 12px 16px;
      border: none;
      background: transparent;
      color: #6b7280;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      border-bottom: 2px solid transparent;
      margin-bottom: -1px;
    }

    .tab:hover {
      color: #9ca3af;
    }

    .tab.active {
      color: #0a66c2;
      border-bottom-color: #0a66c2;
    }

    .tab svg {
      opacity: 0.7;
    }

    .tab.active svg {
      opacity: 1;
    }

    /* Reply Mode Indicator */
    .reply-mode-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 16px;
      background: linear-gradient(90deg, rgba(139, 92, 246, 0.15) 0%, rgba(139, 92, 246, 0.05) 100%);
      border-bottom: 1px solid rgba(139, 92, 246, 0.2);
      font-size: 12px;
      color: #a78bfa;
      font-weight: 500;
    }

    .reply-mode-indicator svg {
      flex-shrink: 0;
    }

    .reply-to-name {
      color: #c4b5fd;
      font-weight: 600;
      margin-left: 4px;
    }

    /* Context Awareness Section */
    .context-awareness {
      background: rgba(0, 0, 0, 0.25);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding: 12px 16px;
    }

    .context-header {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
      margin-bottom: 12px;
    }

    .context-header svg {
      color: #6b7280;
    }

    .scanning-badge {
      margin-left: auto;
      padding: 2px 8px;
      background: rgba(59, 130, 246, 0.2);
      border: 1px solid rgba(59, 130, 246, 0.3);
      border-radius: 10px;
      font-size: 9px;
      color: #60a5fa;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      animation: pulse 1.5s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    .context-timeline {
      display: flex;
      flex-direction: column;
      gap: 0;
      position: relative;
    }

    .context-item {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      padding: 8px 0;
      position: relative;
    }

    .context-item-line {
      position: absolute;
      left: 5px;
      top: 22px;
      bottom: -8px;
      width: 2px;
      background: rgba(255, 255, 255, 0.1);
    }

    .context-item:last-child .context-item-line {
      display: none;
    }

    .context-item-icon {
      width: 12px;
      height: 12px;
      margin-top: 2px;
      flex-shrink: 0;
      color: #6b7280;
      position: relative;
      z-index: 1;
    }

    .context-item.success .context-item-icon {
      color: #4ade80;
    }

    .context-item.warning .context-item-icon {
      color: #fbbf24;
    }

    .context-item.scanning .context-item-icon {
      color: #60a5fa;
    }

    .context-item-content {
      flex: 1;
      min-width: 0;
    }

    .context-item-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 2px;
    }

    .context-item-label {
      font-size: 11px;
      font-weight: 600;
      color: #e5e7eb;
    }

    .context-status {
      width: 14px;
      height: 14px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .context-status.success {
      background: rgba(34, 197, 94, 0.2);
      color: #22c55e;
    }

    .context-status.warning {
      background: rgba(251, 191, 36, 0.2);
      color: #fbbf24;
    }

    .context-status.scanning {
      background: rgba(59, 130, 246, 0.2);
    }

    .scan-spinner {
      width: 8px;
      height: 8px;
      border: 1.5px solid rgba(96, 165, 250, 0.3);
      border-top-color: #60a5fa;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    /* Mini toggle for image analysis in context item */
    .image-analysis-toggle {
      display: flex;
      align-items: center;
      margin-left: auto;
      cursor: pointer;
    }

    .image-analysis-toggle input {
      display: none;
    }

    .mini-toggle {
      width: 28px;
      height: 16px;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      position: relative;
      transition: all 0.2s;
    }

    .mini-toggle::after {
      content: '';
      position: absolute;
      top: 2px;
      left: 2px;
      width: 12px;
      height: 12px;
      background: #fff;
      border-radius: 50%;
      transition: all 0.2s;
    }

    .mini-toggle.active {
      background: linear-gradient(135deg, #8b5cf6, #a855f7);
    }

    .mini-toggle.active::after {
      transform: translateX(12px);
    }

    .context-item-value {
      font-size: 11px;
      color: #9ca3af;
      line-height: 1.4;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .context-item-value.scanning {
      color: #60a5fa;
      font-style: italic;
    }

    .context-item-value.warning {
      color: #fbbf24;
      font-size: 10px;
    }

    /* Hover tooltip for context items */
    .context-item.has-tooltip {
      cursor: pointer;
    }

    .context-item.has-tooltip:hover {
      background: rgba(255, 255, 255, 0.03);
      border-radius: 6px;
      margin: -4px;
      padding: 4px;
    }

    .hover-hint {
      margin-left: 4px;
      opacity: 0.4;
      transition: opacity 0.2s;
    }

    .context-item:hover .hover-hint {
      opacity: 0.8;
    }

    .context-tooltip {
      position: absolute;
      left: 0;
      right: 0;
      top: 100%;
      margin-top: 4px;
      background: #1e1e2f;
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 10px;
      padding: 12px;
      z-index: 100;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      animation: tooltipFadeIn 0.15s ease-out;
    }

    @keyframes tooltipFadeIn {
      from {
        opacity: 0;
        transform: translateY(-4px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .context-tooltip-header {
      font-size: 10px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .context-tooltip-content {
      font-size: 12px;
      line-height: 1.6;
      color: #e5e7eb;
      max-height: 200px;
      overflow-y: auto;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .context-tooltip-content::-webkit-scrollbar {
      width: 4px;
    }

    .context-tooltip-content::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 2px;
    }

    .context-tooltip-content::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 2px;
    }
    
    .panel-content {
      padding: 20px;
      overflow-y: auto;
      flex: 1;
    }
    
    .section {
      margin-bottom: 20px;
    }
    
    .section-label {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
      margin-bottom: 8px;
    }
    
    .post-preview {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      padding: 12px;
      font-size: 13px;
      line-height: 1.5;
      color: #d1d5db;
      max-height: 100px;
      overflow-y: auto;
    }
    
    .post-preview h1 {
      font-size: 18px;
      font-weight: 700;
      color: #fff;
      margin: 12px 0 8px 0;
    }
    
    .post-preview h2 {
      font-size: 16px;
      font-weight: 600;
      color: #fff;
      margin: 10px 0 6px 0;
    }
    
    .post-preview h3 {
      font-size: 14px;
      font-weight: 600;
      color: #e5e7eb;
      margin: 8px 0 4px 0;
    }
    
    .post-preview p {
      margin: 8px 0;
      line-height: 1.6;
    }
    
    .post-preview strong {
      font-weight: 600;
      color: #fff;
    }
    
    .post-preview em {
      font-style: italic;
      color: #d1d5db;
    }
    
    .post-preview br {
      line-height: 1.6;
    }
    
    .author-info {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: #9ca3af;
      margin-bottom: 8px;
    }
    
    .author-name {
      color: #fff;
      font-weight: 500;
    }
    
    /* Your Thoughts Input */
    .thoughts-input-wrapper {
      position: relative;
    }

    .thoughts-input {
      width: 100%;
      padding: 10px 32px 10px 12px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #fff;
      font-size: 13px;
      font-family: inherit;
      line-height: 1.5;
      resize: none;
      transition: all 0.2s;
      min-height: 60px;
      max-height: 120px;
    }

    .thoughts-input::placeholder {
      color: #6b7280;
      font-size: 12px;
    }

    .thoughts-input:hover {
      border-color: rgba(255, 255, 255, 0.2);
    }

    .thoughts-input:focus {
      outline: none;
      border-color: #0a66c2;
      box-shadow: 0 0 0 3px rgba(10, 102, 194, 0.2);
    }

    .clear-thoughts-btn {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      border: none;
      background: rgba(255, 255, 255, 0.1);
      color: #9ca3af;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }

    .clear-thoughts-btn:hover {
      background: rgba(239, 68, 68, 0.2);
      color: #ef4444;
    }

    .optional-label {
      font-weight: 400;
      color: #6b7280;
      font-size: 10px;
    }

    /* Service Offer Toggle */
    .service-offer-toggle {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.05), rgba(234, 88, 12, 0.05));
      border: 1px solid rgba(245, 158, 11, 0.2);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
      position: relative;
    }

    .service-offer-toggle:not(.disabled):hover {
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(234, 88, 12, 0.1));
      border-color: rgba(245, 158, 11, 0.3);
    }

    .service-offer-toggle.disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .toggle-left {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .toggle-icon {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      background: rgba(245, 158, 11, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #f59e0b;
    }

    .toggle-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .toggle-label {
      font-size: 12px;
      font-weight: 500;
      color: #fff;
    }

    .toggle-hint {
      font-size: 10px;
      color: #9ca3af;
    }

    .toggle-hint.warning {
      color: #f59e0b;
    }

    .toggle-checkbox {
      position: absolute;
      opacity: 0;
      pointer-events: none;
    }

    .toggle-switch {
      width: 36px;
      height: 20px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      position: relative;
      transition: all 0.2s;
      flex-shrink: 0;
    }

    .toggle-switch::after {
      content: '';
      position: absolute;
      top: 2px;
      left: 2px;
      width: 16px;
      height: 16px;
      background: #fff;
      border-radius: 50%;
      transition: all 0.2s;
    }

    .toggle-switch.active {
      background: linear-gradient(135deg, #f59e0b, #ea580c);
    }

    .toggle-switch.active::after {
      transform: translateX(16px);
    }

    /* Image Toggle */
    .image-toggle {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(168, 85, 247, 0.05));
      border: 1px solid rgba(139, 92, 246, 0.2);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
      position: relative;
    }

    .image-toggle:hover {
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(168, 85, 247, 0.1));
      border-color: rgba(139, 92, 246, 0.3);
    }

    .toggle-icon.image {
      background: rgba(139, 92, 246, 0.15);
      color: #a855f7;
    }

    .toggle-switch.image.active {
      background: linear-gradient(135deg, #8b5cf6, #a855f7);
    }

    .tone-select {
      width: 100%;
      padding: 10px 14px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #fff;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.2s;
      appearance: none;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 12px center;
    }
    
    .tone-select:hover {
      border-color: rgba(255, 255, 255, 0.2);
    }
    
    .tone-select:focus {
      outline: none;
      border-color: #0a66c2;
      box-shadow: 0 0 0 3px rgba(10, 102, 194, 0.2);
    }
    
    .tone-select option {
      background: #1a1a2e;
      color: #fff;
    }
    
    .generate-btn {
      width: 100%;
      padding: 12px 20px;
      background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
      border: none;
      border-radius: 10px;
      color: #fff;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s;
    }
    
    .generate-btn:hover:not(:disabled) {
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(10, 102, 194, 0.4);
    }
    
    .generate-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .spinner {
      width: 18px;
      height: 18px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top-color: #fff;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    .spinner-small {
      width: 12px;
      height: 12px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top-color: #fff;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* Shimmer Loading */
    .shimmer-container {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .shimmer-card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .shimmer-line {
      height: 12px;
      border-radius: 6px;
      background: linear-gradient(
        90deg,
        rgba(255, 255, 255, 0.05) 0%,
        rgba(255, 255, 255, 0.1) 50%,
        rgba(255, 255, 255, 0.05) 100%
      );
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
    }

    .shimmer-line.long { width: 100%; }
    .shimmer-line.medium { width: 75%; }
    .shimmer-line.short { width: 50%; }

    @keyframes shimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
    
    .results {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    
    .comment-card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      padding: 14px;
      transition: all 0.2s;
    }

    .comment-card.refining {
      opacity: 0.6;
    }
    
    .comment-card:hover {
      background: rgba(255, 255, 255, 0.08);
      border-color: rgba(255, 255, 255, 0.15);
    }
    
    .comment-text {
      font-size: 13px;
      line-height: 1.6;
      color: #e5e7eb;
      margin-bottom: 12px;
    }
    
    .comment-actions {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .action-group {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .action-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      padding: 6px 10px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.05);
      color: #9ca3af;
      font-size: 11px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .action-btn:hover:not(:disabled) {
      background: rgba(255, 255, 255, 0.1);
      color: #fff;
    }

    .action-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .action-btn.copied {
      background: rgba(34, 197, 94, 0.2);
      border-color: rgba(34, 197, 94, 0.3);
      color: #22c55e;
    }

    .action-btn.refine-btn {
      padding: 5px 8px;
      font-size: 10px;
      gap: 4px;
    }

    .action-btn.refine-btn span {
      font-weight: 500;
    }

    .insert-btn {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 6px 12px;
      background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
      border: none;
      border-radius: 6px;
      color: #fff;
      font-size: 11px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    .insert-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(10, 102, 194, 0.4);
    }
    
    /* Recommendation Tag */
    .recommendation-tag {
      display: inline-block;
      font-size: 10px;
      font-weight: 600;
      color: #93c5fd;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
      padding: 3px 8px;
      background: rgba(59, 130, 246, 0.15);
      border-radius: 4px;
    }
    
    .error-message {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 10px;
      padding: 12px;
      color: #fca5a5;
      font-size: 13px;
      display: flex;
      align-items: flex-start;
      gap: 10px;
    }
    
    .error-icon {
      flex-shrink: 0;
      color: #ef4444;
    }
    
    .no-api-key {
      text-align: center;
      padding: 20px;
    }
    
    .no-api-key-icon {
      width: 48px;
      height: 48px;
      margin: 0 auto 16px;
      border-radius: 12px;
      background: rgba(251, 191, 36, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fbbf24;
    }
    
    .no-api-key h3 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 8px;
    }
    
    .no-api-key p {
      font-size: 13px;
      color: #9ca3af;
      margin-bottom: 16px;
    }
    
    .settings-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 10px 16px;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .settings-btn:hover {
      background: rgba(255, 255, 255, 0.15);
    }

    /* History Tab */
    .history-section {
      min-height: 200px;
    }

    .empty-history {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .empty-history svg {
      margin-bottom: 16px;
      opacity: 0.5;
    }

    .empty-history p {
      font-size: 14px;
      font-weight: 500;
      margin-bottom: 4px;
      color: #9ca3af;
    }

    .empty-history span {
      font-size: 12px;
    }

    .history-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }

    .history-count {
      font-size: 11px;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .clear-history-btn {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px 8px;
      background: transparent;
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 4px;
      color: #ef4444;
      font-size: 11px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .clear-history-btn:hover {
      background: rgba(239, 68, 68, 0.1);
    }

    .history-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .history-item {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 10px;
      padding: 12px;
    }

    .history-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
      font-size: 11px;
      color: #6b7280;
    }

    .history-time {
      color: #9ca3af;
      font-weight: 500;
    }

    .history-post {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .history-comment {
      font-size: 13px;
      line-height: 1.5;
      color: #d1d5db;
      margin-bottom: 10px;
    }

    .history-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .panel-footer {
      padding: 12px 20px;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      background: rgba(0, 0, 0, 0.2);
      font-size: 11px;
      color: #6b7280;
      text-align: center;
      line-height: 1.5;
      flex-shrink: 0;
    }
    
    .panel-footer .sponsor-link {
      color: #9ca3af;
      font-weight: 600;
      text-decoration: none;
      transition: color 0.2s;
    }
    
    .panel-footer .sponsor-link:hover {
      color: #0a66c2;
      text-decoration: underline;
    }
    
    .panel-footer .footer-divider {
      margin: 0 8px;
      color: #4b5563;
    }
    
    .panel-footer .support-link {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      color: #ef4444;
      font-weight: 500;
      text-decoration: none;
      transition: all 0.2s;
      margin-left: 4px;
    }
    
    .panel-footer .support-link svg {
      width: 14px;
      height: 14px;
      fill: #ef4444;
      stroke: #ef4444;
    }
    
    .panel-footer .support-link:hover {
      color: #f87171;
      text-decoration: underline;
    }
    
    .panel-footer .support-link:hover svg {
      fill: #f87171;
      stroke: #f87171;
      transform: scale(1.1);
    }
  `}
