import{j as e,r as f,c as je,R as ke}from"./client-D7f9BLy3.js";import{b as et,d as tt,e as nt,g as Ee}from"./storage-BROYPw1S.js";function de({icon:t,label:n,value:o,fullValue:s,status:a,subLabel:r}){const[i,c]=f.useState(!1),l=s&&s.length>0&&s!==o,d=()=>a==="scanning"?e.jsx("div",{className:"context-status scanning",children:e.jsx("div",{className:"scan-spinner"})}):a==="success"?e.jsx("div",{className:"context-status success",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})}):e.jsx("div",{className:"context-status warning",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("path",{d:"M12 9v4M12 17h.01"})})});return e.jsxs("div",{className:`context-item ${a} ${l?"has-tooltip":""}`,onMouseEnter:()=>l&&c(!0),onMouseLeave:()=>c(!1),children:[e.jsx("div",{className:"context-item-line"}),e.jsx("div",{className:"context-item-icon",children:t}),e.jsxs("div",{className:"context-item-content",children:[e.jsxs("div",{className:"context-item-header",children:[e.jsx("span",{className:"context-item-label",children:n}),d(),l&&e.jsx("span",{className:"hover-hint",children:e.jsxs("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 16v-4M12 8h.01"})]})})]}),a==="scanning"?e.jsx("div",{className:"context-item-value scanning",children:"Scanning..."}):o?e.jsx("div",{className:"context-item-value",children:o}):e.jsx("div",{className:"context-item-value warning",children:r||"Not found"})]}),i&&s&&e.jsxs("div",{className:"context-tooltip",children:[e.jsx("div",{className:"context-tooltip-header",children:n}),e.jsx("div",{className:"context-tooltip-content",children:s})]})]})}function ot({postData:t,isScanning:n,analyzeImage:o,onAnalyzeImageChange:s}){const a=(m,v)=>m?m.length>v?m.slice(0,v)+"...":m:"",r=()=>n?"scanning":t!=null&&t.postContent?"success":"warning",i=()=>n?"scanning":t!=null&&t.authorName?"success":"warning",c=()=>n?"scanning":"success",l=()=>{var v,S;return n?"scanning":(((S=(v=t==null?void 0:t.threadContext)==null?void 0:v.existingComments)==null?void 0:S.length)||0)>0?"success":"warning"},d=()=>{var m,v;return t?((m=t.threadContext)==null?void 0:m.mode)==="reply"&&((v=t.threadContext)!=null&&v.parentComment)?`Replying to ${t.threadContext.parentComment.authorName}`:"Direct Comment Mode":null},u=()=>{var m,v;return t?((m=t.threadContext)==null?void 0:m.mode)==="reply"&&((v=t.threadContext)!=null&&v.parentComment)?a(t.threadContext.parentComment.content,50):"Commenting directly on the main post":null},g=()=>{var m,v;return t&&((m=t.threadContext)==null?void 0:m.mode)==="reply"&&(v=t.threadContext)!=null&&v.parentComment?t.threadContext.parentComment.content:null},p=()=>{var v,S;if(!t)return null;const m=((S=(v=t.threadContext)==null?void 0:v.existingComments)==null?void 0:S.length)||0;return m===0?"No previous comments found":`${m} previous comment${m>1?"s":""} analyzed`},x=()=>{var v;if(!t)return null;const m=(v=t.threadContext)==null?void 0:v.existingComments;return!m||m.length===0?null:m.map((S,C)=>`${C+1}. ${S.authorName}: "${a(S.content,100)}"`).join(`

`)},b=()=>{if(!t)return null;const m=[];return t.authorName&&m.push(`Name: ${t.authorName}`),t.authorHeadline&&m.push(`Headline: ${t.authorHeadline}`),m.length>0?m.join(`
`):null},w=()=>n?"scanning":t!=null&&t.imageUrl?"success":"warning";return e.jsxs("div",{className:"context-awareness",children:[e.jsxs("div",{className:"context-header",children:[e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 16v-4M12 8h.01"})]}),e.jsx("span",{children:"Context Analysis"}),n&&e.jsx("span",{className:"scanning-badge",children:"Scanning"})]}),e.jsxs("div",{className:"context-timeline",children:[e.jsx(de,{icon:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"}),e.jsx("polyline",{points:"14 2 14 8 20 8"}),e.jsx("line",{x1:"16",y1:"13",x2:"8",y2:"13"}),e.jsx("line",{x1:"16",y1:"17",x2:"8",y2:"17"})]}),label:"Post Content",value:t?a(t.postContent,50):null,fullValue:(t==null?void 0:t.postContent)||null,status:r(),subLabel:"Unable to scrape post content"}),e.jsx(de,{icon:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"}),e.jsx("circle",{cx:"12",cy:"7",r:"4"})]}),label:"Author",value:t!=null&&t.authorName?`${t.authorName}${t.authorHeadline?` • ${a(t.authorHeadline,30)}`:""}`:null,fullValue:b(),status:i(),subLabel:"Author info not found"}),e.jsx(de,{icon:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polyline",{points:"9 17 4 12 9 7"}),e.jsx("path",{d:"M20 18v-2a4 4 0 0 0-4-4H4"})]}),label:d()||"Thread Mode",value:u(),fullValue:g(),status:c()}),e.jsx(de,{icon:e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})}),label:"Discussion Context",value:p(),fullValue:x(),status:l()}),e.jsxs("div",{className:`context-item ${w()}`,children:[e.jsx("div",{className:"context-item-line"}),e.jsx("div",{className:"context-item-icon",children:e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"}),e.jsx("circle",{cx:"8.5",cy:"8.5",r:"1.5"}),e.jsx("polyline",{points:"21 15 16 10 5 21"})]})}),e.jsxs("div",{className:"context-item-content",children:[e.jsxs("div",{className:"context-item-header",children:[e.jsx("span",{className:"context-item-label",children:"Image Analysis"}),w()==="scanning"?e.jsx("div",{className:"context-status scanning",children:e.jsx("div",{className:"scan-spinner"})}):w()==="success"?e.jsx("div",{className:"context-status success",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})})}):e.jsx("div",{className:"context-status warning",children:e.jsx("svg",{width:"10",height:"10",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"3",children:e.jsx("path",{d:"M12 9v4M12 17h.01"})})}),(t==null?void 0:t.imageUrl)&&s&&e.jsxs("label",{className:"image-analysis-toggle",onClick:m=>m.stopPropagation(),children:[e.jsx("input",{type:"checkbox",checked:o??!1,onChange:m=>s(m.target.checked)}),e.jsx("span",{className:`mini-toggle ${o?"active":""}`})]})]}),w()==="scanning"?e.jsx("div",{className:"context-item-value scanning",children:"Scanning..."}):t!=null&&t.imageUrl?e.jsx("div",{className:"context-item-value",children:o?"Will analyze image":"Image skipped (click toggle)"}):e.jsx("div",{className:"context-item-value warning",children:"No image in post"})]})]})]})]})}function Be(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}async function ue(t){if(console.log("[FloatingPanel] safeSendMessage called with type:",t.type),!Be())return console.error("[FloatingPanel] Extension context invalidated!"),{success:!1,error:"Extension was updated. Please refresh the page."};try{console.log("[FloatingPanel] Sending message to background script...");const n=await chrome.runtime.sendMessage(t);return console.log("[FloatingPanel] Received response from background:",n),n}catch(n){if(console.error("[FloatingPanel] Error sending message:",n),n instanceof Error&&(n.message.includes("Extension context invalidated")||n.message.includes("Receiving end does not exist")))return{success:!1,error:"Extension was updated. Please refresh the page."};throw n}}const st=[{value:"professional",label:"Professional"},{value:"funny",label:"Funny"},{value:"question",label:"Question"},{value:"agree-add-value",label:"Agree & Add Value"}];function rt({postData:t,isScanning:n=!1,onClose:o,onInsertComment:s}){const[a,r]=f.useState("generate"),[i,c]=f.useState("professional"),[l,d]=f.useState(""),[u,g]=f.useState(!1),[p,x]=f.useState([]),[b,w]=f.useState([]),[m,v]=f.useState(null),[S,C]=f.useState(null),[L,N]=f.useState(!1),[M,I]=f.useState(!0),[q,T]=f.useState(null),[P,A]=f.useState([]),[W,re]=f.useState(null),[ie,ae]=f.useState(null),[j,E]=f.useState(!1),[O,F]=f.useState(!1),[V,Z]=f.useState(!1),[K,Oe]=f.useState(!1),[ne,Ve]=f.useState(null),Ge=!n&&t&&t.postContent&&L,le=f.useRef(null),Ue=()=>{const h=le.current;h&&(h.style.height="auto",h.style.height=`${Math.min(h.scrollHeight,120)}px`)},ce=f.useRef(null),H=f.useRef({isDragging:!1,startX:0,startY:0,initialX:0,initialY:0});f.useEffect(()=>{Ye(),xe()},[]),f.useEffect(()=>{t!=null&&t.imageUrl&&K&&Z(!0)},[t==null?void 0:t.imageUrl,K]);const Ye=async()=>{var h;I(!0),T(null);try{const y=await ue({type:"CHECK_CONFIG"});if(!y.success){N(!1),T(y.error||"Failed to check configuration"),I(!1);return}const k=y.settings;if(!k){N(!1),T("Settings not found. Please configure the extension in Settings."),I(!1);return}Ve({enableEmojis:k.enableEmojis??!1,languageLevel:k.languageLevel||"fluent",serviceDescription:k.serviceDescription||""});const B=k.persona&&k.persona.trim().length>0,_=k.apiKey&&k.apiKey.trim().length>0,$=B&&_;if(N($),F(!!((h=k.serviceDescription)!=null&&h.trim())),Oe(k.enableImageAnalysis??!1),Z(k.enableImageAnalysis??!1),$)console.log("[FloatingPanel] Configuration check successful - extension ready");else{const R=[];B||R.push("persona"),_||R.push("API key"),T(`Please complete your setup in Settings: ${R.join(", ")}`)}}catch(y){console.error("[FloatingPanel] Configuration check failed:",y),N(!1),y!=null&&y.message?T(`Error: ${y.message}`):T("Failed to check configuration. Please try again.")}finally{I(!1)}},xe=async()=>{const h=await et();A(h)};f.useEffect(()=>{const h=ce.current;if(!h)return;const y=_=>{if(!_.target.closest(".panel-header"))return;H.current.isDragging=!0,H.current.startX=_.clientX,H.current.startY=_.clientY;const R=h.getBoundingClientRect();H.current.initialX=R.left,H.current.initialY=R.top,h.style.transition="none"},k=_=>{if(!H.current.isDragging)return;const $=_.clientX-H.current.startX,R=_.clientY-H.current.startY;h.style.right="auto",h.style.left=`${H.current.initialX+$}px`,h.style.top=`${H.current.initialY+R}px`},B=()=>{H.current.isDragging=!1,h.style.transition=""};return h.addEventListener("mousedown",y),document.addEventListener("mousemove",k),document.addEventListener("mouseup",B),()=>{h.removeEventListener("mousedown",y),document.removeEventListener("mousemove",k),document.removeEventListener("mouseup",B)}},[]);const Xe=async()=>{var h;if(!t){C("No post data available. Please try again.");return}if(!ne||!L){C("Configuration not ready. Please wait...");return}g(!0),C(null),x([]),w([]);try{const y={type:"GENERATE_COMMENTS",payload:{postData:t,tone:i,enableEmojis:ne.enableEmojis,languageLevel:ne.languageLevel,userThoughts:l.trim()||void 0,enableImageAnalysis:V&&!!(t!=null&&t.imageUrl),includeServiceOffer:j&&!!((h=ne.serviceDescription)!=null&&h.trim()),serviceDescription:j?ne.serviceDescription:void 0}},k=await ue(y);k.success?k.scoredComments&&k.scoredComments.length>0?(w(k.scoredComments),x(k.scoredComments.map(B=>B.text))):k.comments&&x(k.comments):C(k.error||"Failed to generate comments")}catch(y){C(y instanceof Error?y.message:"An unexpected error occurred")}finally{g(!1)}},Ae=async(h,y)=>{v(h);try{const B={type:"REFINE_COMMENT",payload:{comment:b.length>0?b[h].text:p[h],refinementType:y}},_=await ue(B);if(_.success&&_.comment){if(b.length>0){const R=[...b];R[h]={...R[h],text:_.comment},w(R)}const $=[...p];$[h]=_.comment,x($)}else _.error&&C(_.error)}catch(k){console.error("Refine error:",k)}finally{v(null)}},Me=async(h,y,k)=>{try{await navigator.clipboard.writeText(h),y!==void 0&&(re(y),setTimeout(()=>re(null),2e3)),k&&(ae(k),setTimeout(()=>ae(null),2e3))}catch(B){console.error("Copy failed:",B)}},Ke=async(h,y)=>{var B;t&&await tt(h,t.postContent);const k=y!==void 0&&(((B=b[y])==null?void 0:B.text)||p[y])||h;s(h),ue({type:"STREAM_UPDATE_PERSONA",payload:{originalAiSuggestion:k,finalUserVersion:h}}).catch(_=>{console.error("[FloatingPanel] Persona update error:",_)}),xe()},Je=async()=>{await nt(),A([])},Qe=()=>{if(Be())try{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})}catch{C("Extension was updated. Please refresh the page.")}else C("Extension was updated. Please refresh the page.")},Ze=(h,y)=>h.length<=y?h:h.slice(0,y)+"...",De=h=>{const y=new Date(h),B=new Date().getTime()-y.getTime(),_=Math.floor(B/6e4),$=Math.floor(B/36e5),R=Math.floor(B/864e5);return _<1?"Just now":_<60?`${_}m ago`:$<24?`${$}h ago`:R<7?`${R}d ago`:y.toLocaleDateString()};return M?e.jsxs("div",{className:"panel",ref:ce,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"})})}),e.jsx("span",{children:"AI Comment Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"panel-content",children:e.jsxs("div",{className:"no-api-key",children:[e.jsx("div",{className:"no-api-key-icon",children:e.jsx("div",{className:"w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto"})}),e.jsx("h3",{children:"Checking Configuration..."}),e.jsx("p",{children:"Verifying your setup"})]})})]}):L?e.jsx(e.Fragment,{children:e.jsxs("div",{className:"panel",ref:ce,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"})})}),e.jsx("span",{children:"AI Comment Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsxs("div",{className:"tabs",children:[e.jsxs("button",{className:`tab ${a==="generate"?"active":""}`,onClick:()=>r("generate"),children:[e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),"Generate"]}),e.jsxs("button",{className:`tab ${a==="history"?"active":""}`,onClick:()=>{r("history"),xe()},children:[e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("polyline",{points:"12 6 12 12 16 14"})]}),"History"]})]}),e.jsx(ot,{postData:t,isScanning:n,analyzeImage:V,onAnalyzeImageChange:Z}),e.jsx("div",{className:"panel-content",children:a==="generate"?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"section",children:[e.jsxs("div",{className:"section-label",children:["Your key point ",e.jsx("span",{className:"optional-label",children:"(optional)"})]}),e.jsxs("div",{className:"thoughts-input-wrapper",children:[e.jsx("textarea",{ref:le,className:"thoughts-input",value:l,onChange:h=>{d(h.target.value),Ue()},placeholder:"e.g., Mention that we just launched a similar feature, or ask about their pricing model...",rows:2}),l&&e.jsx("button",{className:"clear-thoughts-btn",onClick:()=>{d(""),le.current&&(le.current.style.height="auto")},title:"Clear",children:e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]})]}),e.jsx("div",{className:"section",children:e.jsxs("label",{className:`service-offer-toggle ${O?"":"disabled"}`,children:[e.jsxs("div",{className:"toggle-left",children:[e.jsx("div",{className:"toggle-icon",children:e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"2",y:"7",width:"20",height:"14",rx:"2",ry:"2"}),e.jsx("path",{d:"M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"})]})}),e.jsxs("div",{className:"toggle-text",children:[e.jsx("span",{className:"toggle-label",children:"Include Service Offer"}),O?e.jsx("span",{className:"toggle-hint",children:"Subtly promote your expertise"}):e.jsx("span",{className:"toggle-hint warning",children:"Configure in Settings first"})]})]}),e.jsx("input",{type:"checkbox",checked:j,onChange:h=>E(h.target.checked),disabled:!O,className:"toggle-checkbox"}),e.jsx("span",{className:`toggle-switch ${j?"active":""}`})]})}),e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Tone"}),e.jsx("select",{className:"tone-select",value:i,onChange:h=>c(h.target.value),children:st.map(h=>e.jsx("option",{value:h.value,children:h.label},h.value))})]}),e.jsx("div",{className:"section",children:e.jsx("button",{className:"generate-btn",onClick:Xe,disabled:!Ge||u,children:n?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Scanning Context..."]}):u?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Generating..."]}):t?e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),"Generate Comments"]}):e.jsxs(e.Fragment,{children:[e.jsxs("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 8v4M12 16h.01"})]}),"Waiting for Context..."]})})}),u&&e.jsxs("div",{className:"shimmer-container",children:[e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line long"}),e.jsx("div",{className:"shimmer-line medium"}),e.jsx("div",{className:"shimmer-line short"})]}),e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line long"}),e.jsx("div",{className:"shimmer-line medium"})]}),e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line medium"}),e.jsx("div",{className:"shimmer-line long"})]})]}),S&&e.jsxs("div",{className:"error-message",children:[e.jsxs("svg",{className:"error-icon",width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("line",{x1:"12",y1:"8",x2:"12",y2:"12"}),e.jsx("line",{x1:"12",y1:"16",x2:"12.01",y2:"16"})]}),e.jsx("span",{children:S})]}),p.length>0&&!u&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Generated Comments"}),e.jsx("div",{className:"results",children:p.map((h,y)=>{const k=b[y];return e.jsxs("div",{className:`comment-card ${m===y?"refining":""}`,children:[(k==null?void 0:k.recommendationTag)&&e.jsx("div",{className:"recommendation-tag",children:k.recommendationTag}),e.jsx("div",{className:"comment-text",children:h}),e.jsxs("div",{className:"comment-actions",children:[e.jsxs("div",{className:"action-group",children:[e.jsx("button",{className:"action-btn refine-btn",onClick:()=>Ae(y,"concise"),disabled:m!==null,title:"Make more concise",children:m===y?e.jsx("div",{className:"spinner-small"}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M4 12h16M4 12l4-4M4 12l4 4M20 12l-4-4M20 12l-4 4"})}),e.jsx("span",{children:"Shorter"})]})}),e.jsx("button",{className:"action-btn refine-btn",onClick:()=>Ae(y,"rephrase"),disabled:m!==null,title:"Rephrase",children:m===y?e.jsx("div",{className:"spinner-small"}):e.jsxs(e.Fragment,{children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M1 4v6h6"}),e.jsx("path",{d:"M3.51 15a9 9 0 1 0 2.13-9.36L1 10"})]}),e.jsx("span",{children:"Rephrase"})]})})]}),e.jsxs("div",{className:"action-group",children:[e.jsx("button",{className:`action-btn ${W===y?"copied":""}`,onClick:()=>Me(h,y),title:"Copy to clipboard",children:W===y?e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})}):e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),e.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]})}),e.jsxs("button",{className:"insert-btn",onClick:()=>Ke(h,y),title:"Insert into comment box",children:[e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})}),"Insert"]})]})]})]},y)})})]})]}):e.jsx("div",{className:"history-section",children:P.length===0?e.jsxs("div",{className:"empty-history",children:[e.jsxs("svg",{width:"32",height:"32",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("polyline",{points:"12 6 12 12 16 14"})]}),e.jsx("p",{children:"No comments in history yet."}),e.jsx("span",{children:"Generated comments will appear here."})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"history-header",children:[e.jsxs("span",{className:"history-count",children:[P.length," recent comments"]}),e.jsxs("button",{className:"clear-history-btn",onClick:Je,children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("polyline",{points:"3 6 5 6 21 6"}),e.jsx("path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),"Clear"]})]}),e.jsx("div",{className:"history-list",children:P.map(h=>e.jsxs("div",{className:"history-item",children:[e.jsxs("div",{className:"history-meta",children:[e.jsx("span",{className:"history-time",children:De(h.timestamp)}),e.jsx("span",{className:"history-post",children:Ze(h.postPreview,30)})]}),e.jsx("div",{className:"history-comment",children:h.comment}),e.jsxs("div",{className:"history-actions",children:[e.jsx("button",{className:`action-btn ${ie===h.id?"copied":""}`,onClick:()=>Me(h.comment,void 0,h.id),children:ie===h.id?e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})}),"Copied"]}):e.jsxs(e.Fragment,{children:[e.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),e.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]}),"Copy"]})}),e.jsxs("button",{className:"insert-btn",onClick:()=>s(h.comment),children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})}),"Insert"]})]})]},h.id))})]})})}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]})}):e.jsx(e.Fragment,{children:e.jsxs("div",{className:"panel",ref:ce,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"})})}),e.jsx("span",{children:"AI Comment Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"panel-content",children:e.jsxs("div",{className:"no-api-key",children:[e.jsx("div",{className:"no-api-key-icon",children:e.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"})})}),e.jsx("h3",{children:"Setup Required"}),e.jsx("p",{children:q||"Please complete your setup in Settings"}),e.jsxs("button",{className:"settings-btn",onClick:Qe,children:[e.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("path",{d:"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"})]}),"Open Settings"]})]})}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]})})}const it=[{value:"friendly",label:"Friendly"},{value:"professional",label:"Professional"},{value:"follow-up",label:"Follow-up"},{value:"closing-deal",label:"Closing Deal"},{value:"networking",label:"Networking"}];function Le(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}async function at(t){if(!Le())return{success:!1,error:"Extension was updated. Please refresh the page."};try{return await chrome.runtime.sendMessage(t)}catch(n){if(n instanceof Error&&(n.message.includes("Extension context invalidated")||n.message.includes("Receiving end does not exist")))return{success:!1,error:"Extension was updated. Please refresh the page."};throw n}}function lt({conversationContext:t,isScanning:n=!1,onClose:o,onInsertReply:s}){const[a,r]=f.useState("friendly"),[i,c]=f.useState(""),[l,d]=f.useState(!1),[u,g]=f.useState([]),[p,x]=f.useState(null),[b,w]=f.useState(null),[m,v]=f.useState(!0),[S,C]=f.useState(null),[L,N]=f.useState(!1),[M,I]=f.useState(!1),q=!n&&t&&t.messages.length>0&&m,T=f.useRef(null),P=f.useRef(null),A=f.useRef({isDragging:!1,startX:0,startY:0,initialX:0,initialY:0});f.useEffect(()=>{Ee().then(j=>{var E;v(!!j.apiKey),I(!!((E=j.serviceDescription)!=null&&E.trim()))})},[]);const W=()=>{const j=T.current;j&&(j.style.height="auto",j.style.height=`${Math.min(j.scrollHeight,120)}px`)};f.useEffect(()=>{const j=P.current;if(!j)return;const E=V=>{if(!V.target.closest(".panel-header"))return;A.current.isDragging=!0,A.current.startX=V.clientX,A.current.startY=V.clientY;const K=j.getBoundingClientRect();A.current.initialX=K.left,A.current.initialY=K.top,j.style.transition="none"},O=V=>{if(!A.current.isDragging)return;const Z=V.clientX-A.current.startX,K=V.clientY-A.current.startY;j.style.right="auto",j.style.left=`${A.current.initialX+Z}px`,j.style.top=`${A.current.initialY+K}px`},F=()=>{A.current.isDragging=!1,j.style.transition=""};return j.addEventListener("mousedown",E),document.addEventListener("mousemove",O),document.addEventListener("mouseup",F),()=>{j.removeEventListener("mousedown",E),document.removeEventListener("mousemove",O),document.removeEventListener("mouseup",F)}},[]);const re=async()=>{var j;if(!t){w("No conversation context available.");return}d(!0),w(null),g([]),x(null);try{const E=await Ee();if(!E.apiKey){v(!1);return}const O={type:"GENERATE_MESSAGES",payload:{conversationContext:t,tone:a,persona:E.persona,enableEmojis:E.enableEmojis??!1,languageLevel:E.languageLevel||"fluent",userThoughts:i.trim()||void 0,includeServiceOffer:L&&!!((j=E.serviceDescription)!=null&&j.trim()),serviceDescription:L?E.serviceDescription:void 0}},F=await at(O);F.success&&F.replies?(g(F.replies),F.summary&&x(F.summary)):w(F.error||"Failed to generate replies")}catch(E){w(E instanceof Error?E.message:"An unexpected error occurred")}finally{d(!1)}},ie=async(j,E)=>{try{await navigator.clipboard.writeText(j),C(E),setTimeout(()=>C(null),2e3)}catch(O){console.error("Copy failed:",O)}},ae=()=>{if(Le())try{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})}catch{w("Extension was updated. Please refresh the page.")}else w("Extension was updated. Please refresh the page.")};return m?e.jsxs("div",{className:"panel messaging-panel",ref:P,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon messaging",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})})}),e.jsx("span",{children:"Conversation Co-pilot"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"messaging-context",children:n?e.jsxs("div",{className:"context-scanning",children:[e.jsx("div",{className:"spinner-small"}),e.jsx("span",{children:"Analyzing conversation..."})]}):t?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"context-participant",children:[e.jsx("span",{className:"context-label",children:"Chatting with:"}),e.jsx("span",{className:"context-value",children:t.participantName})]}),t.participantHeadline&&e.jsx("div",{className:"context-headline",children:t.participantHeadline}),e.jsxs("div",{className:"context-stats",children:[e.jsxs("span",{className:"stat",children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})}),t.messages.length," messages"]}),e.jsxs("span",{className:"stat",children:[e.jsx("span",{className:`sentiment-dot ${t.sentiment}`}),t.sentiment]})]}),p&&e.jsxs("div",{className:"ai-summary",children:[e.jsx("div",{className:"summary-topic",children:p.topic}),e.jsxs("div",{className:"summary-action",children:[e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),p.suggestedAction]})]})]}):e.jsxs("div",{className:"context-empty",children:[e.jsxs("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 8v4M12 16h.01"})]}),e.jsx("span",{children:"Open a conversation to get started"})]})}),e.jsxs("div",{className:"panel-content",children:[e.jsxs("div",{className:"section",children:[e.jsxs("div",{className:"section-label",children:["Your goal for this reply ",e.jsx("span",{className:"optional-label",children:"(optional)"})]}),e.jsxs("div",{className:"thoughts-input-wrapper",children:[e.jsx("textarea",{ref:T,className:"thoughts-input",value:i,onChange:j=>{c(j.target.value),W()},placeholder:"e.g., Schedule a call for next week, or ask about their budget...",rows:2}),i&&e.jsx("button",{className:"clear-thoughts-btn",onClick:()=>{c(""),T.current&&(T.current.style.height="auto")},title:"Clear",children:e.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]})]}),e.jsx("div",{className:"section",children:e.jsxs("label",{className:`service-offer-toggle ${M?"":"disabled"}`,children:[e.jsxs("div",{className:"toggle-left",children:[e.jsx("div",{className:"toggle-icon",children:e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"2",y:"7",width:"20",height:"14",rx:"2",ry:"2"}),e.jsx("path",{d:"M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"})]})}),e.jsxs("div",{className:"toggle-text",children:[e.jsx("span",{className:"toggle-label",children:"Include Service Offer"}),M?e.jsx("span",{className:"toggle-hint",children:"Subtly mention your expertise"}):e.jsx("span",{className:"toggle-hint warning",children:"Configure in Settings first"})]})]}),e.jsx("input",{type:"checkbox",checked:L,onChange:j=>N(j.target.checked),disabled:!M,className:"toggle-checkbox"}),e.jsx("span",{className:`toggle-switch ${L?"active":""}`})]})}),e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Conversation Tone"}),e.jsx("select",{className:"tone-select",value:a,onChange:j=>r(j.target.value),children:it.map(j=>e.jsx("option",{value:j.value,children:j.label},j.value))})]}),e.jsx("div",{className:"section",children:e.jsx("button",{className:"generate-btn",onClick:re,disabled:!q||l,children:n?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Analyzing Chat..."]}):l?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Crafting Replies..."]}):t?e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2"})}),"Suggest Replies"]}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})}),"Open a Conversation"]})})}),l&&e.jsxs("div",{className:"shimmer-container",children:[e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line long"}),e.jsx("div",{className:"shimmer-line short"})]}),e.jsxs("div",{className:"shimmer-card",children:[e.jsx("div",{className:"shimmer-line medium"}),e.jsx("div",{className:"shimmer-line long"})]})]}),b&&e.jsxs("div",{className:"error-message",children:[e.jsxs("svg",{className:"error-icon",width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("line",{x1:"12",y1:"8",x2:"12",y2:"12"}),e.jsx("line",{x1:"12",y1:"16",x2:"12.01",y2:"16"})]}),e.jsx("span",{children:b})]}),u.length>0&&!l&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Suggested Replies"}),e.jsx("div",{className:"results",children:u.map((j,E)=>e.jsxs("div",{className:"comment-card",children:[e.jsx("div",{className:"recommendation-tag",children:j.recommendationTag}),e.jsx("div",{className:"comment-text",children:j.text}),e.jsx("div",{className:"comment-actions",children:e.jsxs("div",{className:"action-group",children:[e.jsx("button",{className:`action-btn ${S===E?"copied":""}`,onClick:()=>ie(j.text,E),title:"Copy to clipboard",children:S===E?e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("polyline",{points:"20 6 9 17 4 12"})}):e.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),e.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]})}),e.jsxs("button",{className:"insert-btn",onClick:()=>s(j.text),title:"Insert into message box",children:[e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})}),"Send"]})]})})]},E))})]})]}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]}):e.jsxs("div",{className:"panel messaging-panel",ref:P,children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon messaging",children:e.jsx("svg",{width:"18",height:"18",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"})})}),e.jsx("span",{children:"Conversation Co-pilot"})]}),e.jsx("button",{className:"close-btn",onClick:o,children:e.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsx("div",{className:"panel-content",children:e.jsxs("div",{className:"no-api-key",children:[e.jsx("div",{className:"no-api-key-icon",children:e.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"})})}),e.jsx("h3",{children:"API Key Required"}),e.jsx("p",{children:"Please configure your API key in the extension settings."}),e.jsx("button",{className:"settings-btn",onClick:ae,children:"Open Settings"})]})}),e.jsxs("div",{className:"panel-footer",children:[e.jsx("span",{children:"Supported by "}),e.jsx("a",{href:"https://travel-code.com/",target:"_blank",rel:"noopener noreferrer",className:"sponsor-link",children:"Travel Code"}),e.jsx("span",{children:" — AI-powered corporate travel platform. Managing all corporate travel in one place."})]})]})}const Ie={"business-mistake":{name:"Business Mistake & Lesson",prompt:"Write a post about a business mistake and lessons learned — in the style of a founder who honestly documents their journey. Format: hook → crisis → solution → key takeaway."}},ct=[{value:"professional",label:"Professional"},{value:"raw",label:"Raw/Authentic"},{value:"bold",label:"Bold"}];function dt(){var t;try{return!!((t=chrome==null?void 0:chrome.runtime)!=null&&t.id)}catch{return!1}}async function ut(t){if(!dt())return{success:!1,error:"Extension was updated. Please refresh the page."};try{return await chrome.runtime.sendMessage(t)}catch(n){if(console.error("[PostAssistant] Error sending message:",n),n instanceof Error&&(n.message.includes("Extension context invalidated")||n.message.includes("Receiving end does not exist")))return{success:!1,error:"Extension was updated. Please refresh the page."};throw n}}function ht({onClose:t,onInsertPost:n}){const[o,s]=f.useState("business-mistake"),[a,r]=f.useState(""),[i,c]=f.useState(""),[l,d]=f.useState("raw"),[u,g]=f.useState(!1),[p,x]=f.useState(null),[b,w]=f.useState(null),[m,v]=f.useState(null),S=async()=>{var N;g(!0),v(null),x(null);try{let M="";o==="business-mistake"?M=Ie["business-mistake"].prompt:a.trim()?M=a.trim():M="Write a post about a business mistake and lessons learned — in the style of a founder who honestly documents their journey. Format: hook → crisis → solution → key takeaway.",console.log("[PostAssistant] Sending request:",{topic:M,tone:l,keyPoints:i.trim()||void 0});const I=await ut({type:"generate-post",data:{topic:M,tone:l,keyPoints:i.trim()||void 0}});if(console.log("[PostAssistant] Received response:",I),I.success&&((N=I.data)!=null&&N.post))x(I.data.post),w(I.data.originalPost||I.data.post);else{const q=I.error||"Failed to generate post";console.error("[PostAssistant] Error:",q),v(q)}}catch(M){v(M.message||"An error occurred")}finally{g(!1)}},C=()=>{p&&(n(p),t())},L=N=>{if(!N)return"";const q=(P=>{const A=document.createElement("div");return A.textContent=P,A.innerHTML})(N).split(`
`),T=[];for(let P=0;P<q.length;P++){let A=q[P];const W=A.trim();if(W===""){T.push("<br/>");continue}if(W.startsWith("### ")){T.push(`<h3>${W.substring(4)}</h3>`);continue}if(W.startsWith("## ")){T.push(`<h2>${W.substring(3)}</h2>`);continue}if(W.startsWith("# ")){T.push(`<h1>${W.substring(2)}</h1>`);continue}A=A.replace(/\*\*([^*]+?)\*\*/g,"<strong>$1</strong>"),A=A.replace(/__([^_]+?)__/g,"<strong>$1</strong>"),A=A.replace(new RegExp("(?<!\\*)\\*([^*]+?)\\*(?!\\*)","g"),"<em>$1</em>"),A=A.replace(new RegExp("(?<!_)_([^_]+?)_(?!_)","g"),"<em>$1</em>"),A=A.replace(/#(\w+)/g,'<span style="color: #70b5f9; font-weight: 600;">#$1</span>'),T.push(`<p>${A}</p>`)}return T.join("")};return e.jsxs("div",{className:"panel",children:[e.jsxs("div",{className:"panel-header",children:[e.jsxs("div",{className:"panel-title",children:[e.jsx("div",{className:"panel-icon",children:e.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("path",{d:"M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"}),e.jsx("circle",{cx:"7.5",cy:"14.5",r:"1.5"}),e.jsx("circle",{cx:"16.5",cy:"14.5",r:"1.5"})]})}),e.jsx("span",{children:"Post Assistant"})]}),e.jsx("button",{className:"close-btn",onClick:t,title:"Close",children:e.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M18 6L6 18M6 6l12 12"})})})]}),e.jsxs("div",{className:"panel-content",children:[e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Template"}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:[e.jsx("button",{onClick:()=>s("business-mistake"),style:{padding:"12px",background:o==="business-mistake"?"rgba(10, 102, 194, 0.2)":"rgba(255, 255, 255, 0.05)",border:`1px solid ${o==="business-mistake"?"rgba(10, 102, 194, 0.4)":"rgba(255, 255, 255, 0.1)"}`,borderRadius:"10px",color:"#fff",cursor:"pointer",textAlign:"left",fontSize:"13px",fontWeight:o==="business-mistake"?600:400},children:Ie["business-mistake"].name}),e.jsx("button",{onClick:()=>s("custom"),style:{padding:"12px",background:o==="custom"?"rgba(10, 102, 194, 0.2)":"rgba(255, 255, 255, 0.05)",border:`1px solid ${o==="custom"?"rgba(10, 102, 194, 0.4)":"rgba(255, 255, 255, 0.1)"}`,borderRadius:"10px",color:"#fff",cursor:"pointer",textAlign:"left",fontSize:"13px",fontWeight:o==="custom"?600:400},children:"Custom Topic"})]})]}),o==="custom"&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Topic"}),e.jsx("textarea",{className:"thoughts-input",placeholder:"Write about our new update, My thoughts on AI, etc.",value:a,onChange:N=>r(N.target.value),rows:3})]}),e.jsxs("div",{className:"section",children:[e.jsxs("div",{className:"section-label",children:["Key Points ",e.jsx("span",{className:"optional-label",children:"(optional)"})]}),e.jsx("textarea",{className:"thoughts-input",placeholder:"Add context, specific points, or details you want to include in the post...",value:i,onChange:N=>c(N.target.value),rows:3})]}),e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",children:"Tone"}),e.jsx("select",{className:"tone-select",value:l,onChange:N=>d(N.target.value),children:ct.map(N=>e.jsx("option",{value:N.value,children:N.label},N.value))})]}),e.jsx("button",{className:"generate-btn",onClick:S,disabled:u||o==="custom"&&!a.trim(),children:u?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"spinner"}),"Generating..."]}):e.jsxs(e.Fragment,{children:[e.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M13 2L3 14h9l-1 8 10-12h-9l1-8z"})}),"Generate Post"]})}),m&&e.jsxs("div",{className:"error-message",children:[e.jsxs("svg",{className:"error-icon",width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"10"}),e.jsx("path",{d:"M12 8v4M12 16h.01"})]}),e.jsx("span",{children:m})]}),p&&e.jsxs("div",{className:"section",children:[e.jsx("div",{className:"section-label",style:{marginBottom:"12px",fontSize:"14px",fontWeight:600},children:"Generated Post"}),e.jsx("div",{className:"post-preview",style:{maxHeight:"300px",overflowY:"auto",padding:"16px",background:"rgba(255, 255, 255, 0.03)",border:"1px solid rgba(255, 255, 255, 0.1)",borderRadius:"8px",fontSize:"14px",lineHeight:"1.6",color:"#fff",wordWrap:"break-word",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'},dangerouslySetInnerHTML:{__html:L(b||p)}}),e.jsxs("button",{className:"insert-btn",onClick:C,style:{marginTop:"16px",width:"100%",padding:"12px 16px",background:"linear-gradient(135deg, #0a66c2 0%, #004182 100%)",border:"none",borderRadius:"8px",color:"#fff",fontSize:"14px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",transition:"all 0.2s ease"},onMouseEnter:N=>{N.currentTarget.style.background="linear-gradient(135deg, #004182 0%, #0a66c2 100%)",N.currentTarget.style.transform="translateY(-1px)"},onMouseLeave:N=>{N.currentTarget.style.background="linear-gradient(135deg, #0a66c2 0%, #004182 100%)",N.currentTarget.style.transform="translateY(0)"},children:[e.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:e.jsx("path",{d:"M12 5v14M5 12l7-7 7 7"})}),"Insert into Post"]})]})]})]})}function Re(t){const n=document.createElement("button");return n.className="lai-ai-button",n.setAttribute("aria-label","Generate AI Comment"),n.innerHTML=`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
      <circle cx="7.5" cy="14.5" r="1.5"/>
      <circle cx="16.5" cy="14.5" r="1.5"/>
    </svg>
  `,n.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),t()}),n}function te(t,n){for(const o of n)try{const s=t.querySelector(o);if(s)return s}catch{console.warn(`[LinkedIn AI] Invalid selector: ${o}`)}return null}function Y(t,n){const o=[],s=new Set;for(const a of n)try{t.querySelectorAll(a).forEach(i=>{s.has(i)||(s.add(i),o.push(i))})}catch{}return o}function fe(t){let n=t.parentElement;for(;n;){if(n.querySelectorAll('[data-view-name="reaction-button"], [data-view-name="feed-comment-button"], [data-view-name="feed-share-button"], [data-view-name="feed-send-as-message-button"]').length>=3)return n;const s=n.querySelectorAll("button");let a=0;if(s.forEach(r=>{var c;const i=(c=r.textContent)==null?void 0:c.trim();["Like","Comment","Repost","Send"].includes(i||"")&&a++}),a>=3)return n;n=n.parentElement}return null}function mt(){const t=document.querySelectorAll('[data-view-name="feed-full-update"]');return t.length>0?Array.from(t):Y(document,[".feed-shared-update-v2",".occludable-update",'[data-urn*="activity"]','[data-urn*="ugcPost"]'])}function qe(t){var a;const n=t.querySelector('[data-view-name="feed-comment-button"]');if(n)return fe(n);const o=t.querySelectorAll("button");for(const r of o)if(((a=r.textContent)==null?void 0:a.trim())==="Comment")return fe(r);const s=t.querySelector('[data-view-name="reaction-button"]');return s?fe(s):te(t,[".social-actions-button",".feed-shared-social-action-bar",".social-details-social-activity",'[class*="social-actions"]'])}function ee(t){let n=t.trim();return n=n.replace(/…?see (more|less)/gi,""),n=n.replace(/…?\s*more\s*$/gi,""),n=n.replace(/…?voir (plus|moins)/gi,""),n=n.replace(/…?mehr (anzeigen|ausblenden)/gi,""),n=n.replace(/…?ещё/gi,""),n=n.replace(/…?больше/gi,""),n=n.replace(/…?mostrar (más|menos)/gi,""),n=n.replace(/[\d,.]+ (reactions?|likes?|comments?|reposts?|shares?)/gi,""),n=n.replace(/\b(Like|Comment|Repost|Send|Share|Reply)\b\s*/g,(o,s)=>/^\s*$/.test(n.substring(n.indexOf(o)-5,n.indexOf(o)))?"":o),n=n.replace(/\s+/g," ").trim(),n}function pt(t){const n=t.querySelectorAll('[data-view-name="feed-commentary"]');if(n.length>0){const c=[];for(const l of n){let d=!1,u=l.parentElement;for(let g=0;g<8&&!(!u||u===t);g++){if(Array.from(u.querySelectorAll("button")).find(x=>{var b;return((b=x.textContent)==null?void 0:b.trim())==="Reply"})){d=!0;break}u=u.parentElement}d||c.push(l)}if(c.length>0){let d=c[0].parentElement;for(;d&&d!==t;){const p=d.querySelectorAll('[data-view-name="feed-commentary"]'),x=Array.from(d.querySelectorAll("button")).some(b=>{var w;return((w=b.textContent)==null?void 0:w.trim())==="Reply"});if(p.length>=c.length&&!x)break;d=d.parentElement}if(d&&d!==t){const p=ee(d.textContent||"");if(p.length>10)return p}const u=[];c.forEach(p=>{var b;const x=(b=p.textContent)==null?void 0:b.trim();x&&u.push(x)});const g=ee(u.join(`
`));if(g.length>10)return g}}const o=qe(t);if(o){let c=o.previousElementSibling;for(;c;){const l=ee(c.textContent||""),d=c.querySelectorAll("img").length>0,u=l.length;if(u>30&&(!d||u>100))return l;c=c.previousElementSibling}}const s=te(t,['[class*="update-components-text"]',".feed-shared-update-v2__description",".feed-shared-text",".feed-shared-inline-show-more-text",".break-words",'[data-test-id="main-feed-activity-card__commentary"]']);if(s){const c=ee(s.textContent||"");if(c.length>10)return c}let a="",r=0;const i=t.children;for(let c=0;c<i.length;c++){const l=i[c];if(l===o||l.contains(o)||Array.from(l.querySelectorAll("button")).some(g=>{var p;return((p=g.textContent)==null?void 0:p.trim())==="Reply"}))continue;const u=ee(l.textContent||"");u.length>r&&u.length>30&&(a=u,r=u.length)}return a||""}function ve(t){var s,a;let n=!1;if(t.querySelectorAll('button, span[role="button"], a[role="button"], span.see-more, a.see-more').forEach(r=>{var l,d,u;const i=((l=r.textContent)==null?void 0:l.trim().toLowerCase())||"",c=((d=r.getAttribute("aria-label"))==null?void 0:d.toLowerCase())||"";(i==="more"||i==="...more"||i==="…more"||i==="…ещё"||i==="ещё"||i.includes("see more")||i.includes("show more")||i.includes("voir plus")||i.includes("mehr anzeigen")||i.includes("mostrar más")||i.includes("больше")||c.includes("see more")||c.includes("show more")||c.includes("expand"))&&(Array.from(((u=r.parentElement)==null?void 0:u.querySelectorAll("button"))||[]).some(p=>{var x;return((x=p.textContent)==null?void 0:x.trim())==="Reply"&&p!==r})||(r.click(),n=!0,console.log('[LinkedIn AI] Expanded "see more" text')))}),!n){const r=t.querySelectorAll('[data-view-name="feed-commentary"]');for(const i of r){const c=i.parentElement;if(c){const l=c.querySelector('button, span[role="button"]');l&&((s=l.textContent)!=null&&s.trim().toLowerCase().includes("more")||(a=l.textContent)!=null&&a.trim().toLowerCase().includes("ещё"))&&(l.click(),n=!0,console.log("[LinkedIn AI] Expanded truncated commentary"))}}}return n||Y(t,[".feed-shared-inline-show-more-text__see-more-less-toggle",".see-more",'[data-control-name="see_more"]','button[aria-label*="see more"]','button[aria-label*="Show more"]']).forEach(i=>{i.click(),n=!0}),n}async function gt(t){ve(t)&&(await new Promise(s=>setTimeout(s,500)),ve(t)&&await new Promise(s=>setTimeout(s,300)))}function xt(t){var r,i,c,l,d,u,g,p,x,b,w,m,v,S;const n=t.querySelector('[data-view-name="feed-actor-image"]');if(n){const C=n.parentElement;if(C){const N=C.querySelectorAll('a[href*="/in/"], a[href*="/company/"]');for(const M of N){if(M===n)continue;const I=(r=M.textContent)==null?void 0:r.trim();if(I&&I.length>=2&&I.length<100)return I.split(`
`)[0].trim()}}const L=(i=n.parentElement)==null?void 0:i.parentElement;if(L){const N=L.querySelectorAll('a[href*="/in/"], a[href*="/company/"]');for(const M of N){if(M===n)continue;const I=M.querySelectorAll("span");for(const T of I){const P=(c=T.textContent)==null?void 0:c.trim();if(P&&P.length>=2&&P.length<80&&!P.includes("•")&&!P.includes("followers"))return P}const q=(u=(d=(l=M.textContent)==null?void 0:l.trim())==null?void 0:d.split(`
`)[0])==null?void 0:u.trim();if(q&&q.length>=2&&q.length<80)return q}}}const o=t.querySelector('[data-view-name="feed-header-text"]');if(o){const C=(x=(p=(g=o.textContent)==null?void 0:g.trim())==null?void 0:p.split(`
`)[0])==null?void 0:x.trim();if(C&&C.length>=2)return C}const s=te(t,['[class*="update-components-actor__name"]',".feed-shared-actor__name",".feed-shared-actor__title",'a[class*="actor-name"]']);if(s){let C=((b=s.textContent)==null?void 0:b.trim())||"";if(C=C.split(`
`)[0].replace(/View.*profile/gi,"").replace(/•.*$/g,"").trim(),C)return C}const a=(w=t.children[0])==null?void 0:w.children;if(a)for(let C=0;C<Math.min(3,a.length);C++){const L=a[C],N=L==null?void 0:L.querySelector('a[href*="/in/"], a[href*="/company/"]');if(N){const M=(S=(v=(m=N.textContent)==null?void 0:m.trim())==null?void 0:v.split(`
`)[0])==null?void 0:S.trim();if(M&&M.length>=2&&M.length<80)return M}}return"Unknown Author"}function ft(t){var s,a,r,i,c;const n=t.querySelector('[data-view-name="feed-actor-image"]');if(n){const l=(s=n.parentElement)==null?void 0:s.parentElement;if(l){const d=l.querySelectorAll("span");for(const u of d){const g=(a=u.textContent)==null?void 0:a.trim();if(g&&g.length>=5&&g.length<200&&!g.includes("•")&&!g.match(/^\d+[hdwmy]$/)&&!g.match(/^\d+\s*(followers?|connections?)/i)&&!g.includes("Follow")&&!g.includes("Promoted")){const p=(r=n.parentElement)==null?void 0:r.querySelector('a[href*="/in/"], a[href*="/company/"]'),x=(i=p==null?void 0:p.textContent)==null?void 0:i.trim();if(x&&g!==x&&!g.startsWith(x))return g}}}}const o=te(t,['[class*="update-components-actor__description"]',".feed-shared-actor__description",".feed-shared-actor__sub-description",".update-components-actor__sublabel"]);if(o){let l=((c=o.textContent)==null?void 0:c.trim())||"";if(l=l.split("•")[0].trim(),l=l.replace(/\d+\s*(followers?|connections?)/gi,"").trim(),l)return l}return""}function bt(t){const n=t.querySelectorAll('[data-view-name="feed-update-image"] img, [data-view-name="image"] img');for(const a of n){const r=a;if(r.closest('[data-view-name="feed-actor-image"]')||r.closest('[data-view-name="feed-header-actor-image"]'))continue;const i=r.src||r.getAttribute("data-delayed-url")||r.getAttribute("data-src");if(!i||i.startsWith("data:")||i.includes("/icons/")||i.includes("ghost-organization")||i.includes("ghost-person"))continue;const c=r.naturalWidth||r.width,l=r.naturalHeight||r.height;if(!(c&&l&&(c<100||l<100)))return i}const o=t.querySelectorAll("img");for(const a of o){const r=a;if(r.closest('[data-view-name="feed-actor-image"]')||r.closest('[data-view-name="feed-header-actor-image"]')||r.closest('[data-view-name="identity-module"]'))continue;const i=r.src||r.getAttribute("data-delayed-url");if(!i||i.startsWith("data:")||i.includes("/icons/")||i.includes("ghost-")||i.includes("logo"))continue;const c=r.naturalWidth||r.width,l=r.naturalHeight||r.height;if(c&&l&&(c<100||l<100))continue;const d=r.getBoundingClientRect();if(d.width>150&&d.height>100)return i}const s=[".update-components-image__image",".feed-shared-image__image",".ivm-view-attr__img--centered",'[class*="update-components-image"] img',"img[data-delayed-url]"];for(const a of s){const r=t.querySelectorAll(a);for(const i of r){const c=i;if(c.closest('.feed-shared-actor, [class*="actor"]'))continue;const l=c.src||c.getAttribute("data-delayed-url");if(l&&!l.startsWith("data:")&&!l.includes("/icons/"))return l}}}function We(){return Y(document,['[role="textbox"][contenteditable="true"]','.ql-editor[contenteditable="true"]','[data-placeholder="Add a comment…"]','[data-placeholder="Add a comment..."]','[aria-placeholder="Add a comment…"]','[aria-placeholder="Add a comment..."]','[contenteditable="true"][aria-label*="comment" i]','[contenteditable="true"][aria-label*="reply" i]','.editor-content [contenteditable="true"]']).find(s=>{const a=s.getBoundingClientRect();return a.width>0&&a.height>0})||null}function vt(t,n){try{const o=t.querySelectorAll('a[data-attribute-index], span[data-mention], [class*="mention"], a[href*="/in/"]'),s=[];o.forEach(u=>{s.push(u.cloneNode(!0))});const r=(t.textContent||"").match(/^(@[\w\s]+)\s*/),i=r?r[1]:null;t.innerHTML="",s.length>0?s.forEach(u=>{t.appendChild(u),t.appendChild(document.createTextNode(" "))}):i&&t.appendChild(document.createTextNode(i+" "));const c=document.createElement("p");c.textContent=n,t.appendChild(c),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:n})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0})),t.focus();const l=window.getSelection(),d=document.createRange();return d.selectNodeContents(t),d.collapse(!1),l==null||l.removeAllRanges(),l==null||l.addRange(d),!0}catch(o){return console.error("[LinkedIn AI] Failed to inject text:",o),!1}}function yt(t){var a,r,i,c,l,d,u,g;const n=t.querySelectorAll('a[href*="/in/"]');for(const p of n){if(p.closest('[data-view-name="feed-commentary"]'))continue;const b=p.querySelector('span[aria-hidden="true"]');if(b){const v=(a=b.textContent)==null?void 0:a.trim();if(v&&v.length>=2&&v.length<100)return v}const w=p.querySelectorAll("span");for(const v of w){const S=(r=v.textContent)==null?void 0:r.trim();if(S&&S.length>=2&&S.length<80&&!S.includes("•")&&!S.includes("1st")&&!S.includes("2nd")&&!S.includes("3rd"))return S}const m=(l=(c=(i=p.textContent)==null?void 0:i.trim())==null?void 0:c.split(`
`)[0])==null?void 0:l.trim();if(m&&m.length>=2&&m.length<80&&!m.includes("•"))return m}const s=te(t,[".comments-post-meta__name-text",".comments-post-meta__name",'[class*="comments-post-meta__name"]']);if(s){const p=(g=(u=(d=s.textContent)==null?void 0:d.trim())==null?void 0:u.split(`
`)[0])==null?void 0:g.trim();if(p&&p.length>=2)return p}return"Unknown"}function oe(t){var n,o,s,a;try{if((((n=t.textContent)==null?void 0:n.trim())||"").length<10)return null;const i=yt(t);let c="";const l=t.querySelectorAll('[data-view-name="feed-commentary"]');if(l.length>0){const u=[];l.forEach(g=>{var x;const p=(x=g.textContent)==null?void 0:x.trim();p&&u.push(p)}),c=u.join(" ").trim()}if(!c||c.length<5){const u=[],g=document.createTreeWalker(t,NodeFilter.SHOW_TEXT,{acceptNode:x=>{var m;const b=x.parentElement;if(!b||b.tagName==="BUTTON"||b.closest('a[href*="/in/"]')&&!b.closest('[data-view-name="feed-commentary"]')||b.closest("time"))return NodeFilter.FILTER_REJECT;const w=((m=x.textContent)==null?void 0:m.trim())||"";return w.length<3||["Like","Reply","Report","1st","2nd","3rd","•"].includes(w)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let p;for(;p=g.nextNode();){const x=((o=p.textContent)==null?void 0:o.trim())||"";x.length>=3&&x!==i&&u.push(x)}u.length>0&&(c=u.sort((x,b)=>b.length-x.length)[0])}if(!c||c.length<5){const u=te(t,[".comments-comment-item__main-content",'[class*="comment-item__main-content"]',".comments-comment-item-content-body",".update-components-text"]);c=((s=u==null?void 0:u.textContent)==null?void 0:s.trim())||""}if(c=ee(c),!c||c.length<5)return null;const d=!!t.closest('[class*="replies-list"]')||!!((a=t.parentElement)!=null&&a.closest('[class*="replies"]'));return{authorName:i,authorHeadline:"",content:c,isReply:d}}catch(r){return console.error("[LinkedIn AI] Error extracting comment:",r),null}}function ze(t){const n=Y(t,[".comments-comment-item",".comments-comment-entity",'article[class*="comments-comment-item"]']);if(n.length>0)return n;const o=Array.from(t.querySelectorAll("button")).filter(r=>{var c;return((c=r.textContent)==null?void 0:c.trim())==="Reply"}),s=[],a=new Set;for(const r of o){let i=r.parentElement;for(let c=0;c<6&&i;c++){const l=i.querySelector('a[href*="/in/"]'),d=i.querySelector('[data-view-name="feed-commentary"]');if(l&&(d||i.textContent.length>20)){a.has(i)||(a.add(i),s.push(i));break}i=i.parentElement}}return s}function wt(t,n=5){const o=[],s=new Set,a=ze(t);for(const r of a){if(o.length>=n)break;if(!t.contains(r))continue;const i=oe(r);if(i&&i.content.length>5){const c=i.content.slice(0,50).toLowerCase();s.has(c)||(s.add(c),o.push(i))}}return o}function jt(t){var u,g,p,x;const n=We();if(!n)return{isReply:!1,parentComment:null,threadParticipants:[]};let o=n.closest('[class*="replies-list"], [class*="replies"]');const s=n.querySelector('a[href*="/in/"], [data-mention]'),a=((u=n.getAttribute("aria-label"))==null?void 0:u.toLowerCase())||"",r=((g=n.getAttribute("aria-placeholder"))==null?void 0:g.toLowerCase())||"",i=a.includes("reply")||r.includes("reply");if(!o&&!s&&!i)return{isReply:!1,parentComment:null,threadParticipants:[]};let c=null;const l=[],d=ze(t);if(o){for(const b of d)if(b.contains(o)){c=oe(b),c&&l.push(c.authorName);break}}if(!c&&s){const b=(x=(p=s.textContent)==null?void 0:p.trim())==null?void 0:x.replace("@","");if(b)for(const w of d){const m=oe(w);if(m&&m.authorName.toLowerCase().includes(b.toLowerCase())){c=m,l.push(m.authorName);break}}}if(!c){const b=n.getBoundingClientRect();let w=null,m=1/0;for(const v of d){const S=v.getBoundingClientRect(),C=Math.abs(S.bottom-b.top);C<m&&C<200&&(m=C,w=oe(v))}w&&(c=w,l.push(w.authorName))}for(const b of d){const w=oe(b);w&&w.authorName!=="Unknown"&&!l.includes(w.authorName)&&l.push(w.authorName)}return{isReply:!0,parentComment:c,threadParticipants:l}}function kt(t){const n=t.closest('[data-view-name="feed-full-update"]');if(n)return n;const o=[".feed-shared-update-v2",".occludable-update",'[data-urn*="activity"]','[data-urn*="ugcPost"]'];for(const s of o){const a=t.closest(s);if(a)return a}return t}function Ct(t){if(t.closest('.comments-comment-item, .comments-comment-entity, [class*="comments-comment-item"]'))return!0;const o=t.parentElement;if(o&&Array.from(o.querySelectorAll("button")).find(r=>{var i;return((i=r.textContent)==null?void 0:i.trim())==="Reply"}))return!0;let s=t.parentElement;for(let a=0;a<4&&s;a++){const r=s.querySelectorAll("button");let i=!1,c=!1;if(r.forEach(l=>{var u,g;const d=(u=l.textContent)==null?void 0:u.trim();d==="Reply"&&(i=!0),d==="Like"&&!((g=l.getAttribute("data-view-name"))!=null&&g.includes("reaction"))&&(c=!0)}),i&&c)return!0;s=s.parentElement}return!1}async function Nt(t){try{const n=kt(t);if(!n)return console.warn("[LinkedIn AI] Could not find main post container"),null;const o=Ct(t),s=xt(n),a=ft(n);await gt(n);const r=pt(n);if(!r)return console.warn("[LinkedIn AI] Could not extract post content"),null;const i=bt(n),c=wt(n,5);let l;const d=[];if(o){const g=jt(n);l=g.parentComment||void 0,d.push(...g.threadParticipants)}for(const g of c)d.includes(g.authorName)||d.push(g.authorName);const u={mode:o?"reply":"post",parentComment:l,existingComments:c,threadParticipants:d};return console.log("[LinkedIn AI] Scraped data:",{authorName:s,authorHeadline:a,postContentLength:r.length,hasImage:!!i,isReplyMode:o,parentComment:l==null?void 0:l.authorName,existingCommentsCount:c.length}),{authorName:s,authorHeadline:a,postContent:r,imageUrl:i,threadContext:u}}catch(n){return console.error("[LinkedIn AI] Error scraping post data:",n),null}}function ge(){return Y(document,['[role="dialog"][aria-label*="Start a post" i]','[role="dialog"][aria-label*="Create a post" i]','[role="dialog"][aria-label*="post" i]','[data-view-name*="share"]',".share-box-feed-entry__modal",".share-box__modal",".artdeco-modal",'[class*="share-box"]','[class*="share-modal"]']).find(s=>{const a=s.getBoundingClientRect();return a.width>0&&a.height>0})||null}function Ce(){const t=['[role="textbox"][contenteditable="true"]','.ql-editor[contenteditable="true"]','[data-placeholder*="What do you want to talk about"]','[aria-placeholder*="What do you want to talk about"]','[contenteditable="true"][aria-label*="post" i]','[contenteditable="true"][aria-label*="Text editor" i]',".ql-container .ql-editor"],n=ge();if(n){const a=Y(n,t);if(a.length>0){const r=a.find(i=>{const c=i.getBoundingClientRect();return c.width>0&&c.height>0});if(r)return r}}return Y(document,t).find(a=>{const r=a.getBoundingClientRect();return r.width>0&&r.height>0})||null}function St(){var s;const t=ge();if(!t)return null;const o=Y(t,[".share-box__toolbar",".share-box-feed-entry__toolbar",".share-box__footer",".share-creation-state__toolbar",'[class*="share-box"][class*="toolbar"]','[class*="share-box"][class*="footer"]',".artdeco-modal__actionbar"]);if(o.length===0){const a=t.querySelectorAll("button");for(const r of a){const i=((s=r.getAttribute("aria-label"))==null?void 0:s.toLowerCase())||"";if(i.includes("photo")||i.includes("video")||i.includes("media"))return r.parentElement}}return o[0]||null}function At(t,n){try{t.innerHTML="";const o=document.createElement("p");o.textContent=n,t.appendChild(o),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:n})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0})),t.focus();const s=window.getSelection(),a=document.createRange();return a.selectNodeContents(t),a.collapse(!1),s==null||s.removeAllRanges(),s==null||s.addRange(a),!0}catch(o){return console.error("[LinkedIn AI] Failed to inject text into post editor:",o),!1}}function Mt(){const t=window.getSelection();return(t==null?void 0:t.toString().trim())||""}function Et(){const t=Mt();return!t||t.length<10?null:{authorName:"Selected Text",authorHeadline:"",postContent:t,threadContext:{mode:"post",existingComments:[],threadParticipants:[]}}}const U={messageItem:[".msg-s-message-list__event",".msg-s-event-listitem",'[class*="msg-s-event-listitem"]'],messageContent:[".msg-s-event-listitem__body",".msg-s-message-group__content",'[class*="msg-s-event-listitem__body"]',"p.msg-s-event-listitem__body"],messageTimestamp:[".msg-s-message-list__time-heading",".msg-s-message-group__timestamp","time"],participantName:[".msg-overlay-bubble-header__title",".msg-thread__link-to-profile",".msg-entity-lockup__entity-title",'[class*="msg-overlay-bubble-header__title"]',"h2.msg-entity-lockup__entity-title"],participantHeadline:[".msg-entity-lockup__entity-subtitle",".msg-overlay-bubble-header__subtitle",'[class*="msg-entity-lockup__entity-subtitle"]'],messageInput:[".msg-form__contenteditable",".msg-form__message-texteditor",'[contenteditable="true"][role="textbox"]',"div.msg-form__contenteditable"],myMessageIndicator:[".msg-s-message-group--selfsend",'[class*="selfsend"]']};function se(t,n){for(const o of n){const s=t.querySelector(o);if(s)return s}return null}function It(t,n){for(const o of n){const s=t.querySelectorAll(o);if(s.length>0)return Array.from(s)}return[]}function pe(){return window.location.pathname.includes("/messaging")}function _t(){const t=document.querySelector(".global-nav__me-photo, .feed-identity-module__actor-meta"),n=t==null?void 0:t.getAttribute("alt");if(n)return n;const o=document.querySelector(".global-nav__me .t-14");return o!=null&&o.textContent?o.textContent.trim():"Me"}function Fe(){var o,s;const t=se(document,U.participantName),n=se(document,U.participantHeadline);return{name:((o=t==null?void 0:t.textContent)==null?void 0:o.trim())||"Unknown",headline:((s=n==null?void 0:n.textContent)==null?void 0:s.trim())||void 0}}function Tt(t){const n=t.closest(".msg-s-message-group");if(n){for(const o of U.myMessageIndicator)if(n.matches(o)||n.querySelector(o))return!0}for(const o of U.myMessageIndicator)if(t.matches(o)||t.closest(o))return!0;return!1}function Pt(t=10){var i,c;const n=[],o=_t(),s=Fe(),r=It(document,U.messageItem).slice(-t);for(const l of r){const d=se(l,U.messageContent),u=(i=d==null?void 0:d.textContent)==null?void 0:i.trim();if(!u||u.length<2)continue;const g=Tt(l),p=se(l,U.messageTimestamp),x=(c=p==null?void 0:p.textContent)==null?void 0:c.trim();n.push({sender:g?"me":"other",senderName:g?o:s.name,content:u,timestamp:x})}return n}function Bt(t){if(t.length===0)return"neutral";const o=t.slice(-5).map(d=>d.content.toLowerCase()).join(" "),a=["great","awesome","thanks","thank you","excellent","love","excited","looking forward","happy","pleased"].some(d=>o.includes(d)),i=["price","cost","budget","deal","offer","proposal","terms","negotiate","discount","rate"].some(d=>o.includes(d)),c=t[t.length-1],l=c.sender==="me";return c.content.length<20,i?"negotiating":a?"positive":l&&t.length>3?"cold":"neutral"}function Lt(t){if(t.length===0)return"General conversation";const n=t.map(s=>s.content).join(" ").toLowerCase(),o=[{pattern:/job|position|opportunity|hiring|role|career/i,topic:"Job opportunity discussion"},{pattern:/project|collaboration|partner|work together/i,topic:"Collaboration proposal"},{pattern:/service|solution|help|consulting/i,topic:"Business services"},{pattern:/meeting|call|schedule|calendar|zoom|coffee/i,topic:"Scheduling a meeting"},{pattern:/price|cost|budget|quote|proposal/i,topic:"Pricing negotiation"},{pattern:/connect|networking|intro|introduction/i,topic:"Networking"},{pattern:/question|help|advice|recommend/i,topic:"Seeking advice"},{pattern:/follow.?up|checking in|touch base/i,topic:"Follow-up conversation"}];for(const{pattern:s,topic:a}of o)if(s.test(n))return a;return"Professional discussion"}async function Rt(){try{if(!pe())return console.log("[LinkedIn AI] Not on messaging page"),null;const t=Fe(),n=Pt(10);if(n.length===0)return console.log("[LinkedIn AI] No messages found in conversation"),null;const o=n[n.length-1],s=Lt(n),a=Bt(n);return console.log("[LinkedIn AI] Scraped conversation:",{participant:t.name,messageCount:n.length,topic:s,sentiment:a,lastMessageFrom:o.sender}),{participantName:t.name,participantHeadline:t.headline,messages:n,topic:s,sentiment:a,lastMessageFrom:o.sender}}catch(t){return console.error("[LinkedIn AI] Error scraping conversation:",t),null}}function qt(){return se(document,U.messageInput)}function Wt(t){const n=qt();if(!n)return console.error("[LinkedIn AI] Message input not found"),!1;try{n.focus(),n.innerHTML="";const o=document.createElement("p");return o.textContent=t,n.appendChild(o),n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0})),setTimeout(()=>{n.innerText=t,n.dispatchEvent(new Event("input",{bubbles:!0}))},50),!0}catch(o){return console.error("[LinkedIn AI] Error injecting text:",o),!1}}const zt=`
  .lai-ai-button {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(10, 102, 194, 0.3);
    margin-left: 8px;
  }
  
  .lai-ai-button:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(10, 102, 194, 0.4);
  }
  
  .lai-ai-button:active {
    transform: scale(0.95);
  }
  
  .lai-ai-button svg {
    width: 18px;
    height: 18px;
    color: white;
  }

  .lai-ai-button::after {
    content: 'AI Comment';
    position: absolute;
    bottom: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%) scale(0.9);
    padding: 6px 10px;
    background: #1a1a2e;
    color: white;
    font-size: 12px;
    font-weight: 500;
    border-radius: 6px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }

  .lai-ai-button::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    border: 6px solid transparent;
    border-top-color: #1a1a2e;
    opacity: 0;
    pointer-events: none;
    transition: all 0.2s ease;
  }

  .lai-ai-button:hover::after,
  .lai-ai-button:hover::before {
    opacity: 1;
    transform: translateX(-50%) scale(1);
  }

  .lai-ai-button:hover::before {
    transform: translateX(-50%);
  }

  .lai-selection-btn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 16px;
    background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
    border: none;
    border-radius: 12px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(10, 102, 194, 0.4);
    z-index: 999998;
    transition: all 0.2s ease;
  }

  .lai-selection-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 24px rgba(10, 102, 194, 0.5);
  }

  .lai-selection-btn svg {
    width: 18px;
    height: 18px;
  }

  /* Messaging AI Button */
  .lai-messaging-ai-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 6px rgba(10, 102, 194, 0.25);
    margin: 0 4px;
    flex-shrink: 0;
    vertical-align: middle;
  }
  
  .lai-messaging-ai-button:hover {
    transform: scale(1.1);
    box-shadow: 0 3px 10px rgba(10, 102, 194, 0.4);
    background: linear-gradient(135deg, #004182 0%, #0066a2 100%);
  }
  
  .lai-messaging-ai-button:active {
    transform: scale(0.95);
  }
  
  .lai-messaging-ai-button svg {
    width: 16px;
    height: 16px;
    color: white;
  }

  /* Post Assistant Sparkle Button */
  .lai-post-sparkle-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 8px;
    background: linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%);
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
    margin: 0 4px;
    flex-shrink: 0;
  }
  
  .lai-post-sparkle-button:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
    background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%);
  }
  
  .lai-post-sparkle-button:active {
    transform: scale(0.95);
  }
  
  .lai-post-sparkle-button svg {
    width: 18px;
    height: 18px;
    color: white;
  }
`;let z=null,J=null,G=null,Ne=null;function Ft(){if(document.getElementById("lai-content-styles"))return;const t=document.createElement("style");t.id="lai-content-styles",t.textContent=zt,document.head.appendChild(t)}function Q(){if(J)return J;J=document.createElement("div"),J.id="lai-panel-container";const t=J.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=Dt(),t.appendChild(n);const o=document.createElement("div");return o.id="lai-panel-mount",t.appendChild(o),document.body.appendChild(J),J}function me(t,n){const a=Q().shadowRoot.getElementById("lai-panel-mount");z||(z=je.createRoot(a)),z.render(e.jsx(ke.StrictMode,{children:e.jsx(rt,{postData:t,isScanning:n,onClose:X,onInsertComment:Kt})}))}function be(t,n){const a=Q().shadowRoot.getElementById("lai-panel-mount");z||(z=je.createRoot(a)),z.render(e.jsx(ke.StrictMode,{children:e.jsx(lt,{conversationContext:t,isScanning:n,onClose:X,onInsertReply:$t})}))}function Ht(){const o=Q().shadowRoot.getElementById("lai-panel-mount");z||(z=je.createRoot(o)),z.render(e.jsx(ke.StrictMode,{children:e.jsx(ht,{onClose:X,onInsertPost:Ot})}))}function $t(t){Wt(t)&&X()}function Ot(t){const n=Ce();n?At(n,t)&&X():navigator.clipboard.writeText(t).then(()=>{alert("Post copied to clipboard! Paste it into the post editor."),X()}).catch(()=>{console.error("[LinkedIn AI] Failed to copy to clipboard")})}function Vt(){Q(),Ht()}function Gt(){Q(),be(null,!0),(async()=>{await new Promise(n=>setTimeout(n,200));const t=await Rt();be(t||null,!1)})()}function Ut(t){var a;const n=['[role="textbox"][contenteditable="true"]','[contenteditable="true"][aria-label*="comment" i]','[contenteditable="true"][aria-label*="reply" i]','[aria-placeholder="Add a comment…"]','[aria-placeholder="Add a comment..."]','[data-placeholder="Add a comment…"]','[data-placeholder="Add a comment..."]','.ql-editor[contenteditable="true"]',".comments-comment-box__form-container .ql-editor",".comments-comment-texteditor .ql-editor",'.editor-content [contenteditable="true"]'];for(const r of n){const i=t.querySelectorAll(r);for(const c of i){const l=c.getBoundingClientRect();if(l.width>0&&l.height>0)return c}}const o=[],s=t.getBoundingClientRect();for(const r of n){const i=document.querySelectorAll(r);for(const c of i){const l=c.getBoundingClientRect();if(l.width>0&&l.height>0){const d=Math.abs(l.top-s.top);o.push({box:c,distance:d})}}}return o.sort((r,i)=>r.distance-i.distance),((a=o[0])==null?void 0:a.box)||null}function Yt(t,n=!1){Q(),me(null,!0),Se(),(async()=>{const o=t.closest('[data-view-name="feed-full-update"]')||t.closest(".feed-shared-update-v2")||t.closest(".occludable-update")||t.closest('[data-urn*="activity"]');o&&ve(o);const s=n?400:200;await new Promise(r=>setTimeout(r,s)),Ne=Ut(t);const a=await Nt(t);a?me(a,!1):(me(null,!1),Jt())})()}function Xt(t){Q();const n={...t,threadContext:t.threadContext||{mode:"post",existingComments:[],threadParticipants:[]}};me(n,!1),Se()}function X(){z&&(z.unmount(),z=null),Ne=null}function Kt(t){let n=Ne;if(n){const o=n.getBoundingClientRect();(!document.body.contains(n)||o.width===0&&o.height===0)&&(n=null)}if(n||(n=We()),n&&vt(n,t)){X();return}navigator.clipboard.writeText(t).then(()=>{alert("Comment copied to clipboard! Paste it into the comment box."),X()}).catch(()=>{console.error("[LinkedIn AI] Failed to copy to clipboard")})}function He(t,n=!1){Yt(t,n)}function Jt(){G||(G=document.createElement("button"),G.className="lai-selection-btn",G.innerHTML=`
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M4 7V4h16v3"/>
      <path d="M9 20h6"/>
      <path d="M12 4v16"/>
    </svg>
    Analyze Selected Text
  `,G.addEventListener("click",()=>{const t=Et();t?(Xt(t),Se()):alert("Please highlight some text from a LinkedIn post first.")}),document.body.appendChild(G))}function Se(){G&&(G.remove(),G=null)}function ye(){mt().forEach(n=>{const o=n;if(o.dataset.laiProcessed)return;o.dataset.laiProcessed="true";const s=qe(n);if(s){const a=Array.from(s.querySelectorAll("button")).some(i=>{var c;return((c=i.textContent)==null?void 0:c.trim())==="Reply"});if(s.closest('.comments-comment-item, .comments-comment-entity, [class*="comments-comment-item"], .comments-comments-list')||a)return;if(!s.querySelector(".lai-ai-button")){const i=Re(()=>{He(i,!1)});s.appendChild(i)}}$e(n)})}function Qt(t){var s,a;const n=t.querySelectorAll('button, span[role="button"]');for(const r of n)if(((s=r.textContent)==null?void 0:s.trim())==="Reply"){r.click(),console.log("[LinkedIn AI] Clicked Reply button (by text)");return}const o=(a=t.querySelector('button[aria-label*="Reply"], button[aria-label*="reply"], [class*="reply-action"], .comments-comment-social-bar__reply-action'))==null?void 0:a.closest("button");o&&(o.click(),console.log("[LinkedIn AI] Clicked Reply button (by selector)"))}function $e(t){const n=t.querySelectorAll('.comments-comment-item, .comments-comment-entity, article[class*="comments-comment"]');if(n.length>0){n.forEach(s=>{_e(s)});return}const o=Array.from(t.querySelectorAll("button")).filter(s=>{var a;return((a=s.textContent)==null?void 0:a.trim())==="Reply"});for(const s of o){let a=s.parentElement;for(let r=0;r<6&&a;r++){const i=a.querySelector('a[href*="/in/"]'),c=a.querySelector('[data-view-name="feed-commentary"]');if(i&&(c||a.textContent.length>20)){_e(a,s);break}a=a.parentElement}}}function _e(t,n){var a;const o=t;if(o.dataset.laiCommentProcessed)return;o.dataset.laiCommentProcessed="true";let s=null;if(n){s=n.parentElement;let r=n.parentElement;for(let i=0;i<3&&r;i++){const c=r.querySelectorAll("button");let l=!1,d=!1;if(c.forEach(u=>{var p;const g=(p=u.textContent)==null?void 0:p.trim();g==="Like"&&(l=!0),g==="Reply"&&(d=!0)}),l&&d){s=r;break}r=r.parentElement}}if(!s){const r=[".comments-comment-social-bar",'[class*="comment-social-bar"]',".comments-comment-item__action-bar"];for(const i of r)if(s=t.querySelector(i),s)break}if(!s){const r=t.querySelectorAll("button");for(const i of r){const c=(a=i.textContent)==null?void 0:a.trim();if(c==="Reply"||c==="Like"){s=i.parentElement;break}}}if(s&&!s.querySelector(".lai-ai-button")){const r=Re(()=>{Qt(t),setTimeout(()=>{He(r,!0)},300)});r.style.width="28px",r.style.height="28px",r.style.marginLeft="4px",s.appendChild(r)}}function Zt(){document.querySelectorAll('[data-view-name="feed-full-update"], .feed-shared-update-v2, .occludable-update, [data-urn*="activity"]').forEach(n=>{$e(n)})}function he(){const t=document.createElement("button");return t.className="lai-post-sparkle-button",t.setAttribute("aria-label","AI Post Assistant"),t.title="AI Post Assistant",t.innerHTML=`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
      <circle cx="7.5" cy="14.5" r="1.5"/>
      <circle cx="16.5" cy="14.5" r="1.5"/>
    </svg>
  `,t.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Vt()}),t}function D(){const t=ge();if(document.querySelector(".lai-post-sparkle-button"))return;let n=St();if(!n){const s=[".share-box__toolbar",".share-box-feed-entry__toolbar",".share-box__footer",".share-creation-state__toolbar",".share-box__actions",".share-box-feed-entry__actions",".artdeco-modal__actionbar",'[class*="share-box"][class*="toolbar"]','[class*="share-box"][class*="footer"]','[class*="share-box"][class*="actions"]'];for(const a of s){const r=document.querySelector(a);if(r){const i=r.getBoundingClientRect();if(i.width>0&&i.height>0){n=r;break}}}}if(n){const s=he();n.insertBefore(s,n.firstChild),console.log("[LinkedIn AI] Post Assistant button injected into toolbar");return}const o=Ce();if(o&&o.parentElement){let s=o.parentElement;for(let a=0;a<3;a++)if(s){const r=s.querySelector('[class*="toolbar"], [class*="footer"], [class*="actions"], [class*="button"]');if(r){const i=he();r.insertBefore(i,r.firstChild),console.log("[LinkedIn AI] Post Assistant button injected near editor");return}s=s.parentElement}if(o.parentElement){const a=he();o.parentElement.insertBefore(a,o.nextSibling),console.log("[LinkedIn AI] Post Assistant button injected after editor");return}}if(t){const s=he();s.style.position="absolute",s.style.top="10px",s.style.right="10px",s.style.zIndex="10000",t.appendChild(s),console.log("[LinkedIn AI] Post Assistant button injected as absolute positioned")}}function we(){const t=[".msg-form__footer",".msg-form__left-actions",".msg-form__content-container",".msg-form"];let n=null;for(const i of t)if(n=document.querySelector(i),n)break;if(!n){console.log("[LinkedIn AI] Message form footer not found");return}if(document.querySelector(".lai-messaging-ai-button"))return;const o=document.createElement("button");o.className="lai-messaging-ai-button",o.type="button",o.title="AI Reply Assistant",o.innerHTML=`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"/>
    </svg>
  `,o.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),Gt()});const s=document.querySelector(".msg-form__left-actions");if(s){s.insertBefore(o,s.firstChild),console.log("[LinkedIn AI] Messaging AI button injected into left actions");return}const a=document.querySelector(".msg-form__footer");if(a){a.insertBefore(o,a.firstChild),console.log("[LinkedIn AI] Messaging AI button injected into footer");return}const r=document.querySelector('.msg-form__send-button, .msg-form__send-btn, button[type="submit"][class*="send"]');if(r&&r.parentElement){r.parentElement.insertBefore(o,r),console.log("[LinkedIn AI] Messaging AI button injected before send button");return}console.log("[LinkedIn AI] Could not find suitable location for messaging button")}function Te(){Ft(),pe()?we():ye(),D(),setInterval(()=>{(ge()||Ce())&&D()},500);let n=null;const o=()=>{n&&clearTimeout(n),n=setTimeout(()=>{pe()?we():(ye(),Zt()),D()},300)};new MutationObserver(a=>{let r=!1,i=!1;a.forEach(c=>{c.addedNodes.length>0&&(c.addedNodes.forEach(l=>{var d,u,g,p,x,b,w,m,v;l instanceof Element&&(((u=(d=l.getAttribute)==null?void 0:d.call(l,"data-view-name"))!=null&&u.includes("feed")||(g=l.querySelector)!=null&&g.call(l,'[data-view-name="feed-full-update"]')||(p=l.querySelector)!=null&&p.call(l,'[data-view-name="feed-comment-button"]')||(x=l.querySelector)!=null&&x.call(l,"button"))&&(r=!0),((b=l.matches)!=null&&b.call(l,'.comments-comment-item, .comments-comment-entity, [class*="comment"], .feed-shared-update-v2')||(w=l.querySelector)!=null&&w.call(l,".comments-comment-item, .comments-comment-entity"))&&(r=!0),((m=l.matches)!=null&&m.call(l,'[role="dialog"], .artdeco-modal, [class*="share-box"], [class*="share-modal"]')||(v=l.querySelector)!=null&&v.call(l,'[role="dialog"][aria-label*="post" i], .artdeco-modal, [class*="share-box"]'))&&(i=!0))}),r=!0)}),r&&o(),i&&(setTimeout(()=>D(),100),setTimeout(()=>D(),500),setTimeout(()=>D(),1e3))}).observe(document.body,{childList:!0,subtree:!0})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Te):Te();let Pe=location.href;new MutationObserver(()=>{location.href!==Pe&&(Pe=location.href,setTimeout(()=>{pe()?we():ye()},1e3))}).observe(document,{subtree:!0,childList:!0});function Dt(){return`
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    .panel {
      position: fixed;
      top: 80px;
      right: 20px;
      width: 400px;
      max-height: calc(100vh - 100px);
      background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
      border-radius: 16px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      color: #fff;
      z-index: 999999;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    
    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(30px) scale(0.95);
      }
      to {
        opacity: 1;
        transform: translateX(0) scale(1);
      }
    }
    
    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      background: rgba(255, 255, 255, 0.02);
      cursor: move;
      flex-shrink: 0;
    }
    
    .panel-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: 14px;
    }
    
    .panel-icon {
      width: 32px;
      height: 32px;
      border-radius: 8px;
      background: linear-gradient(135deg, #0a66c2 0%, #00a0dc 100%);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .panel-icon svg {
      width: 18px;
      height: 18px;
      color: white;
    }

    .panel-icon.messaging {
      background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%);
    }

    /* Messaging Context Styles */
    .messaging-context {
      padding: 12px 16px;
      background: rgba(124, 58, 237, 0.1);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .context-scanning {
      display: flex;
      align-items: center;
      gap: 8px;
      color: #a78bfa;
      font-size: 13px;
    }

    .context-participant {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
    }

    .context-label {
      font-size: 11px;
      color: #9ca3af;
    }

    .context-value {
      font-size: 14px;
      font-weight: 600;
      color: #f3f4f6;
    }

    .context-headline {
      font-size: 12px;
      color: #9ca3af;
      margin-bottom: 8px;
    }

    .context-stats {
      display: flex;
      gap: 12px;
      margin-top: 8px;
    }

    .context-stats .stat {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      color: #9ca3af;
    }

    .sentiment-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #6b7280;
    }

    .sentiment-dot.positive {
      background: #22c55e;
    }

    .sentiment-dot.neutral {
      background: #eab308;
    }

    .sentiment-dot.negotiating {
      background: #f97316;
    }

    .sentiment-dot.cold {
      background: #6b7280;
    }

    .ai-summary {
      margin-top: 10px;
      padding: 10px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 8px;
      border-left: 3px solid #a855f7;
    }

    .summary-topic {
      font-size: 12px;
      font-weight: 500;
      color: #e5e7eb;
      margin-bottom: 6px;
    }

    .summary-action {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: #a78bfa;
    }

    .context-empty {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 16px;
      color: #6b7280;
      font-size: 13px;
      text-align: center;
    }

    .context-empty svg {
      opacity: 0.5;
    }
    
    .close-btn {
      width: 28px;
      height: 28px;
      border-radius: 6px;
      border: none;
      background: rgba(255, 255, 255, 0.1);
      color: #9ca3af;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }
    
    .close-btn:hover {
      background: rgba(239, 68, 68, 0.2);
      color: #ef4444;
    }

    /* Tabs */
    .tabs {
      display: flex;
      padding: 0 12px;
      background: rgba(0, 0, 0, 0.2);
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      flex-shrink: 0;
    }

    .tab {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 12px 16px;
      border: none;
      background: transparent;
      color: #6b7280;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      border-bottom: 2px solid transparent;
      margin-bottom: -1px;
    }

    .tab:hover {
      color: #9ca3af;
    }

    .tab.active {
      color: #0a66c2;
      border-bottom-color: #0a66c2;
    }

    .tab svg {
      opacity: 0.7;
    }

    .tab.active svg {
      opacity: 1;
    }

    /* Reply Mode Indicator */
    .reply-mode-indicator {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 16px;
      background: linear-gradient(90deg, rgba(139, 92, 246, 0.15) 0%, rgba(139, 92, 246, 0.05) 100%);
      border-bottom: 1px solid rgba(139, 92, 246, 0.2);
      font-size: 12px;
      color: #a78bfa;
      font-weight: 500;
    }

    .reply-mode-indicator svg {
      flex-shrink: 0;
    }

    .reply-to-name {
      color: #c4b5fd;
      font-weight: 600;
      margin-left: 4px;
    }

    /* Context Awareness Section */
    .context-awareness {
      background: rgba(0, 0, 0, 0.25);
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding: 12px 16px;
    }

    .context-header {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
      margin-bottom: 12px;
    }

    .context-header svg {
      color: #6b7280;
    }

    .scanning-badge {
      margin-left: auto;
      padding: 2px 8px;
      background: rgba(59, 130, 246, 0.2);
      border: 1px solid rgba(59, 130, 246, 0.3);
      border-radius: 10px;
      font-size: 9px;
      color: #60a5fa;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      animation: pulse 1.5s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    .context-timeline {
      display: flex;
      flex-direction: column;
      gap: 0;
      position: relative;
    }

    .context-item {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      padding: 8px 0;
      position: relative;
    }

    .context-item-line {
      position: absolute;
      left: 5px;
      top: 22px;
      bottom: -8px;
      width: 2px;
      background: rgba(255, 255, 255, 0.1);
    }

    .context-item:last-child .context-item-line {
      display: none;
    }

    .context-item-icon {
      width: 12px;
      height: 12px;
      margin-top: 2px;
      flex-shrink: 0;
      color: #6b7280;
      position: relative;
      z-index: 1;
    }

    .context-item.success .context-item-icon {
      color: #4ade80;
    }

    .context-item.warning .context-item-icon {
      color: #fbbf24;
    }

    .context-item.scanning .context-item-icon {
      color: #60a5fa;
    }

    .context-item-content {
      flex: 1;
      min-width: 0;
    }

    .context-item-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 2px;
    }

    .context-item-label {
      font-size: 11px;
      font-weight: 600;
      color: #e5e7eb;
    }

    .context-status {
      width: 14px;
      height: 14px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .context-status.success {
      background: rgba(34, 197, 94, 0.2);
      color: #22c55e;
    }

    .context-status.warning {
      background: rgba(251, 191, 36, 0.2);
      color: #fbbf24;
    }

    .context-status.scanning {
      background: rgba(59, 130, 246, 0.2);
    }

    .scan-spinner {
      width: 8px;
      height: 8px;
      border: 1.5px solid rgba(96, 165, 250, 0.3);
      border-top-color: #60a5fa;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    /* Mini toggle for image analysis in context item */
    .image-analysis-toggle {
      display: flex;
      align-items: center;
      margin-left: auto;
      cursor: pointer;
    }

    .image-analysis-toggle input {
      display: none;
    }

    .mini-toggle {
      width: 28px;
      height: 16px;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      position: relative;
      transition: all 0.2s;
    }

    .mini-toggle::after {
      content: '';
      position: absolute;
      top: 2px;
      left: 2px;
      width: 12px;
      height: 12px;
      background: #fff;
      border-radius: 50%;
      transition: all 0.2s;
    }

    .mini-toggle.active {
      background: linear-gradient(135deg, #8b5cf6, #a855f7);
    }

    .mini-toggle.active::after {
      transform: translateX(12px);
    }

    .context-item-value {
      font-size: 11px;
      color: #9ca3af;
      line-height: 1.4;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .context-item-value.scanning {
      color: #60a5fa;
      font-style: italic;
    }

    .context-item-value.warning {
      color: #fbbf24;
      font-size: 10px;
    }

    /* Hover tooltip for context items */
    .context-item.has-tooltip {
      cursor: pointer;
    }

    .context-item.has-tooltip:hover {
      background: rgba(255, 255, 255, 0.03);
      border-radius: 6px;
      margin: -4px;
      padding: 4px;
    }

    .hover-hint {
      margin-left: 4px;
      opacity: 0.4;
      transition: opacity 0.2s;
    }

    .context-item:hover .hover-hint {
      opacity: 0.8;
    }

    .context-tooltip {
      position: absolute;
      left: 0;
      right: 0;
      top: 100%;
      margin-top: 4px;
      background: #1e1e2f;
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 10px;
      padding: 12px;
      z-index: 100;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      animation: tooltipFadeIn 0.15s ease-out;
    }

    @keyframes tooltipFadeIn {
      from {
        opacity: 0;
        transform: translateY(-4px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .context-tooltip-header {
      font-size: 10px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .context-tooltip-content {
      font-size: 12px;
      line-height: 1.6;
      color: #e5e7eb;
      max-height: 200px;
      overflow-y: auto;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .context-tooltip-content::-webkit-scrollbar {
      width: 4px;
    }

    .context-tooltip-content::-webkit-scrollbar-track {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 2px;
    }

    .context-tooltip-content::-webkit-scrollbar-thumb {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 2px;
    }
    
    .panel-content {
      padding: 20px;
      overflow-y: auto;
      flex: 1;
    }
    
    .section {
      margin-bottom: 20px;
    }
    
    .section-label {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #9ca3af;
      margin-bottom: 8px;
    }
    
    .post-preview {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      padding: 12px;
      font-size: 13px;
      line-height: 1.5;
      color: #d1d5db;
      max-height: 100px;
      overflow-y: auto;
    }
    
    .post-preview h1 {
      font-size: 18px;
      font-weight: 700;
      color: #fff;
      margin: 12px 0 8px 0;
    }
    
    .post-preview h2 {
      font-size: 16px;
      font-weight: 600;
      color: #fff;
      margin: 10px 0 6px 0;
    }
    
    .post-preview h3 {
      font-size: 14px;
      font-weight: 600;
      color: #e5e7eb;
      margin: 8px 0 4px 0;
    }
    
    .post-preview p {
      margin: 8px 0;
      line-height: 1.6;
    }
    
    .post-preview strong {
      font-weight: 600;
      color: #fff;
    }
    
    .post-preview em {
      font-style: italic;
      color: #d1d5db;
    }
    
    .post-preview br {
      line-height: 1.6;
    }
    
    .author-info {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: #9ca3af;
      margin-bottom: 8px;
    }
    
    .author-name {
      color: #fff;
      font-weight: 500;
    }
    
    /* Your Thoughts Input */
    .thoughts-input-wrapper {
      position: relative;
    }

    .thoughts-input {
      width: 100%;
      padding: 10px 32px 10px 12px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #fff;
      font-size: 13px;
      font-family: inherit;
      line-height: 1.5;
      resize: none;
      transition: all 0.2s;
      min-height: 60px;
      max-height: 120px;
    }

    .thoughts-input::placeholder {
      color: #6b7280;
      font-size: 12px;
    }

    .thoughts-input:hover {
      border-color: rgba(255, 255, 255, 0.2);
    }

    .thoughts-input:focus {
      outline: none;
      border-color: #0a66c2;
      box-shadow: 0 0 0 3px rgba(10, 102, 194, 0.2);
    }

    .clear-thoughts-btn {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      border: none;
      background: rgba(255, 255, 255, 0.1);
      color: #9ca3af;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
    }

    .clear-thoughts-btn:hover {
      background: rgba(239, 68, 68, 0.2);
      color: #ef4444;
    }

    .optional-label {
      font-weight: 400;
      color: #6b7280;
      font-size: 10px;
    }

    /* Service Offer Toggle */
    .service-offer-toggle {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.05), rgba(234, 88, 12, 0.05));
      border: 1px solid rgba(245, 158, 11, 0.2);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
      position: relative;
    }

    .service-offer-toggle:not(.disabled):hover {
      background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(234, 88, 12, 0.1));
      border-color: rgba(245, 158, 11, 0.3);
    }

    .service-offer-toggle.disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .toggle-left {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .toggle-icon {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      background: rgba(245, 158, 11, 0.15);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #f59e0b;
    }

    .toggle-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .toggle-label {
      font-size: 12px;
      font-weight: 500;
      color: #fff;
    }

    .toggle-hint {
      font-size: 10px;
      color: #9ca3af;
    }

    .toggle-hint.warning {
      color: #f59e0b;
    }

    .toggle-checkbox {
      position: absolute;
      opacity: 0;
      pointer-events: none;
    }

    .toggle-switch {
      width: 36px;
      height: 20px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      position: relative;
      transition: all 0.2s;
      flex-shrink: 0;
    }

    .toggle-switch::after {
      content: '';
      position: absolute;
      top: 2px;
      left: 2px;
      width: 16px;
      height: 16px;
      background: #fff;
      border-radius: 50%;
      transition: all 0.2s;
    }

    .toggle-switch.active {
      background: linear-gradient(135deg, #f59e0b, #ea580c);
    }

    .toggle-switch.active::after {
      transform: translateX(16px);
    }

    /* Image Toggle */
    .image-toggle {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px;
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(168, 85, 247, 0.05));
      border: 1px solid rgba(139, 92, 246, 0.2);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
      position: relative;
    }

    .image-toggle:hover {
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(168, 85, 247, 0.1));
      border-color: rgba(139, 92, 246, 0.3);
    }

    .toggle-icon.image {
      background: rgba(139, 92, 246, 0.15);
      color: #a855f7;
    }

    .toggle-switch.image.active {
      background: linear-gradient(135deg, #8b5cf6, #a855f7);
    }

    .tone-select {
      width: 100%;
      padding: 10px 14px;
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #fff;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.2s;
      appearance: none;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 12px center;
    }
    
    .tone-select:hover {
      border-color: rgba(255, 255, 255, 0.2);
    }
    
    .tone-select:focus {
      outline: none;
      border-color: #0a66c2;
      box-shadow: 0 0 0 3px rgba(10, 102, 194, 0.2);
    }
    
    .tone-select option {
      background: #1a1a2e;
      color: #fff;
    }
    
    .generate-btn {
      width: 100%;
      padding: 12px 20px;
      background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
      border: none;
      border-radius: 10px;
      color: #fff;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      transition: all 0.2s;
    }
    
    .generate-btn:hover:not(:disabled) {
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(10, 102, 194, 0.4);
    }
    
    .generate-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    .spinner {
      width: 18px;
      height: 18px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top-color: #fff;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    .spinner-small {
      width: 12px;
      height: 12px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top-color: #fff;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    
    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* Shimmer Loading */
    .shimmer-container {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .shimmer-card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .shimmer-line {
      height: 12px;
      border-radius: 6px;
      background: linear-gradient(
        90deg,
        rgba(255, 255, 255, 0.05) 0%,
        rgba(255, 255, 255, 0.1) 50%,
        rgba(255, 255, 255, 0.05) 100%
      );
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
    }

    .shimmer-line.long { width: 100%; }
    .shimmer-line.medium { width: 75%; }
    .shimmer-line.short { width: 50%; }

    @keyframes shimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
    
    .results {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    
    .comment-card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      padding: 14px;
      transition: all 0.2s;
    }

    .comment-card.refining {
      opacity: 0.6;
    }
    
    .comment-card:hover {
      background: rgba(255, 255, 255, 0.08);
      border-color: rgba(255, 255, 255, 0.15);
    }
    
    .comment-text {
      font-size: 13px;
      line-height: 1.6;
      color: #e5e7eb;
      margin-bottom: 12px;
    }
    
    .comment-actions {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .action-group {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .action-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      padding: 6px 10px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.05);
      color: #9ca3af;
      font-size: 11px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .action-btn:hover:not(:disabled) {
      background: rgba(255, 255, 255, 0.1);
      color: #fff;
    }

    .action-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .action-btn.copied {
      background: rgba(34, 197, 94, 0.2);
      border-color: rgba(34, 197, 94, 0.3);
      color: #22c55e;
    }

    .action-btn.refine-btn {
      padding: 5px 8px;
      font-size: 10px;
      gap: 4px;
    }

    .action-btn.refine-btn span {
      font-weight: 500;
    }

    .insert-btn {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 6px 12px;
      background: linear-gradient(135deg, #0a66c2 0%, #0077b5 100%);
      border: none;
      border-radius: 6px;
      color: #fff;
      font-size: 11px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    .insert-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(10, 102, 194, 0.4);
    }
    
    /* Recommendation Tag */
    .recommendation-tag {
      display: inline-block;
      font-size: 10px;
      font-weight: 600;
      color: #93c5fd;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
      padding: 3px 8px;
      background: rgba(59, 130, 246, 0.15);
      border-radius: 4px;
    }
    
    .error-message {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 10px;
      padding: 12px;
      color: #fca5a5;
      font-size: 13px;
      display: flex;
      align-items: flex-start;
      gap: 10px;
    }
    
    .error-icon {
      flex-shrink: 0;
      color: #ef4444;
    }
    
    .no-api-key {
      text-align: center;
      padding: 20px;
    }
    
    .no-api-key-icon {
      width: 48px;
      height: 48px;
      margin: 0 auto 16px;
      border-radius: 12px;
      background: rgba(251, 191, 36, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fbbf24;
    }
    
    .no-api-key h3 {
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 8px;
    }
    
    .no-api-key p {
      font-size: 13px;
      color: #9ca3af;
      margin-bottom: 16px;
    }
    
    .settings-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 10px 16px;
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      color: #fff;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    .settings-btn:hover {
      background: rgba(255, 255, 255, 0.15);
    }

    /* History Tab */
    .history-section {
      min-height: 200px;
    }

    .empty-history {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .empty-history svg {
      margin-bottom: 16px;
      opacity: 0.5;
    }

    .empty-history p {
      font-size: 14px;
      font-weight: 500;
      margin-bottom: 4px;
      color: #9ca3af;
    }

    .empty-history span {
      font-size: 12px;
    }

    .history-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }

    .history-count {
      font-size: 11px;
      color: #6b7280;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .clear-history-btn {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px 8px;
      background: transparent;
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 4px;
      color: #ef4444;
      font-size: 11px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .clear-history-btn:hover {
      background: rgba(239, 68, 68, 0.1);
    }

    .history-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .history-item {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 10px;
      padding: 12px;
    }

    .history-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
      font-size: 11px;
      color: #6b7280;
    }

    .history-time {
      color: #9ca3af;
      font-weight: 500;
    }

    .history-post {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .history-comment {
      font-size: 13px;
      line-height: 1.5;
      color: #d1d5db;
      margin-bottom: 10px;
    }

    .history-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .panel-footer {
      padding: 12px 20px;
      border-top: 1px solid rgba(255, 255, 255, 0.08);
      background: rgba(0, 0, 0, 0.2);
      font-size: 11px;
      color: #6b7280;
      text-align: center;
      line-height: 1.5;
      flex-shrink: 0;
    }
    
    .panel-footer .sponsor-link {
      color: #9ca3af;
      font-weight: 600;
      text-decoration: none;
      transition: color 0.2s;
    }
    
    .panel-footer .sponsor-link:hover {
      color: #0a66c2;
      text-decoration: underline;
    }
    
    .panel-footer .footer-divider {
      margin: 0 8px;
      color: #4b5563;
    }
    
    .panel-footer .support-link {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      color: #ef4444;
      font-weight: 500;
      text-decoration: none;
      transition: all 0.2s;
      margin-left: 4px;
    }
    
    .panel-footer .support-link svg {
      width: 14px;
      height: 14px;
      fill: #ef4444;
      stroke: #ef4444;
    }
    
    .panel-footer .support-link:hover {
      color: #f87171;
      text-decoration: underline;
    }
    
    .panel-footer .support-link:hover svg {
      fill: #f87171;
      stroke: #f87171;
      transform: scale(1.1);
    }
  `}
